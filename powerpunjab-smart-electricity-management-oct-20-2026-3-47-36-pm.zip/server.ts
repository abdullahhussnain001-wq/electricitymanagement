import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Google GenAI if key is present
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(ai),
    timestamp: new Date().toISOString(),
  });
});

// AI Bill Analysis Endpoint
app.post('/api/gemini/analyze-bill', async (req: Request, res: Response) => {
  try {
    const { bill, previousBill, connectionName } = req.body;

    if (!bill) {
      return res.status(400).json({ error: 'Bill data is required' });
    }

    if (!ai) {
      // Deterministic realistic analysis fallback
      return res.json({
        source: 'deterministic-fallback',
        summary: `Your ${bill.billingMonth} electricity bill for ${connectionName || 'your connection'} is Rs. ${bill.totalAmount.toLocaleString()} for ${bill.unitsConsumed} units consumed. This represents an increase of ${previousBill ? Math.round(((bill.unitsConsumed - previousBill.unitsConsumed) / previousBill.unitsConsumed) * 100) : 18}% in consumption compared to the previous cycle.`,
        consumptionChange: previousBill 
          ? `Units consumed increased from ${previousBill.unitsConsumed} to ${bill.unitsConsumed} units (+${bill.unitsConsumed - previousBill.unitsConsumed} units, +${(((bill.unitsConsumed - previousBill.unitsConsumed) / previousBill.unitsConsumed) * 100).toFixed(1)}%). The bill amount rose from Rs. ${previousBill.totalAmount.toLocaleString()} to Rs. ${bill.totalAmount.toLocaleString()} (+Rs. ${(bill.totalAmount - previousBill.totalAmount).toLocaleString()}, +${(((bill.totalAmount - previousBill.totalAmount) / previousBill.totalAmount) * 100).toFixed(1)}%).`
          : `Total recorded consumption is ${bill.unitsConsumed} units with a total payable amount of Rs. ${bill.totalAmount.toLocaleString()}.`,
        chargeBreakdown: [
          { name: 'Cost of Electricity', amount: bill.costOfElectricity || 5700, explanation: 'Base energy charges for units consumed calculated across tariff slabs.' },
          { name: 'Fuel Price Adjustment (FPA)', amount: bill.fuelPriceAdjustment || 890, explanation: 'Variation in thermal power fuel generation costs passed through per NEPRA regulations.' },
          { name: 'FC Surcharge', amount: bill.fcSurcharge || 450, explanation: 'Financing cost surcharge applied to debt servicing in the power sector.' },
          { name: 'Electricity Duty & TV Fee', amount: (bill.electricityDuty || 120) + (bill.tvFee || 35), explanation: 'Provincial electricity duty (1.5%) and government PTV license fee (Rs. 35).' },
          { name: 'Sales Tax (GST)', amount: bill.salesTax || 1255, explanation: 'Standard 17% general sales tax on electricity supply.' },
        ],
        possibleReasons: [
          'Increased utilization of cooling appliances (air conditioners or desert coolers) during peak daytime and nighttime temperatures.',
          'Refrigeration compressors running longer cycles due to ambient humidity and heat.',
          'Crossing into a higher tariff slab (e.g. above 300 or 400 units), where the baseline per-unit rate increases progressively.',
          'Seasonal fuel price adjustment (FPA) variations reflecting grid fuel generation mix.'
        ],
        recommendations: [
          'Set air conditioner thermostats to 26°C instead of 20°C to reduce cooling compressor workload by up to 30%.',
          'Shift high-load appliance usage (ironing, washing machine, water pump) to off-peak daytime hours before 6:00 PM.',
          'Clean air conditioner filters and refrigerator coils every fortnight to optimize airflow efficiency.',
          'Switch any remaining incandescent or compact fluorescent lamps to 9W-12W LED bulbs.'
        ],
        limitations: 'This AI analysis is based on available demonstration billing figures and fictional tariff assumptions. It does not replace physical meter inspection or official utility records.'
      });
    }

    const prompt = `You are the PowerPunjab AI Electricity Bill Analyst for residential consumers in Punjab, Pakistan.
Analyze the following electricity bill comparison and generate a comprehensive, user-friendly breakdown in JSON format.

Current Bill:
Month: ${bill.billingMonth}
Units: ${bill.unitsConsumed}
Total Amount: Rs. ${bill.totalAmount}
Base Energy Cost: Rs. ${bill.costOfElectricity}
Fuel Price Adjustment: Rs. ${bill.fuelPriceAdjustment}
FC Surcharge: Rs. ${bill.fcSurcharge}
Electricity Duty: Rs. ${bill.electricityDuty}
TV Fee: Rs. ${bill.tvFee}
Sales Tax: Rs. ${bill.salesTax}

Previous Bill:
${previousBill ? `Month: ${previousBill.billingMonth}, Units: ${previousBill.unitsConsumed}, Total Amount: Rs. ${previousBill.totalAmount}` : 'No previous bill provided.'}

Connection: ${connectionName || 'Home Connection'}

Provide a structured, empathetic, and strictly factual explanation in JSON with the following keys:
- summary: string (plain language 2-3 sentence overview)
- consumptionChange: string (clear description of unit and rupee changes with exact calculated percentages)
- chargeBreakdown: array of { name: string, amount: number, explanation: string }
- possibleReasons: array of 4 plausible real-world reasons (e.g., cooling load, tariff slabs, weather)
- recommendations: array of 4 practical actionable energy-saving tips
- limitations: string (disclaimer noting this is based on demonstration data)

Respond with valid JSON only.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ source: 'gemini-3.8-flash', ...parsed });
  } catch (error) {
    console.error('Error in analyze-bill:', error);
    return res.status(500).json({
      error: 'Failed to analyze bill with AI',
      details: error instanceof Error ? error.message : String(error),
    });
  }
});

// AI Support Assistant Endpoint
app.post('/api/gemini/chat', async (req: Request, res: Response) => {
  try {
    const { messages, userContext } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    const lastMessage = messages[messages.length - 1]?.content || '';

    if (!ai) {
      // Intelligent fallback for support assistant
      const lower = lastMessage.toLowerCase();
      let reply = "Hello! I am your PowerPunjab Smart Assistant. I can help you understand your electricity bills, explain tariff structures, estimate appliance running costs, and guide you on filing complaints.";

      if (lower.includes('why') && (lower.includes('bill') || lower.includes('high') || lower.includes('increase'))) {
        reply = "Your current October bill (Rs. 8,450 for 496 units) is higher than September (Rs. 7,820 for 420 units) primarily because your recorded consumption increased by 76 units (+18.1%). In Punjab's progressive tariff structure, crossing higher unit thresholds incurs higher per-unit rates, in addition to increased Fuel Price Adjustments (FPA) and General Sales Tax (17%). Using ACs or continuous cooling during humid days is the most common reason for this rise.";
      } else if (lower.includes('unit') && lower.includes('mean')) {
        reply = "In electricity billing, '1 unit' is equivalent to 1 Kilowatt-hour (1 kWh). This means operating a 1,000-watt appliance continuously for 1 hour. For instance, running a 1,000W iron for 1 hour consumes exactly 1 unit. Ten 100W light bulbs running together for 1 hour also consume 1 unit.";
      } else if (lower.includes('save') || lower.includes('reduce')) {
        reply = "Here are top 4 practical ways to reduce your electricity bill:\n1. Set Inverter ACs to 26°C with fan speed on auto (saves 20-30% power compared to 20°C).\n2. Unplug standby electronics and chargers when not in use.\n3. Run heavy appliances (washing machine, iron, water pumps) outside peak hours.\n4. Replace old tube lights and incandescent bulbs with 9W-12W LED lights.";
      } else if (lower.includes('complaint') || lower.includes('voltage') || lower.includes('outage')) {
        reply = "You can easily report problems right here in the app! Tap on 'Report a Problem' on the dashboard or head to the Complaints section. Select your issue category (e.g., Low Voltage, Power Outage, Meter Issue) and submit. You will receive an instant tracking ID (like PP-10482) to track technician progress.";
      } else if (lower.includes('calculate') || lower.includes('appliance') || lower.includes('cost')) {
        reply = "You can use our interactive Energy Calculator! For example, running a 1.5-ton AC (1,800 watts) for 8 hours a day consumes approximately 14.4 units per day, costing about Rs. 345/day (or ~Rs. 10,350/month) at an assumed rate of Rs. 24/unit. Check the Calculator tool to test all your home appliances.";
      } else if (lower.includes('pay') || lower.includes('receipt')) {
        reply = "You can simulate bill payments securely in PowerPunjab! Open your unpaid bill, tap 'Pay Now', select your preferred mock payment channel (Bank Transfer, Card, Easypaisa/JazzCash), and confirm. Once done, an instant digital receipt is generated and your bill is updated to 'Paid'.";
      }

      return res.json({
        reply,
        source: 'deterministic-fallback',
      });
    }

    const systemInstruction = `You are PowerPunjab AI Assistant, an expert, polite, and practical electricity management assistant for residential consumers in Punjab, Pakistan.
Current Consumer Context:
- Name: ${userContext?.userName || 'Ahmed Khan'}
- Active Connection: ${userContext?.connectionName || 'Home (DEMO-10284)'}
- Current Bill: Rs. ${userContext?.currentBillAmount || '8,450'} for ${userContext?.currentUnits || '496'} units (Status: ${userContext?.billStatus || 'Unpaid'})
- Previous Bill: Rs. 7,820 for 420 units
- Assumed Tariff Baseline: Progressive residential slabs, average ~Rs. 17.50-24/unit + taxes & surcharges.

Guidelines:
- Provide clear, friendly, and helpful guidance in plain English (with optional Urdu terminology where helpful like 'Wapda', 'Bijli', 'FPA', 'Kunda', 'Inverter').
- Ground your answers in the consumer's current demo bill numbers whenever relevant.
- Clearly emphasize that this is a smart demonstration application and not official utility databases.
- Keep answers structured with short bullet points when explaining multiple tips or charges.`;

    const contents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction,
      },
    });

    return res.json({
      reply: response.text || 'I could not generate an answer right now. Please try again.',
      source: 'gemini-3.8-flash',
    });
  } catch (error) {
    console.error('Error in chat:', error);
    return res.status(500).json({
      error: 'Failed to process chat message',
      details: error instanceof Error ? error.message : String(error),
    });
  }
});

// Appliance audit advice endpoint
app.post('/api/gemini/appliance-advice', async (req: Request, res: Response) => {
  try {
    const { appliance, watts, hours, monthlyCost } = req.body;
    if (!ai) {
      return res.json({
        advice: `For your ${appliance} (${watts}W operating ${hours} hrs/day, estimated at Rs. ${monthlyCost}/month), optimizing daily usage by just 2 hours can save approximately 15-20% on that appliance's electricity consumption. Ensure regular maintenance to avoid power surges.`,
        source: 'fallback',
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Provide 2 concise, practical energy-saving tips for an appliance: ${appliance} (rated ${watts} watts, used ${hours} hours per day, costing estimated Rs. ${monthlyCost}/month in Pakistan). Keep it under 60 words.`,
    });

    return res.json({
      advice: response.text,
      source: 'gemini-3.8-flash',
    });
  } catch (error) {
    return res.json({
      advice: `Operating your ${req.body.appliance} during off-peak hours and ensuring proper maintenance will help keep energy consumption at the lowest possible slab.`,
      source: 'fallback',
    });
  }
});

// Setup Vite or Static File Serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`⚡ PowerPunjab Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
