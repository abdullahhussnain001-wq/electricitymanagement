import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  Settings,
  Globe,
  Bell,
  BookOpen,
  RotateCcw,
  LogOut,
  ChevronRight,
  Check,
  Edit2,
  Building2,
  FileDown,
  ShieldCheck,
  Building,
} from 'lucide-react';

export const ProfileTab: React.FC = () => {
  const {
    user,
    updateUser,
    connections,
    activeConnection,
    switchConnection,
    openTariffsEducation,
    openPdfReport,
    logout,
    resetDemoData,
  } = useApp();

  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [nameInput, setNameInput] = useState(user.name);
  const [phoneInput, setPhoneInput] = useState(user.phone);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUser({ name: nameInput, phone: phoneInput });
    setIsEditingProfile(false);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs">
        <span className="text-[11px] font-bold text-[#003366] uppercase tracking-wider block">
          Citizen Record & Preferences
        </span>
        <h2 className="text-xl font-bold text-[#0B2545] tracking-tight">
          Consumer Profile & Meter Registry
        </h2>
        <p className="text-xs text-slate-600 mt-0.5">
          Manage your verified consumer identity, registered meters, and personal record exports
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Profile & Registered Meters */}
        <div className="lg:col-span-2 space-y-6">
          {/* Consumer Information Card */}
          <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-[#D1D5DB] pb-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded bg-[#003366] text-white flex items-center justify-center font-bold text-sm">
                  {user.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#0B2545]">{user.name}</h3>
                  <p className="text-xs text-slate-600">{user.email}</p>
                </div>
              </div>

              <button
                onClick={() => setIsEditingProfile(!isEditingProfile)}
                className="py-1.5 px-3 bg-[#F4F6F8] hover:bg-slate-200 border border-[#D1D5DB] text-xs font-semibold text-slate-700 rounded transition-colors cursor-pointer"
              >
                {isEditingProfile ? 'Cancel' : 'Edit Details'}
              </button>
            </div>

            {/* Profile fields or edit form */}
            {isEditingProfile ? (
              <form onSubmit={handleSaveProfile} className="space-y-3 pt-2 text-xs">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Full Legal Name</label>
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-xs text-slate-900 focus:border-[#003366]"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Contact Phone Number</label>
                  <input
                    type="text"
                    value={phoneInput}
                    onChange={(e) => setPhoneInput(e.target.value)}
                    className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-xs text-slate-900 focus:border-[#003366]"
                  />
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsEditingProfile(false)}
                    className="py-1 px-3 text-xs text-slate-600 hover:text-slate-900"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="py-1.5 px-4 bg-[#003366] hover:bg-[#0B2545] text-white text-xs font-bold rounded transition-colors"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block font-medium">Account Category</span>
                  <span className="font-bold text-slate-900">
                    {user.accountType === 'demo' ? 'Official Demonstration User' : 'Registered Citizen Account'}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block font-medium">Registered Phone</span>
                  <span className="font-mono font-medium text-slate-800">{user.phone}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block font-medium">Verification Status</span>
                  <span className="text-[#0F5132] font-bold flex items-center gap-1 mt-0.5">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Verified Citizen</span>
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Registered Electricity Meters */}
          <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs space-y-4">
            <div className="border-b border-[#D1D5DB] pb-3">
              <h3 className="text-sm font-bold text-[#0B2545]">
                Registered Electricity Connections ({connections.length})
              </h3>
              <p className="text-xs text-slate-500">
                Meters linked to your national identity and account reference
              </p>
            </div>

            <div className="space-y-3">
              {connections.map((conn) => {
                const isSelected = conn.connectionId === activeConnection.connectionId;

                return (
                  <div
                    key={conn.connectionId}
                    className={`p-4 rounded border transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-[#F4F6F8] border-[#003366]'
                        : 'bg-white border-[#D1D5DB] hover:bg-[#F4F6F8]/60'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm">{conn.displayName}</span>
                        {isSelected ? (
                          <span className="bg-[#003366] text-white text-[10px] font-bold uppercase px-2 py-0.5 rounded">
                            Active Meter
                          </span>
                        ) : (
                          <span className="text-slate-500 text-[10px] font-medium border border-slate-300 px-1.5 py-0.2 rounded">
                            Secondary
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-600 font-mono">
                        Ref: <strong className="text-slate-900">{conn.referenceNumber}</strong> • Meter: {conn.maskedMeterNumber}
                      </div>
                      <div className="text-xs text-slate-500">
                        {conn.serviceProvider || 'LESCO'} • Tariff: {conn.tariff} ({conn.sanctionedLoad})
                      </div>
                    </div>

                    {!isSelected && (
                      <button
                        onClick={() => switchConnection(conn.connectionId)}
                        className="py-1.5 px-3 bg-white hover:bg-slate-100 text-[#003366] border border-[#003366] text-xs font-bold rounded cursor-pointer self-start sm:self-center"
                      >
                        Switch To This Meter
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Official Actions & Demonstration Controls */}
        <div className="space-y-6">
          {/* Document Export Box */}
          <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs space-y-3">
            <h3 className="text-sm font-bold text-[#0B2545] border-b border-[#D1D5DB] pb-2">
              Official Statements
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Export an official certified summary of all electricity invoices and units for personal tax and accounting records.
            </p>
            <button
              onClick={openPdfReport}
              className="w-full py-2 px-4 bg-[#003366] hover:bg-[#0B2545] text-white text-xs font-bold rounded flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-none"
            >
              <FileDown className="w-4 h-4" />
              <span>Export PDF Statement</span>
            </button>
          </div>

          {/* Statutory Regulations */}
          <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs space-y-3">
            <h3 className="text-sm font-bold text-[#0B2545] border-b border-[#D1D5DB] pb-2">
              Statutory Resources
            </h3>
            <button
              onClick={openTariffsEducation}
              className="w-full text-left p-3 rounded bg-[#F4F6F8] hover:bg-slate-200 border border-[#D1D5DB] transition-colors flex items-center justify-between text-xs cursor-pointer"
            >
              <div>
                <span className="font-bold text-slate-900 block">NEPRA Slabs & Electricity Guides</span>
                <span className="text-[10px] text-slate-500">Official tariff structure & peak hours</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
          </div>

          {/* Demonstration Environment Controls */}
          <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs space-y-3">
            <h3 className="text-sm font-bold text-[#0B2545] border-b border-[#D1D5DB] pb-2">
              Session Management
            </h3>

            <div className="space-y-2">
              <button
                onClick={() => setShowResetConfirm(true)}
                className="w-full py-2 px-3 bg-[#F4F6F8] hover:bg-[#F8D7DA] text-slate-700 hover:text-[#842029] border border-[#D1D5DB] text-xs font-semibold rounded flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Demonstration Records</span>
              </button>

              <button
                onClick={logout}
                className="w-full py-2 px-3 bg-white hover:bg-[#F4F6F8] text-[#842029] border border-[#F5C2C7] text-xs font-bold rounded flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out of Portal</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Reset Confirmation Dialog */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D1D5DB] w-full max-w-sm rounded p-5 space-y-3 shadow-lg">
            <h4 className="text-sm font-bold text-[#0B2545]">Reset Demonstration Data?</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              This will restore original demo meter records and set the October 2026 invoice back to Unpaid status.
            </p>
            <div className="flex justify-end gap-2 pt-2 border-t border-[#D1D5DB]">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="py-1.5 px-3 rounded border border-[#D1D5DB] text-slate-700 text-xs font-semibold cursor-pointer hover:bg-[#F4F6F8]"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  resetDemoData();
                  setShowResetConfirm(false);
                }}
                className="py-1.5 px-4 rounded bg-[#003366] text-white text-xs font-bold cursor-pointer hover:bg-[#0B2545]"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
