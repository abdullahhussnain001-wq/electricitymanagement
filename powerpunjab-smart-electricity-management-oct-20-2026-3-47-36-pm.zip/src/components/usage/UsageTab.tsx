import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DataService } from '../../services/dataService';
import { MonthlyUsage } from '../../types';
import {
  TrendingUp,
  BarChart2,
  Calendar,
  Zap,
  ArrowRight,
  Info,
  DollarSign,
  ArrowUpDown,
  FileDown,
  Calculator,
} from 'lucide-react';

export const UsageTab: React.FC = () => {
  const { activeConnection, openCalculator, openPdfReport } = useApp();
  const [metricView, setMetricView] = useState<'units' | 'cost'>('units');
  const [selectedMonthIndex, setSelectedMonthIndex] = useState<number>(5);
  const [compareMonthA, setCompareMonthA] = useState<number>(4);
  const [compareMonthB, setCompareMonthB] = useState<number>(5);

  const usageData: MonthlyUsage[] = DataService.getMonthlyUsage(activeConnection.connectionId);

  const selectedData = usageData[selectedMonthIndex] || usageData[usageData.length - 1];

  const monthAData = usageData[compareMonthA] || usageData[4];
  const monthBData = usageData[compareMonthB] || usageData[5];

  const unitDiff = monthBData.units - monthAData.units;
  const unitPct = monthAData.units > 0 ? ((unitDiff / monthAData.units) * 100).toFixed(1) : '0';

  const costDiff = monthBData.estimatedCost - monthAData.estimatedCost;
  const costPct = monthAData.estimatedCost > 0 ? ((costDiff / monthAData.estimatedCost) * 100).toFixed(1) : '0';

  const maxVal = metricView === 'units'
    ? Math.max(...usageData.map((d: MonthlyUsage) => d.units)) * 1.15
    : Math.max(...usageData.map((d: MonthlyUsage) => d.estimatedCost)) * 1.15;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <span className="text-[11px] font-bold text-[#003366] uppercase tracking-wider block">
            Metered Consumption Analytics
          </span>
          <h2 className="text-xl font-bold text-[#0B2545] tracking-tight">
            Electricity Usage & Trend Records
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Connection: <strong className="text-slate-900">{activeConnection.displayName}</strong> • Meter: <span className="font-mono text-slate-800 font-bold">{activeConnection.maskedMeterNumber}</span>
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Toggle units vs cost */}
          <div className="bg-[#F4F6F8] border border-[#D1D5DB] p-0.5 rounded flex text-xs">
            <button
              onClick={() => setMetricView('units')}
              className={`px-3 py-1 rounded font-bold transition-colors cursor-pointer ${
                metricView === 'units'
                  ? 'bg-[#003366] text-white'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              Units (kWh)
            </button>
            <button
              onClick={() => setMetricView('cost')}
              className={`px-3 py-1 rounded font-bold transition-colors cursor-pointer ${
                metricView === 'cost'
                  ? 'bg-[#003366] text-white'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              Cost (PKR)
            </button>
          </div>

          <button
            onClick={openPdfReport}
            className="flex items-center gap-1.5 py-1.5 px-3 bg-white hover:bg-[#F4F6F8] text-[#003366] border border-[#003366] text-xs font-bold rounded transition-colors cursor-pointer"
          >
            <FileDown className="w-3.5 h-3.5" />
            <span>Export Report (PDF)</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Monthly Bar Chart & Tabular View */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-[#D1D5DB] pb-3">
              <div>
                <h3 className="text-sm font-bold text-[#0B2545]">
                  6-Month Consumption Chart ({metricView === 'units' ? 'kWh Units' : 'PKR Charges'})
                </h3>
                <p className="text-xs text-slate-500">
                  Select any month to inspect line statistics
                </p>
              </div>

              <span className="text-xs font-bold text-[#003366] bg-[#F4F6F8] px-2.5 py-1 rounded border border-[#D1D5DB]">
                Selected: {selectedData.month} 2026
              </span>
            </div>

            {/* Selected Month Banner */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-[#F4F6F8] p-3.5 rounded border border-[#D1D5DB] text-xs">
              <div>
                <span className="text-[10px] text-slate-500 uppercase block font-semibold">Consumption (kWh)</span>
                <span className="font-mono text-xl font-bold text-[#003366]">
                  {selectedData.units} kWh
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase block font-semibold">Energy Charges</span>
                <span className="font-mono text-xl font-bold text-slate-900">
                  Rs. {selectedData.estimatedCost.toLocaleString()}
                </span>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <span className="text-[10px] text-slate-500 uppercase block font-semibold">Cycle Status</span>
                <span className="text-xs font-bold text-[#0F5132]">
                  {selectedData.isCurrent ? 'Current Billed Period' : 'Historical Period'}
                </span>
              </div>
            </div>

            {/* Standard Accessible Bar Chart */}
            <div className="pt-4">
              <div className="flex items-end justify-between gap-3 h-48 px-2 border-b border-[#D1D5DB] pb-2">
                {usageData.map((d: MonthlyUsage, index: number) => {
                  const val = metricView === 'units' ? d.units : d.estimatedCost;
                  const heightPercent = Math.round((val / maxVal) * 100);
                  const isSelected = index === selectedMonthIndex;

                  return (
                    <div
                      key={d.month}
                      onClick={() => setSelectedMonthIndex(index)}
                      className="flex-1 flex flex-col items-center gap-1.5 cursor-pointer group"
                    >
                      <span
                        className={`text-[11px] font-mono transition-colors ${
                          isSelected ? 'text-[#003366] font-bold' : 'text-slate-500 group-hover:text-slate-900'
                        }`}
                      >
                        {metricView === 'units' ? d.units : `${Math.round(d.estimatedCost / 1000)}k`}
                      </span>

                      <div className="w-full bg-[#F4F6F8] rounded-t h-full flex items-end border-t border-x border-[#D1D5DB]">
                        <div
                          style={{ height: `${heightPercent}%` }}
                          className={`w-full transition-all ${
                            isSelected
                              ? 'bg-[#003366]'
                              : d.isCurrent
                              ? 'bg-[#0B2545]/80'
                              : 'bg-slate-400 group-hover:bg-slate-500'
                          }`}
                        />
                      </div>

                      <span
                        className={`text-xs ${
                          isSelected ? 'text-[#003366] font-bold' : 'text-slate-600'
                        }`}
                      >
                        {d.month.slice(0, 3)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Consumption Records Table */}
          <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs space-y-3">
            <h3 className="text-sm font-bold text-[#0B2545] border-b border-[#D1D5DB] pb-2">
              Monthly Consumption Table
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#F4F6F8] text-slate-700 font-bold border-b border-[#D1D5DB]">
                    <th className="py-2.5 px-3">Billing Cycle</th>
                    <th className="py-2.5 px-3">Units (kWh)</th>
                    <th className="py-2.5 px-3">Energy Charges (PKR)</th>
                    <th className="py-2.5 px-3">Slab Category</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {usageData.map((d: MonthlyUsage) => (
                    <tr key={d.month} className="hover:bg-[#F4F6F8]/70">
                      <td className="py-2.5 px-3 font-semibold text-slate-900">
                        {d.month} 2026
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold text-[#003366]">
                        {d.units} kWh
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-800">
                        Rs. {d.estimatedCost.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        {d.units > 300 ? 'Slab 4 (301-700 Units)' : 'Slab 3 (201-300 Units)'}
                      </td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${
                            d.isCurrent
                              ? 'bg-[#F8D7DA] text-[#842029] border-[#F5C2C7]'
                              : 'bg-[#D1E7DD] text-[#0F5132] border-[#BADBCC]'
                          }`}
                        >
                          {d.isCurrent ? 'Unpaid' : 'Paid'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Two-Month Variance Audit & Appliance Calculator */}
        <div className="space-y-6">
          {/* Two-Month Variance Audit Card */}
          <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs space-y-3">
            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-4 h-4 text-[#003366]" />
              <h3 className="text-sm font-bold text-[#0B2545]">
                Two-Month Comparison Audit
              </h3>
            </div>
            <p className="text-xs text-slate-600">
              Select two billing periods to inspect percentage changes in electricity usage and expenditure.
            </p>

            <div className="space-y-2.5 pt-1">
              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                  Baseline Period (A):
                </label>
                <select
                  value={compareMonthA}
                  onChange={(e) => setCompareMonthA(Number(e.target.value))}
                  className="w-full bg-white border border-[#D1D5DB] rounded px-2.5 py-1.5 text-slate-900 text-xs focus:border-[#003366]"
                >
                  {usageData.map((d: MonthlyUsage, i: number) => (
                    <option key={d.month} value={i}>
                      {d.month} 2026 ({d.units} units)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                  Comparison Period (B):
                </label>
                <select
                  value={compareMonthB}
                  onChange={(e) => setCompareMonthB(Number(e.target.value))}
                  className="w-full bg-white border border-[#D1D5DB] rounded px-2.5 py-1.5 text-slate-900 text-xs focus:border-[#003366]"
                >
                  {usageData.map((d: MonthlyUsage, i: number) => (
                    <option key={d.month} value={i}>
                      {d.month} 2026 ({d.units} units)
                    </option>
                  ))}
                </select>
              </div>

              {/* Calculated Delta Box */}
              <div className="p-3 bg-[#F4F6F8] rounded border border-[#D1D5DB] space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Consumption Change:</span>
                  <span className={`font-mono font-bold ${unitDiff > 0 ? 'text-[#842029]' : 'text-[#0F5132]'}`}>
                    {unitDiff > 0 ? `+${unitDiff}` : unitDiff} kWh ({unitDiff > 0 ? `+${unitPct}` : unitPct}%)
                  </span>
                </div>
                <div className="flex justify-between items-center border-t border-[#D1D5DB] pt-1.5">
                  <span className="text-slate-600">Cost Variance:</span>
                  <span className={`font-mono font-bold ${costDiff > 0 ? 'text-[#842029]' : 'text-[#0F5132]'}`}>
                    {costDiff > 0 ? `+Rs. ${costDiff.toLocaleString()}` : `Rs. ${costDiff.toLocaleString()}`} ({costDiff > 0 ? `+${costPct}` : costPct}%)
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Calculator Link Card */}
          <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs space-y-3">
            <div className="flex items-center gap-2">
              <Calculator className="w-4 h-4 text-[#003366]" />
              <h3 className="text-sm font-bold text-[#0B2545]">
                Appliance Energy Calculator
              </h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Estimate the exact running cost of air conditioners, fans, refrigerators, and water pumps at current tariff rates.
            </p>
            <button
              onClick={openCalculator}
              className="w-full py-2 px-4 bg-white hover:bg-[#F4F6F8] text-[#003366] border border-[#003366] text-xs font-bold rounded transition-colors cursor-pointer"
            >
              Open Energy Calculator
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
