import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  FileText,
  CreditCard,
  Calculator,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Building,
  PlusCircle,
  FileDown,
  ArrowRight,
  BookOpen,
  HelpCircle,
  ShieldCheck,
  ChevronRight,
  Zap,
} from 'lucide-react';

export const DashboardTab: React.FC = () => {
  const {
    user,
    activeConnection,
    currentBill,
    previousBill,
    bills,
    openBillDetails,
    openAiAnalyzer,
    openPaymentModal,
    openCalculator,
    openComplaintsModal,
    openTariffsEducation,
    openAddBill,
    openPdfReport,
    setActiveTab,
    complaints,
  } = useApp();

  const isUnpaid = currentBill?.paymentStatus === 'unpaid';
  const currentUnits = currentBill?.unitsConsumed || 0;
  const prevUnits = previousBill?.unitsConsumed || 0;
  const unitDiff = currentUnits - prevUnits;
  const unitPct = prevUnits > 0 ? ((unitDiff / prevUnits) * 100).toFixed(1) : '0';
  const currentTaxes = currentBill
    ? currentBill.fcSurcharge + currentBill.electricityDuty + currentBill.tvFee + currentBill.salesTax
    : 0;

  return (
    <div className="space-y-6">
      {/* 1. Official Government Alert Notice */}
      {currentBill && (
        <div
          className={`border rounded p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
            isUnpaid
              ? 'bg-[#F8D7DA] border-[#F5C2C7] text-[#842029]'
              : 'bg-[#D1E7DD] border-[#BADBCC] text-[#0F5132]'
          }`}
        >
          <div className="flex items-start gap-3">
            <div
              className={`p-1.5 rounded mt-0.5 ${
                isUnpaid ? 'bg-[#842029] text-white' : 'bg-[#0F5132] text-white'
              }`}
            >
              {isUnpaid ? (
                <Clock className="w-4 h-4" />
              ) : (
                <CheckCircle2 className="w-4 h-4" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wide">
                  {isUnpaid ? 'Action Required: Outstanding Bill' : 'Account in Good Standing'}
                </span>
                <span className="text-[11px] font-mono opacity-80">
                  Ref: {activeConnection.referenceNumber}
                </span>
              </div>
              <p className="text-xs mt-0.5 font-medium leading-relaxed">
                {isUnpaid
                  ? `Electricity bill for ${currentBill.billingMonth} amounting to Rs. ${currentBill.totalAmount.toLocaleString()} is due on ${currentBill.dueDate}. Pay before due date to avoid a late surcharge of Rs. ${(currentBill.amountAfterDueDate - currentBill.totalAmount).toLocaleString()}.`
                  : `All billing charges for ${currentBill.billingMonth} have been cleared in full. Verified payment receipt is on record.`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
            {isUnpaid ? (
              <button
                onClick={() => openPaymentModal(currentBill)}
                className="py-1.5 px-4 bg-[#842029] hover:bg-[#681820] text-white text-xs font-bold rounded transition-colors cursor-pointer"
              >
                Pay Bill Now
              </button>
            ) : (
              <button
                onClick={() => openBillDetails(currentBill)}
                className="py-1.5 px-3 bg-white text-[#0F5132] border border-[#BADBCC] hover:bg-[#D1E7DD]/50 text-xs font-semibold rounded transition-colors cursor-pointer"
              >
                View Receipt
              </button>
            )}
            <button
              onClick={openPdfReport}
              className="py-1.5 px-3 bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 text-xs font-semibold rounded transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span>Export PDF</span>
            </button>
          </div>
        </div>
      )}

      {/* 2. Structured Boxed Consumer Particulars Section */}
      <div className="bg-white border border-[#D1D5DB] rounded p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-[#D1D5DB] pb-3 mb-4">
          <div>
            <h2 className="text-base font-bold text-[#0B2545]">
              Registered Consumer Identification
            </h2>
            <p className="text-xs text-slate-600">
              Verified record maintained by the Punjab Information Technology Board & Distribution Companies
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-500 font-medium">Utility Provider:</span>
            <span className="text-xs font-bold text-[#003366] bg-[#F4F6F8] border border-[#D1D5DB] px-2.5 py-1 rounded">
              {currentBill?.serviceProvider || activeConnection.serviceProvider}
            </span>
          </div>
        </div>

        {/* 2x4 Structured Boxed Information Table */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div className="bg-[#F4F6F8] p-3 rounded border border-[#D1D5DB]">
            <span className="text-[10px] text-slate-500 block uppercase font-semibold">Consumer Name</span>
            <span className="font-bold text-slate-900 text-xs mt-0.5 block truncate">
              {user.name}
            </span>
          </div>
          <div className="bg-[#F4F6F8] p-3 rounded border border-[#D1D5DB]">
            <span className="text-[10px] text-slate-500 block uppercase font-semibold">Account Reference</span>
            <span className="font-mono font-bold text-[#003366] text-xs mt-0.5 block">
              {activeConnection.referenceNumber}
            </span>
          </div>
          <div className="bg-[#F4F6F8] p-3 rounded border border-[#D1D5DB]">
            <span className="text-[10px] text-slate-500 block uppercase font-semibold">Meter Serial Number</span>
            <span className="font-mono font-bold text-slate-800 text-xs mt-0.5 block">
              {activeConnection.maskedMeterNumber}
            </span>
          </div>
          <div className="bg-[#F4F6F8] p-3 rounded border border-[#D1D5DB]">
            <span className="text-[10px] text-slate-500 block uppercase font-semibold">Tariff / Load</span>
            <span className="text-slate-900 font-medium text-xs mt-0.5 block">
              {activeConnection.tariff} • {activeConnection.sanctionedLoad}
            </span>
          </div>

          <div className="bg-[#F4F6F8] p-3 rounded border border-[#D1D5DB]">
            <span className="text-[10px] text-slate-500 block uppercase font-semibold">Sub-Division / Feeder</span>
            <span className="text-slate-800 font-medium text-xs mt-0.5 block truncate" title={activeConnection.subDivision}>
              {activeConnection.subDivision}
            </span>
          </div>
          <div className="bg-[#F4F6F8] p-3 rounded border border-[#D1D5DB]">
            <span className="text-[10px] text-slate-500 block uppercase font-semibold">Connection Category</span>
            <span className="text-slate-800 font-medium text-xs mt-0.5 block capitalize">
              {activeConnection.connectionType} Connection
            </span>
          </div>
          <div className="bg-[#F4F6F8] p-3 rounded border border-[#D1D5DB]">
            <span className="text-[10px] text-slate-500 block uppercase font-semibold">Registered Contact</span>
            <span className="text-slate-800 font-mono text-xs mt-0.5 block">
              {user.phone || '0300-1234567'}
            </span>
          </div>
          <div className="bg-[#F4F6F8] p-3 rounded border border-[#D1D5DB]">
            <span className="text-[10px] text-slate-500 block uppercase font-semibold">Current Billing Month</span>
            <span className="text-slate-900 font-bold text-xs mt-0.5 block">
              {currentBill?.billingMonth || 'Active'}
            </span>
          </div>
        </div>
      </div>

      {/* 3. Clearly Labeled Status Cards (No gradients, flat formal boxes) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Status Card 1: Bill Status */}
        <div className="bg-white border border-[#D1D5DB] rounded p-4">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide block">
            Billing Status
          </span>
          <div className="mt-2 flex items-center justify-between">
            <span
              className={`text-xs font-bold uppercase px-2.5 py-1 rounded border ${
                isUnpaid
                  ? 'bg-[#F8D7DA] text-[#842029] border-[#F5C2C7]'
                  : 'bg-[#D1E7DD] text-[#0F5132] border-[#BADBCC]'
              }`}
            >
              {isUnpaid ? 'Payment Due' : 'Paid in Full'}
            </span>
            <span className="text-xs text-slate-500">
              {currentBill?.billingMonth}
            </span>
          </div>
          <div className="mt-3 pt-2.5 border-t border-slate-200 text-[11px] text-slate-600">
            Due Date: <span className="font-semibold text-slate-900">{currentBill?.dueDate || 'N/A'}</span>
          </div>
        </div>

        {/* Status Card 2: Payable Amount */}
        <div className="bg-white border border-[#D1D5DB] rounded p-4">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide block">
            Net Payable (PKR)
          </span>
          <div className="mt-1 text-2xl font-bold font-mono text-[#0B2545]">
            Rs. {currentBill ? currentBill.totalAmount.toLocaleString() : '0'}
          </div>
          <div className="mt-2 pt-2.5 border-t border-slate-200 text-[11px] text-slate-600">
            {isUnpaid ? (
              <span className="text-[#842029] font-medium">
                After Due: Rs. {currentBill?.amountAfterDueDate.toLocaleString()}
              </span>
            ) : (
              <span className="text-[#0F5132] font-medium">
                No outstanding arrears
              </span>
            )}
          </div>
        </div>

        {/* Status Card 3: Electricity Usage */}
        <div className="bg-white border border-[#D1D5DB] rounded p-4">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide block">
            Electricity Consumed
          </span>
          <div className="mt-1 text-2xl font-bold font-mono text-[#003366]">
            {currentUnits} <span className="text-sm font-normal text-slate-600">kWh Units</span>
          </div>
          <div className="mt-2 pt-2.5 border-t border-slate-200 text-[11px] text-slate-600">
            <span>
              {unitDiff >= 0 ? `+${unitDiff}` : unitDiff} units ({unitPct}%) vs prev month
            </span>
          </div>
        </div>

        {/* Status Card 4: Grid Supply Status */}
        <div className="bg-white border border-[#D1D5DB] rounded p-4">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide block">
            Supply & Meter State
          </span>
          <div className="mt-2 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#0F5132] inline-block" />
            <span className="text-sm font-bold text-slate-900">Normal / Energized</span>
          </div>
          <div className="mt-3 pt-2.5 border-t border-slate-200 text-[11px] text-slate-600 truncate">
            Feeder: <span className="font-semibold text-slate-900">{activeConnection.subDivision}</span>
          </div>
        </div>
      </div>

      {/* 4. Primary Government Action Toolbar (Flat, rectangular buttons) */}
      <div className="bg-white border border-[#D1D5DB] rounded p-3.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">
            Quick Actions:
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {currentBill && isUnpaid && (
            <button
              onClick={() => openPaymentModal(currentBill)}
              className="py-2 px-4 bg-[#003366] hover:bg-[#0B2545] text-white text-xs font-bold rounded transition-colors cursor-pointer"
            >
              Pay Current Bill
            </button>
          )}

          {currentBill && (
            <button
              onClick={() => openBillDetails(currentBill)}
              className="py-2 px-3.5 bg-white hover:bg-[#F4F6F8] text-[#003366] border border-[#003366] text-xs font-semibold rounded transition-colors cursor-pointer"
            >
              View Full Statement
            </button>
          )}

          {currentBill && (
            <button
              onClick={() => openAiAnalyzer(currentBill)}
              className="py-2 px-3.5 bg-white hover:bg-[#F4F6F8] text-slate-700 border border-[#D1D5DB] text-xs font-semibold rounded transition-colors cursor-pointer"
            >
              Explain Charges (Plain Language)
            </button>
          )}

          <button
            onClick={openPdfReport}
            className="py-2 px-3.5 bg-white hover:bg-[#F4F6F8] text-slate-700 border border-[#D1D5DB] text-xs font-semibold rounded transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <FileDown className="w-3.5 h-3.5" />
            <span>Download PDF Statement</span>
          </button>

          <button
            onClick={openCalculator}
            className="py-2 px-3.5 bg-white hover:bg-[#F4F6F8] text-slate-700 border border-[#D1D5DB] text-xs font-semibold rounded transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>Appliance Calculator</span>
          </button>

          <button
            onClick={openComplaintsModal}
            className="py-2 px-3.5 bg-white hover:bg-[#F4F6F8] text-slate-700 border border-[#D1D5DB] text-xs font-semibold rounded transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-700" />
            <span>Lodge Complaint</span>
          </button>
        </div>
      </div>

      {/* 5. Main 2-Column Section: Detailed Bill Breakdown + Recent Records */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Current Bill Summary Table + Billing History Table */}
        <div className="lg:col-span-2 space-y-6">
          {/* Current Bill Breakdown Box */}
          {currentBill && (
            <div className="bg-white border border-[#D1D5DB] rounded p-5">
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-[#D1D5DB] pb-3 mb-4">
                <div>
                  <h3 className="text-sm font-bold text-[#0B2545]">
                    Current Bill Summary — {currentBill.billingMonth}
                  </h3>
                  <p className="text-xs text-slate-600">
                    Official tariff calculation based on NEPRA schedule
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">Bill ID:</span>
                  <span className="font-mono text-xs font-bold text-slate-800 bg-[#F4F6F8] px-2 py-0.5 rounded border border-[#D1D5DB]">
                    {currentBill.billId}
                  </span>
                </div>
              </div>

              {/* Simple Table Breakdown */}
              <div className="border border-[#D1D5DB] rounded overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#F4F6F8] text-slate-700 font-bold border-b border-[#D1D5DB]">
                      <th className="py-2 px-3">Description</th>
                      <th className="py-2 px-3 text-right">Calculation Detail</th>
                      <th className="py-2 px-3 text-right">Amount (PKR)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D1D5DB]">
                    <tr>
                      <td className="py-2.5 px-3 font-medium text-slate-900">
                        Cost of Electricity (Base Energy)
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-600">
                        {currentBill.unitsConsumed} Units @ Slab Tier
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-medium text-slate-900">
                        Rs. {currentBill.costOfElectricity.toLocaleString()}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-medium text-slate-900">
                        Fuel Price Adjustment (FPA)
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-600">
                        Statutory monthly variation
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-medium text-slate-900">
                        Rs. {currentBill.fuelPriceAdjustment.toLocaleString()}
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-medium text-slate-900">
                        Government Taxes, Duties & GST
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-600">
                        General Sales Tax, FC Surcharge, Electricity Duty
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-medium text-slate-900">
                        Rs. {currentTaxes.toLocaleString()}
                      </td>
                    </tr>
                    <tr className="bg-[#F4F6F8] font-bold">
                      <td className="py-2.5 px-3 text-[#0B2545]">
                        Total Amount Payable Within Due Date
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-600 text-[11px]">
                        Due by: {currentBill.dueDate}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-sm text-[#003366]">
                        Rs. {currentBill.totalAmount.toLocaleString()}
                      </td>
                    </tr>
                    <tr className="text-slate-600">
                      <td className="py-2 px-3 text-[11px]">
                        Amount Payable After Due Date (Late Surcharge)
                      </td>
                      <td className="py-2 px-3 text-right text-[11px]">
                        Late surcharge: Rs. {(currentBill.amountAfterDueDate - currentBill.totalAmount).toLocaleString()}
                      </td>
                      <td className="py-2 px-3 text-right font-mono font-medium text-slate-800 text-[11px]">
                        Rs. {currentBill.amountAfterDueDate.toLocaleString()}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Sub-actions */}
              <div className="mt-3.5 flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="text-slate-500">
                  Issue Date: <strong className="text-slate-700">{currentBill.issueDate}</strong>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openBillDetails(currentBill)}
                    className="text-[#003366] font-semibold hover:underline cursor-pointer"
                  >
                    View Complete Tax & Tariff Statement →
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Billing Statements History Table */}
          <div className="bg-white border border-[#D1D5DB] rounded p-5">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-[#D1D5DB] pb-3 mb-4">
              <div>
                <h3 className="text-sm font-bold text-[#0B2545]">
                  Verified Billing Statements History
                </h3>
                <p className="text-xs text-slate-600">
                  Past 6 months official computerized meter records
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={openAddBill}
                  className="text-xs font-semibold text-[#003366] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Add Bill Record</span>
                </button>
                <span className="text-slate-300">|</span>
                <button
                  onClick={() => setActiveTab('bills')}
                  className="text-xs font-semibold text-[#003366] hover:underline cursor-pointer"
                >
                  View All Bills ({bills.length}) →
                </button>
              </div>
            </div>

            {/* Clean Boxed Table */}
            <div className="border border-[#D1D5DB] rounded overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#F4F6F8] text-slate-700 font-bold border-b border-[#D1D5DB]">
                    <th className="py-2.5 px-3">Billing Month</th>
                    <th className="py-2.5 px-3">Units (kWh)</th>
                    <th className="py-2.5 px-3">Due Date</th>
                    <th className="py-2.5 px-3">Amount (PKR)</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#D1D5DB]">
                  {bills.slice(0, 5).map((b) => (
                    <tr key={b.billId} className="hover:bg-[#F4F6F8]/80 transition-colors">
                      <td className="py-2.5 px-3 font-semibold text-slate-900">
                        {b.billingMonth}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-medium text-[#003366]">
                        {b.unitsConsumed}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        {b.dueDate}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-900">
                        Rs. {b.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${
                            b.paymentStatus === 'unpaid'
                              ? 'bg-[#F8D7DA] text-[#842029] border-[#F5C2C7]'
                              : 'bg-[#D1E7DD] text-[#0F5132] border-[#BADBCC]'
                          }`}
                        >
                          {b.paymentStatus === 'unpaid' ? 'Payment Due' : 'Paid'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <div className="inline-flex items-center gap-2">
                          <button
                            onClick={() => openBillDetails(b)}
                            className="text-xs font-semibold text-[#003366] hover:underline cursor-pointer"
                          >
                            Statement
                          </button>
                          <span className="text-slate-300">·</span>
                          <button
                            onClick={() => openAiAnalyzer(b)}
                            className="text-xs font-semibold text-slate-600 hover:text-slate-900 hover:underline cursor-pointer"
                          >
                            Explain
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column (1 Col): Citizen Service Box, Recent Grievances, Public Notices */}
        <div className="space-y-6">
          {/* Box 1: Official PDF Export Notice */}
          <div className="bg-white border border-[#D1D5DB] rounded p-5 space-y-3">
            <div className="flex items-center gap-2">
              <FileDown className="w-5 h-5 text-[#003366]" />
              <h3 className="text-sm font-bold text-[#0B2545]">
                Export Official Statement
              </h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Generate an official, printable A4 PDF statement containing verified electricity consumption, meter readings, and tax deductions for official records or submission.
            </p>
            <button
              onClick={openPdfReport}
              className="w-full py-2 px-4 bg-[#003366] hover:bg-[#0B2545] text-white text-xs font-bold rounded flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <FileDown className="w-4 h-4" />
              <span>Download Statement (PDF)</span>
            </button>
          </div>

          {/* Box 2: Citizen Inquiries & Complaints Table */}
          <div className="bg-white border border-[#D1D5DB] rounded p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-[#D1D5DB] pb-3">
              <div>
                <h3 className="text-sm font-bold text-[#0B2545]">
                  Citizen Grievances & Tickets
                </h3>
                <p className="text-xs text-slate-500">
                  Track ongoing consumer complaints
                </p>
              </div>
              <button
                onClick={openComplaintsModal}
                className="text-xs font-semibold text-[#003366] hover:underline cursor-pointer"
              >
                Log New +
              </button>
            </div>

            {complaints.length === 0 ? (
              <p className="text-xs text-slate-500 py-3 text-center">
                No active complaints filed on this account.
              </p>
            ) : (
              <div className="border border-[#D1D5DB] rounded overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#F4F6F8] text-slate-700 font-bold border-b border-[#D1D5DB]">
                      <th className="py-2 px-2.5">Ticket</th>
                      <th className="py-2 px-2.5">Category</th>
                      <th className="py-2 px-2.5 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D1D5DB]">
                    {complaints.slice(0, 3).map((c) => (
                      <tr
                        key={c.complaintId}
                        onClick={openComplaintsModal}
                        className="hover:bg-[#F4F6F8] cursor-pointer transition-colors"
                      >
                        <td className="py-2 px-2.5 font-mono font-bold text-[#003366] text-[11px]">
                          {c.complaintId}
                        </td>
                        <td className="py-2 px-2.5 text-slate-700 text-[11px] truncate max-w-[120px]">
                          {c.category}
                        </td>
                        <td className="py-2 px-2.5 text-right">
                          <span
                            className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded border ${
                              c.status === 'Resolved'
                                ? 'bg-[#D1E7DD] text-[#0F5132] border-[#BADBCC]'
                                : c.status === 'Assigned' || c.status === 'Under Review'
                                ? 'bg-[#CFF4FC] text-[#055160] border-[#B6EFFB]'
                                : 'bg-[#FFF3CD] text-[#664D03] border-[#FFECB5]'
                            }`}
                          >
                            {c.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <button
              onClick={openComplaintsModal}
              className="w-full py-2 px-3 bg-white text-slate-700 border border-[#D1D5DB] hover:bg-[#F4F6F8] text-xs font-semibold rounded transition-colors cursor-pointer text-center"
            >
              View All Grievances & Track Status
            </button>
          </div>

          {/* Box 3: Public Consumer Services Directory */}
          <div className="bg-white border border-[#D1D5DB] rounded p-5 space-y-3">
            <h3 className="text-sm font-bold text-[#0B2545] border-b border-[#D1D5DB] pb-2">
              Official Consumer Services
            </h3>

            <div className="space-y-2 text-xs">
              <button
                onClick={openCalculator}
                className="w-full text-left p-2.5 rounded border border-[#D1D5DB] hover:bg-[#F4F6F8] transition-colors flex items-center justify-between cursor-pointer"
              >
                <div>
                  <span className="font-bold text-slate-900 block">Appliance Energy Calculator</span>
                  <span className="text-[11px] text-slate-500">Estimate monthly kWh consumption</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              </button>

              <button
                onClick={openTariffsEducation}
                className="w-full text-left p-2.5 rounded border border-[#D1D5DB] hover:bg-[#F4F6F8] transition-colors flex items-center justify-between cursor-pointer"
              >
                <div>
                  <span className="font-bold text-slate-900 block">NEPRA Statutory Tariff Schedule</span>
                  <span className="text-[11px] text-slate-500">Official rate slabs & protected categories</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              </button>

              <div className="p-3 bg-[#F4F6F8] border border-[#D1D5DB] rounded text-xs space-y-1">
                <span className="font-bold text-[#003366] block">Emergency Utility Helpline</span>
                <p className="text-slate-600 text-[11px]">
                  For broken power lines, transformer faults, or sparks:
                </p>
                <div className="font-mono font-bold text-slate-900 pt-0.5">
                  Toll-Free: 118 | WhatsApp: 0311-118118
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
