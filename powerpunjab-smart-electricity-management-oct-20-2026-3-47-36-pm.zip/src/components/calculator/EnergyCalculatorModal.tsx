import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { APPLIANCE_PRESETS } from '../../services/dataService';
import { AppliancePreset } from '../../types';
import {
  X,
  Calculator,
  Plus,
  Trash2,
  Lightbulb,
} from 'lucide-react';

interface AuditItem {
  id: string;
  name: string;
  watts: number;
  hours: number;
  qty: number;
  days: number;
}

export const EnergyCalculatorModal: React.FC = () => {
  const { isCalculatorOpen, closeCalculator } = useApp();

  const [selectedPreset, setSelectedPreset] = useState<AppliancePreset>(APPLIANCE_PRESETS[4]); // AC 1.5T
  const [applianceName, setApplianceName] = useState('Inverter AC 1.5 Ton');
  const [powerWatts, setPowerWatts] = useState<number>(1800);
  const [hoursPerDay, setHoursPerDay] = useState<number>(8);
  const [quantity, setQuantity] = useState<number>(1);
  const [days, setDays] = useState<number>(30);
  const [ratePerKwh, setRatePerKwh] = useState<number>(24);

  const [householdAudit, setHouseholdAudit] = useState<AuditItem[]>([
    { id: '1', name: 'Inverter AC 1.5 Ton', watts: 1800, hours: 8, qty: 1, days: 30 },
    { id: '2', name: 'Ceiling Fan', watts: 75, hours: 14, qty: 4, days: 30 },
    { id: '3', name: 'Refrigerator', watts: 250, hours: 8, qty: 1, days: 30 },
    { id: '4', name: 'LED Bulbs', watts: 12, hours: 6, qty: 6, days: 30 },
  ]);

  const [errorMsg, setErrorMsg] = useState('');

  if (!isCalculatorOpen) return null;

  const calculateSingle = (w: number, h: number, q: number, d: number, r: number) => {
    const dailyKwh = (w * h * q) / 1000;
    const periodKwh = dailyKwh * d;
    const cost = periodKwh * r;
    return {
      dailyKwh: Number(dailyKwh.toFixed(2)),
      periodKwh: Number(periodKwh.toFixed(1)),
      cost: Math.round(cost),
    };
  };

  const currentCalc = calculateSingle(powerWatts, hoursPerDay, quantity, days, ratePerKwh);

  const householdTotalUnits = householdAudit.reduce((acc, item) => {
    return acc + (item.watts * item.hours * item.qty * item.days) / 1000;
  }, 0);
  const householdTotalCost = Math.round(householdTotalUnits * ratePerKwh);

  const handleSelectPreset = (preset: AppliancePreset) => {
    setSelectedPreset(preset);
    setApplianceName(preset.name);
    setPowerWatts(preset.defaultWatts);
    setHoursPerDay(preset.defaultHours);
    setErrorMsg('');
  };

  const handleAddCurrentToAudit = () => {
    if (powerWatts <= 0) {
      setErrorMsg('Power rating must be greater than zero.');
      return;
    }
    if (hoursPerDay <= 0 || hoursPerDay > 24) {
      setErrorMsg('Daily usage hours must be between 1 and 24.');
      return;
    }
    if (quantity <= 0) {
      setErrorMsg('Quantity must be at least 1.');
      return;
    }

    setHouseholdAudit([
      ...householdAudit,
      {
        id: Date.now().toString(),
        name: applianceName,
        watts: powerWatts,
        hours: hoursPerDay,
        qty: quantity,
        days: days,
      },
    ]);
    setErrorMsg('');
  };

  const handleRemoveAuditItem = (id: string) => {
    setHouseholdAudit(householdAudit.filter((item) => item.id !== id));
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-white border border-[#D1D5DB] w-full max-w-md rounded-md shadow-xl overflow-hidden flex flex-col max-h-[92vh] text-[#1D2A44]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#D1D5DB] bg-[#F4F6F8]">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#003366] text-xs uppercase tracking-wide">
              Appliance Consumption Calculator
            </span>
          </div>
          <button
            onClick={closeCalculator}
            className="p-1 rounded text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-5 space-y-4 bg-white text-xs">
          {/* Preset Buttons */}
          <div>
            <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block mb-1.5">
              Standard Appliance Presets:
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {APPLIANCE_PRESETS.map((preset) => {
                const isSelected = selectedPreset.id === preset.id;
                return (
                  <button
                    key={preset.id}
                    onClick={() => handleSelectPreset(preset)}
                    className={`p-2 rounded border text-center transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#003366] text-white border-[#003366] font-bold'
                        : 'bg-[#F4F6F8] hover:bg-slate-200 text-slate-800 border-[#D1D5DB]'
                    }`}
                  >
                    <span className="text-[10px] block truncate">{preset.name.split(' ')[0]}</span>
                    <span className={`text-[9px] font-mono ${isSelected ? 'text-slate-200' : 'text-slate-500'}`}>
                      {preset.defaultWatts}W
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Input Controls */}
          <div className="bg-[#F4F6F8] p-3.5 rounded border border-[#D1D5DB] space-y-3">
            <span className="text-xs font-bold text-[#0B2545] block border-b border-[#D1D5DB] pb-1.5">
              Appliance Specifications
            </span>

            {errorMsg && (
              <div className="p-2 rounded bg-[#F8D7DA] border border-[#F5C2C7] text-[#842029]">
                {errorMsg}
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">Appliance Name</label>
              <input
                type="text"
                value={applianceName}
                onChange={(e) => setApplianceName(e.target.value)}
                className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-xs text-slate-900 focus:border-[#003366]"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Power Rating (Watts)</label>
                <input
                  type="number"
                  min="1"
                  max="10000"
                  value={powerWatts}
                  onChange={(e) => setPowerWatts(Number(e.target.value))}
                  className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-xs font-mono text-slate-900 focus:border-[#003366]"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Daily Usage (Hours)</label>
                <input
                  type="number"
                  min="0.5"
                  max="24"
                  step="0.5"
                  value={hoursPerDay}
                  onChange={(e) => setHoursPerDay(Number(e.target.value))}
                  className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-xs font-mono text-slate-900 focus:border-[#003366]"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Quantity</label>
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-xs font-mono text-slate-900 focus:border-[#003366]"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Tariff Rate (Rs./kWh)</label>
                <input
                  type="number"
                  min="10"
                  max="80"
                  value={ratePerKwh}
                  onChange={(e) => setRatePerKwh(Number(e.target.value))}
                  className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-xs font-mono text-slate-900 focus:border-[#003366]"
                />
              </div>
            </div>

            <button
              onClick={handleAddCurrentToAudit}
              className="w-full py-1.5 px-3 bg-white hover:bg-slate-100 text-[#003366] font-bold text-xs rounded border border-[#003366] transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add to Household Audit</span>
            </button>
          </div>

          {/* Results Box */}
          <div className="p-3.5 rounded bg-white border border-[#D1D5DB] space-y-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-600 block">
              Estimated Usage for {quantity}x {applianceName}
            </span>
            <div className="grid grid-cols-3 gap-2 text-center pt-1">
              <div className="p-2 rounded bg-[#F4F6F8] border border-[#D1D5DB]">
                <span className="text-[9px] text-slate-500 block font-medium">Daily Units</span>
                <span className="font-mono text-sm font-bold text-slate-900">{currentCalc.dailyKwh} kWh</span>
              </div>
              <div className="p-2 rounded bg-[#F4F6F8] border border-[#D1D5DB]">
                <span className="text-[9px] text-slate-500 block font-medium">Monthly Units</span>
                <span className="font-mono text-sm font-bold text-[#003366]">{currentCalc.periodKwh} kWh</span>
              </div>
              <div className="p-2 rounded bg-[#F4F6F8] border border-[#D1D5DB]">
                <span className="text-[9px] text-slate-500 block font-medium">Monthly Cost</span>
                <span className="font-mono text-sm font-bold text-slate-900">Rs. {currentCalc.cost.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Household Audit List */}
          <div className="bg-[#F4F6F8] p-3.5 rounded border border-[#D1D5DB] space-y-2">
            <div className="flex items-center justify-between border-b border-[#D1D5DB] pb-1.5">
              <span className="font-bold text-[#0B2545]">Whole Household Audit</span>
              <span className="font-mono font-bold text-slate-900">
                Rs. {householdTotalCost.toLocaleString()} ({Math.round(householdTotalUnits)} kWh)
              </span>
            </div>

            <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
              {householdAudit.map((item) => {
                const subCalc = calculateSingle(item.watts, item.hours, item.qty, item.days, ratePerKwh);
                return (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-2 rounded bg-white border border-[#D1D5DB] text-xs"
                  >
                    <div>
                      <div className="font-semibold text-slate-900">{item.qty}x {item.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        {item.watts}W • {item.hours}h/day • {subCalc.periodKwh} kWh
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-900">Rs. {subCalc.cost.toLocaleString()}</span>
                      <button
                        onClick={() => handleRemoveAuditItem(item.id)}
                        className="p-1 text-slate-400 hover:text-[#842029] transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#D1D5DB] bg-[#F4F6F8] flex justify-end">
          <button
            onClick={closeCalculator}
            className="py-1.5 px-4 rounded bg-[#003366] hover:bg-[#0B2545] text-white font-bold text-xs transition-colors cursor-pointer shadow-none"
          >
            Close Calculator
          </button>
        </div>
      </div>
    </div>
  );
};
