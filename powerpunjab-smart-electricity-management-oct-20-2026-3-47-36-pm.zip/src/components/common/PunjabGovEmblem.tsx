import React from 'react';

interface PunjabGovEmblemProps {
  size?: number;
  className?: string;
  showBadgeText?: boolean;
}

export const PunjabGovEmblem: React.FC<PunjabGovEmblemProps> = ({
  size = 48,
  className = '',
}) => {
  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 ${className}`}
      style={{ width: size, height: size }}
      title="Official Seal - Government of Punjab"
    >
      <svg
        viewBox="0 0 100 100"
        width={size}
        height={size}
        className="w-full h-full select-none"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="Government of Punjab Official Emblem"
      >
        <defs>
          {/* Subtle gold gradient for laurel / wheat wreath */}
          <linearGradient id="gopGold" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F59E0B" />
            <stop offset="50%" stopColor="#D97706" />
            <stop offset="100%" stopColor="#B45309" />
          </linearGradient>

          {/* Deep Navy / Slate gradient for official seal rim */}
          <linearGradient id="gopNavy" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#003366" />
            <stop offset="100%" stopColor="#0B2545" />
          </linearGradient>

          {/* Official Punjab Green */}
          <linearGradient id="gopGreen" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#065F46" />
            <stop offset="100%" stopColor="#022C22" />
          </linearGradient>
        </defs>

        {/* Outer Circular Rim */}
        <circle cx="50" cy="50" r="48" fill="url(#gopNavy)" stroke="#D97706" strokeWidth="1.5" />
        <circle cx="50" cy="50" r="45" fill="none" stroke="#FFFFFF" strokeWidth="0.75" strokeDasharray="1.5 1.5" opacity="0.6" />

        {/* Inner Green Roundel */}
        <circle cx="50" cy="50" r="41" fill="url(#gopGreen)" stroke="#D97706" strokeWidth="1" />

        {/* Star & Crescent at Top (National & Provincial Emblem) */}
        {/* Crescent */}
        <path
          d="M 52 14 A 8 8 0 1 0 52 30 A 6.5 6.5 0 1 1 52 14 Z"
          fill="#FFFFFF"
        />
        {/* Five-Pointed Star */}
        <polygon
          points="54,18 55.2,21.5 59,21.5 56,23.5 57.2,27 54,25 50.8,27 52,23.5 49,21.5 52.8,21.5"
          fill="#F59E0B"
        />

        {/* Five River Waves Motif (Panj-Aab / Punjab: Jhelum, Chenab, Ravi, Sutlej, Beas) */}
        <g stroke="#FFFFFF" strokeWidth="1.4" fill="none" strokeLinecap="round" opacity="0.95">
          <path d="M 30 38 Q 40 35 50 38 T 70 38" />
          <path d="M 28 43 Q 39 40 50 43 T 72 43" />
          <path d="M 26 48 Q 38 45 50 48 T 74 48" />
          <path d="M 28 53 Q 39 50 50 53 T 72 53" />
          <path d="M 30 58 Q 40 55 50 58 T 70 58" />
        </g>

        {/* Left Wheat Stalk (Agriculture of Punjab) */}
        <g fill="url(#gopGold)" opacity="0.95">
          <path d="M 20 62 Q 17 48 24 34 Q 21 44 22 58 Z" />
          <ellipse cx="19" cy="38" rx="2.2" ry="1.2" transform="rotate(-30 19 38)" />
          <ellipse cx="17" cy="45" rx="2.4" ry="1.3" transform="rotate(-25 17 45)" />
          <ellipse cx="16" cy="52" rx="2.5" ry="1.4" transform="rotate(-15 16 52)" />
          <ellipse cx="18" cy="59" rx="2.5" ry="1.4" transform="rotate(-5 18 59)" />
        </g>

        {/* Right Wheat Stalk */}
        <g fill="url(#gopGold)" opacity="0.95">
          <path d="M 80 62 Q 83 48 76 34 Q 79 44 78 58 Z" />
          <ellipse cx="81" cy="38" rx="2.2" ry="1.2" transform="rotate(30 81 38)" />
          <ellipse cx="83" cy="45" rx="2.4" ry="1.3" transform="rotate(25 83 45)" />
          <ellipse cx="84" cy="52" rx="2.5" ry="1.4" transform="rotate(15 84 52)" />
          <ellipse cx="82" cy="59" rx="2.5" ry="1.4" transform="rotate(5 82 59)" />
        </g>

        {/* Lower Official Ribbon / Plaque */}
        <path
          d="M 18 69 L 26 66 L 74 66 L 82 69 L 76 81 L 24 81 Z"
          fill="url(#gopNavy)"
          stroke="#D97706"
          strokeWidth="1"
        />

        {/* Inscription on Ribbon */}
        <text
          x="50"
          y="74"
          textAnchor="middle"
          fill="#FFFFFF"
          fontSize="5.2"
          fontWeight="bold"
          fontFamily="system-ui, -apple-system, sans-serif"
          letterSpacing="0.4"
        >
          GOVT OF PUNJAB
        </text>
        <text
          x="50"
          y="79"
          textAnchor="middle"
          fill="#F59E0B"
          fontSize="4.2"
          fontWeight="bold"
          fontFamily="system-ui, -apple-system, sans-serif"
          letterSpacing="0.6"
        >
          حکومت پنجاب
        </text>

        {/* Subtle base star */}
        <polygon
          points="50,86 51,89 54,89 51.5,91 52.5,94 50,92 47.5,94 48.5,91 46,89 49,89"
          fill="#F59E0B"
        />
      </svg>
    </div>
  );
};
