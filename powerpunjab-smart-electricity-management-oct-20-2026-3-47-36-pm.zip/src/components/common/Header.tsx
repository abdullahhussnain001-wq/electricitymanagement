import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { TabType } from '../../types';
import { PunjabGovEmblem } from './PunjabGovEmblem';
import {
  Building2,
  ChevronDown,
  Bell,
  Check,
  LogOut,
  FileDown,
  ShieldCheck,
  Phone,
  Menu,
  X,
  ExternalLink,
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    activeConnection,
    connections,
    switchConnection,
    unreadNotificationsCount,
    openNotificationsModal,
    openPdfReport,
    activeTab,
    setActiveTab,
    logout,
    complaints,
  } = useApp();

  const [isConnDropdownOpen, setIsConnDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsConnDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const openComplaintsCount = complaints.filter(
    (c) => c.status !== 'Resolved'
  ).length;

  const navLinks: { id: TabType; label: string; badge?: number }[] = [
    { id: 'home', label: 'Overview' },
    { id: 'bills', label: 'Bills & Payments' },
    { id: 'usage', label: 'Usage Records' },
    { id: 'ai', label: 'Bill Explainer' },
    { id: 'profile', label: 'Consumer Profile' },
  ];

  return (
    <header className="bg-white border-b border-[#D1D5DB] text-[#1D2A44] sticky top-0 z-40 shadow-sm no-print">
      {/* 1. Official Government Top Utility Ribbon */}
      <div className="bg-[#0B2545] text-white text-xs py-1.5 px-4 sm:px-6 border-b border-[#003366]">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[#F59E0B] font-bold text-xs select-none">★</span>
            <span className="font-semibold tracking-wider text-[11px] sm:text-xs">
              GOVERNMENT OF THE PUNJAB • ENERGY & POWER DEVELOPMENT DEPARTMENT
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-4 text-[11px] text-slate-300">
            <span className="flex items-center gap-1">
              <Phone className="w-3 h-3 text-[#F59E0B]" />
              <span>Consumer Helpline: <strong>118</strong> (24/7 Outages)</span>
            </span>
            <span>•</span>
            <span>NEPRA Approved</span>
            <span>•</span>
            <span className="bg-emerald-800 text-emerald-100 font-bold px-1.5 py-0.5 rounded text-[10px] tracking-wide inline-flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              OFFICIAL SYSTEM
            </span>
          </div>
        </div>
      </div>

      {/* 2. Main Title & Identity Bar */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3 sm:py-3.5 flex items-center justify-between gap-3 sm:gap-6">
        {/* Brand & Official Title with Punjab Government Placeholder Emblem */}
        <div className="flex items-center gap-3 sm:gap-4 min-w-0">
          {/* Government of Punjab Official Placeholder Emblem */}
          <PunjabGovEmblem size={48} className="drop-shadow-sm" />

          {/* Titles in Specified Navy Blue Theme */}
          <div className="min-w-0">
            <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap">
              <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-[#0B2545]">
                Roshan Punjab
              </span>
              <div className="hidden xs:inline-flex items-center px-2.5 py-0.5 rounded border border-[#003366] bg-[#F4F6F8] text-[#003366] font-bold text-[11px] sm:text-xs tracking-wide uppercase">
                Official Electricity Consumer Portal
              </div>
            </div>
            {/* Mobile-visible prominent title if screen is narrow */}
            <div className="xs:hidden text-[11px] font-bold text-[#003366] uppercase tracking-wide">
              Official Electricity Consumer Portal
            </div>
            <p className="text-[11px] sm:text-xs text-slate-600 font-medium truncate">
              Power Information Technology Company (PITC) • DISCOs Unified Services
            </p>
          </div>
        </div>

        {/* Right Tools: Connection Switcher, Export PDF, Notifications, Sign Out */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Electricity Connection Selector */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setIsConnDropdownOpen(!isConnDropdownOpen)}
              className="flex items-center gap-1.5 text-xs bg-[#F4F6F8] hover:bg-slate-200 text-[#1D2A44] px-2.5 sm:px-3 py-1.5 rounded border border-[#D1D5DB] font-medium transition-colors cursor-pointer"
              title="Switch electricity connection"
            >
              <Building2 className="w-3.5 h-3.5 text-[#003366] shrink-0" />
              <div className="text-left hidden md:block">
                <span className="text-[10px] text-slate-500 block leading-tight">Consumer Account:</span>
                <span className="font-bold text-slate-900 truncate max-w-[140px] block">
                  {activeConnection.displayName}
                </span>
              </div>
              <div className="md:hidden font-bold text-slate-900">
                {activeConnection.displayName.split(' ')[0]}
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 ml-0.5" />
            </button>

            {isConnDropdownOpen && (
              <div className="absolute right-0 mt-1.5 w-72 bg-white rounded border border-[#D1D5DB] shadow-lg p-2 z-50">
                <div className="px-2 py-1 text-[11px] font-bold text-slate-600 uppercase border-b border-slate-100 flex items-center justify-between">
                  <span>Registered Connections</span>
                  <span className="text-[10px] font-normal text-slate-500">{connections.length} total</span>
                </div>
                <div className="space-y-1 mt-1">
                  {connections.map((conn) => {
                    const isSelected = conn.connectionId === activeConnection.connectionId;
                    return (
                      <button
                        key={conn.connectionId}
                        onClick={() => {
                          switchConnection(conn.connectionId);
                          setIsConnDropdownOpen(false);
                        }}
                        className={`w-full text-left p-2 rounded text-xs transition-colors cursor-pointer flex items-center justify-between ${
                          isSelected
                            ? 'bg-[#F4F6F8] border border-[#003366] text-[#003366] font-bold'
                            : 'hover:bg-[#F4F6F8] text-[#1D2A44]'
                        }`}
                      >
                        <div>
                          <div className="font-bold">{conn.displayName}</div>
                          <div className="text-[10px] text-slate-500 font-mono">
                            Ref: {conn.referenceNumber}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            {conn.serviceProvider || 'LESCO'}
                          </div>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-[#003366]" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Export PDF Report */}
          <button
            onClick={openPdfReport}
            className="flex items-center gap-1.5 text-xs bg-white hover:bg-[#F4F6F8] text-[#003366] border border-[#003366] px-2.5 sm:px-3 py-1.5 rounded font-semibold transition-colors cursor-pointer shadow-none"
            title="Export Monthly Usage & Billing Summary PDF"
          >
            <FileDown className="w-3.5 h-3.5 text-[#003366]" />
            <span className="hidden sm:inline">Export PDF</span>
          </button>

          {/* Notifications */}
          <button
            onClick={openNotificationsModal}
            className="relative p-2 rounded bg-[#F4F6F8] hover:bg-slate-200 border border-[#D1D5DB] text-slate-700 transition-colors cursor-pointer"
            title="Official Notifications & Alerts"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#842029] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* User Sign Out */}
          <button
            onClick={logout}
            className="flex items-center gap-1.5 text-xs bg-[#F4F6F8] hover:bg-[#F8D7DA] text-slate-700 hover:text-[#842029] border border-[#D1D5DB] px-2.5 py-1.5 rounded font-medium transition-colors cursor-pointer"
            title="Log out of portal"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="sm:hidden p-2 rounded border border-[#D1D5DB] text-slate-700 hover:bg-slate-100"
            aria-label="Toggle navigation menu"
          >
            {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* 3. Primary Government Navigation Bar in Navy Blue Theme */}
      <nav className="bg-[#003366] text-white border-t border-[#002244]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex items-center justify-between">
          <div className="hidden sm:flex items-center space-x-1">
            {navLinks.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-2.5 text-xs font-semibold tracking-wide transition-colors cursor-pointer border-b-2 flex items-center gap-1.5 ${
                    isActive
                      ? 'border-[#F59E0B] bg-[#0B2545] text-white'
                      : 'border-transparent text-slate-200 hover:bg-[#0B2545]/60 hover:text-white'
                  }`}
                >
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="bg-[#F59E0B] text-[#0B2545] font-bold text-[10px] px-1.5 py-0.2 rounded-full">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="hidden md:flex items-center text-[11px] text-slate-300 gap-3 py-2">
            <span>Punjab DISCOs: LESCO • GEPCO • FESCO • IESCO • MEPCO</span>
          </div>
        </div>

        {/* Mobile dropdown navigation */}
        {isMobileMenuOpen && (
          <div className="sm:hidden border-t border-[#0B2545] bg-[#0B2545] p-2 space-y-1">
            {navLinks.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs font-semibold rounded flex items-center justify-between ${
                    isActive
                      ? 'bg-white text-[#003366]'
                      : 'text-slate-200 hover:bg-[#003366]'
                  }`}
                >
                  <span>{tab.label}</span>
                  {isActive && <Check className="w-3.5 h-3.5 text-[#003366]" />}
                </button>
              );
            })}
          </div>
        )}
      </nav>
    </header>
  );
};
