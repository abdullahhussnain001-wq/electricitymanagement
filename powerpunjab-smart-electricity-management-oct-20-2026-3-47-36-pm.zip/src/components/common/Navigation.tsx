import React from 'react';
import { useApp } from '../../context/AppContext';
import { TabType } from '../../types';
import { LayoutDashboard, FileText, BarChart2, MessageSquare, User } from 'lucide-react';

interface NavItem {
  id: TabType;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
}

export const Navigation: React.FC = () => {
  const { activeTab, setActiveTab, bills } = useApp();

  const unpaidCount = bills.filter((b) => b.paymentStatus === 'unpaid').length;

  const navItems: NavItem[] = [
    { id: 'home', label: 'Overview', icon: LayoutDashboard },
    { id: 'bills', label: 'Bills', icon: FileText, badge: unpaidCount > 0 ? unpaidCount : undefined },
    { id: 'usage', label: 'Usage', icon: BarChart2 },
    { id: 'ai', label: 'Explainer', icon: MessageSquare },
    { id: 'profile', label: 'Account', icon: User },
  ];

  return (
    <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#D1D5DB] pb-[env(safe-area-inset-bottom,0px)]">
      <div className="flex items-center justify-around py-1.5">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-3 text-xs font-semibold transition-colors cursor-pointer ${
                isActive
                  ? 'text-[#003366]'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <div className="relative">
                <Icon className="w-4 h-4" />
                {item.badge !== undefined && (
                  <span className="absolute -top-1 -right-2 min-w-[14px] h-3.5 px-0.5 rounded-full bg-[#842029] text-white text-[9px] font-bold flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 font-medium">
                {item.label}
              </span>
              {isActive && (
                <div className="w-4 h-0.5 bg-[#003366] mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
