import React from 'react';
import { useApp } from '../../context/AppContext';
import { PunjabGovEmblem } from './PunjabGovEmblem';
import { Building, Phone, Mail, ShieldCheck, ExternalLink, BookOpen } from 'lucide-react';

export const Footer: React.FC = () => {
  const { openTariffsEducation, openPdfReport } = useApp();

  return (
    <footer className="bg-[#0B2545] text-slate-300 text-xs mt-12 border-t-4 border-[#003366] no-print">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 pb-8 border-b border-slate-700">
          {/* Col 1: Government Authority */}
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <PunjabGovEmblem size={32} />
              <div>
                <span className="font-extrabold text-white tracking-wide text-sm block">
                  Roshan Punjab
                </span>
                <span className="text-[10px] text-[#F59E0B] font-bold block">
                  Official Electricity Consumer Portal
                </span>
              </div>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Energy & Power Development Department • Power Information Technology Company (PITC), Government of the Punjab.
            </p>
          </div>

          {/* Col 2: Consumer Services */}
          <div className="space-y-2">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              Consumer Services
            </h4>
            <ul className="space-y-1.5 text-[11px]">
              <li>
                <button
                  onClick={openPdfReport}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Download Billing Statement (PDF)
                </button>
              </li>
              <li>
                <button
                  onClick={openTariffsEducation}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  NEPRA Approved Tariff Slabs
                </button>
              </li>
              <li>
                <span className="text-slate-400">Electricity Sub-Division Directory</span>
              </li>
              <li>
                <span className="text-slate-400">New Connection Application Form</span>
              </li>
            </ul>
          </div>

          {/* Col 3: Assistance & Contact */}
          <div className="space-y-2">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              Emergency & Support
            </h4>
            <div className="space-y-1 text-[11px]">
              <div className="flex items-center gap-2 text-slate-200">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Helpline: <strong>118</strong> (24/7 Outages)</span>
              </div>
              <div className="flex items-center gap-2 text-slate-200">
                <Phone className="w-3.5 h-3.5 text-blue-400" />
                <span>Toll-Free: <strong>0800-00118</strong></span>
              </div>
              <div className="flex items-center gap-2 text-slate-200">
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                <span>support@power.punjab.gov.pk</span>
              </div>
            </div>
          </div>

          {/* Col 4: Standards & Security */}
          <div className="space-y-2">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              Compliance & Notice
            </h4>
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Certified NEPRA Regulatory Standards</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed">
              Demonstration prototype designed for Punjab consumers to audit bills, verify slabs, and track electricity transactions securely.
            </p>
          </div>
        </div>

        {/* Bottom copyright row */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-400">
          <div>
            © {new Date().getFullYear()} Government of Punjab • All Rights Reserved.
          </div>
          <div className="flex gap-4">
            <span className="hover:text-slate-200 cursor-pointer">Privacy Statement</span>
            <span>•</span>
            <span className="hover:text-slate-200 cursor-pointer">Terms of Service</span>
            <span>•</span>
            <span className="hover:text-slate-200 cursor-pointer">Accessibility</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
