import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PunjabGovEmblem } from '../common/PunjabGovEmblem';
import {
  Lock,
  Mail,
  User,
  Phone,
  Eye,
  EyeOff,
  Building,
  KeyRound,
  ShieldCheck,
  Check,
  Copy,
  AlertCircle,
} from 'lucide-react';

export const LoginModal: React.FC = () => {
  const { loginAsDemo, loginUser, loginWithGoogleAuth } = useApp();

  const [mode, setMode] = useState<'login' | 'register' | 'recovery'>('login');

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [provider, setProvider] = useState('LESCO (Lahore Electric Supply Company)');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Recovery states
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoveryStep, setRecoveryStep] = useState<1 | 2>(1);
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');

  // UI state
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [copied, setCopied] = useState(false);

  const handleAutofillDemo = () => {
    setEmail('demo@roshanpunjab.gov.pk');
    setPassword('Demo123!');
    setErrorMessage('');
    setSuccessMessage('Demo credentials filled. Click "Sign In" to proceed.');
  };

  const handleCopyCredentials = () => {
    navigator.clipboard.writeText('Email: demo@roshanpunjab.gov.pk | Password: Demo123!');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!email.trim() || !password.trim()) {
      setErrorMessage('Please enter both email and password.');
      return;
    }

    if (
      (email.trim().toLowerCase() === 'demo@roshanpunjab.gov.pk' ||
        email.trim().toLowerCase() === 'demo@powerpunjab.demo') &&
      password.trim() === 'Demo123!'
    ) {
      loginAsDemo();
      return;
    }

    loginUser(email.trim(), email.split('@')[0]);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!name.trim() || !email.trim() || !password.trim()) {
      setErrorMessage('Full name, email, and password are required.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage('Password confirmation does not match.');
      return;
    }

    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    loginUser(email.trim(), name.trim());
  };

  const handleRecoverySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (recoveryStep === 1) {
      if (!recoveryEmail.trim()) {
        setErrorMessage('Please enter your registered email address.');
        return;
      }
      setRecoveryStep(2);
      setSuccessMessage('A 6-digit verification code has been dispatched to ' + recoveryEmail);
    } else {
      if (!resetCode.trim() || !newPassword.trim()) {
        setErrorMessage('Please enter both the reset code and new password.');
        return;
      }
      setSuccessMessage('Password successfully updated. You may now sign in.');
      setEmail(recoveryEmail);
      setPassword(newPassword);
      setMode('login');
      setRecoveryStep(1);
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F6F8] flex flex-col justify-between text-[#1D2A44]">
      {/* Top Government Ribbon */}
      <div className="bg-[#0B2545] text-white text-xs py-2 px-4 border-b border-[#003366]">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-bold">GOVERNMENT OF THE PUNJAB</span>
            <span>•</span>
            <span className="text-slate-300">Energy & Power Development Department</span>
          </div>
          <div className="text-[11px] text-slate-300 hidden sm:block">
            Official Electricity Consumer Authentication System
          </div>
        </div>
      </div>

      {/* Main Login Card Area */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-6 my-4">
        <div className="w-full max-w-lg space-y-4">
          {/* Header Title with Official Punjab Government Emblem */}
          <div className="text-center space-y-1.5 flex flex-col items-center">
            <PunjabGovEmblem size={64} className="mb-1 drop-shadow-md" />
            <h1 className="text-2xl font-black tracking-tight text-[#0B2545]">
              Roshan Punjab
            </h1>
            <div className="inline-block px-3 py-0.5 rounded border border-[#003366] bg-white text-[#003366] text-xs font-bold uppercase tracking-wider">
              Official Electricity Consumer Portal
            </div>
            <p className="text-xs text-slate-600 max-w-md pt-0.5">
              Unified digital electricity portal under Government of Punjab Energy Department & Power Information Technology Company (PITC)
            </p>
          </div>

          {/* Demonstration Access Banner (Requested by User) */}
          <div className="bg-white border-2 border-[#003366] rounded-md p-4 space-y-2.5 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-[#003366]" />
                <span className="text-xs font-bold text-[#003366] uppercase tracking-wide">
                  Demonstration Access Credentials
                </span>
              </div>
              <button
                type="button"
                onClick={handleCopyCredentials}
                className="text-[11px] text-slate-600 hover:text-[#003366] flex items-center gap-1 font-semibold cursor-pointer"
                title="Copy demo credentials"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <p className="text-xs text-slate-600">
              You can manually enter the credentials below to test all portal features:
            </p>

            <div className="bg-[#F4F6F8] border border-[#D1D5DB] rounded p-2.5 font-mono text-xs space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-slate-600 font-sans font-semibold">User Email:</span>
                <span className="text-[#0B2545] font-bold select-all">demo@roshanpunjab.gov.pk</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600 font-sans font-semibold">Password:</span>
                <span className="text-[#0B2545] font-bold select-all">Demo123!</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] text-slate-500">
                Pre-configured with LESCO residential meter records.
              </span>
              <button
                type="button"
                onClick={handleAutofillDemo}
                className="text-xs font-bold text-[#003366] hover:underline cursor-pointer"
              >
                Autofill Into Form →
              </button>
            </div>
          </div>

          {/* Main Authentication Card */}
          <div className="bg-white border border-[#D1D5DB] rounded-md p-6 shadow-sm space-y-4">
            {/* Mode Tabs */}
            {mode !== 'recovery' && (
              <div className="flex border-b border-[#D1D5DB] pb-2 gap-6 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setErrorMessage('');
                    setSuccessMessage('');
                  }}
                  className={`pb-2 border-b-2 transition-colors cursor-pointer ${
                    mode === 'login'
                      ? 'border-[#003366] text-[#003366]'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Citizen Sign In
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setErrorMessage('');
                    setSuccessMessage('');
                  }}
                  className={`pb-2 border-b-2 transition-colors cursor-pointer ${
                    mode === 'register'
                      ? 'border-[#003366] text-[#003366]'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Register New Account
                </button>
              </div>
            )}

            {/* Error & Success Messages */}
            {errorMessage && (
              <div className="p-3 rounded bg-[#F8D7DA] border border-[#F5C2C7] text-[#842029] text-xs font-medium flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}
            {successMessage && (
              <div className="p-3 rounded bg-[#D1E7DD] border border-[#BADBCC] text-[#0F5132] text-xs font-medium flex items-center gap-2">
                <Check className="w-4 h-4 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {/* MODE 1: LOGIN */}
            {mode === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-[#1D2A44] block mb-1">
                    Email Address or Username
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. demo@powerpunjab.demo"
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded text-xs text-slate-900 placeholder:text-slate-400 focus:border-[#003366] focus:ring-1 focus:ring-[#003366]"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-[#1D2A44]">
                      Account Password
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setMode('recovery');
                        setRecoveryEmail(email);
                        setErrorMessage('');
                        setSuccessMessage('');
                      }}
                      className="text-[11px] font-semibold text-[#003366] hover:underline cursor-pointer"
                    >
                      Forgot Password?
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter account password"
                      className="w-full px-3 py-2 pr-10 bg-white border border-[#D1D5DB] rounded text-xs text-slate-900 placeholder:text-slate-400 focus:border-[#003366] focus:ring-1 focus:ring-[#003366]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-700"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-[#003366] hover:bg-[#0B2545] text-white font-bold text-xs rounded transition-colors cursor-pointer shadow-none"
                >
                  Sign In to PowerPunjab Portal
                </button>
              </form>
            )}

            {/* MODE 2: REGISTER */}
            {mode === 'register' && (
              <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
                <div>
                  <label className="text-xs font-bold text-[#1D2A44] block mb-1">
                    Consumer Full Name *
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Tariq Mahmood"
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded text-xs text-slate-900 focus:border-[#003366]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#1D2A44] block mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded text-xs text-slate-900 focus:border-[#003366]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[11px] font-bold text-[#1D2A44] block mb-1">
                      Phone Number
                    </label>
                    <input
                      type="text"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+92 300 1234567"
                      className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded text-xs text-slate-900 focus:border-[#003366]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-[#1D2A44] block mb-1">
                      Utility Provider
                    </label>
                    <select
                      value={provider}
                      onChange={(e) => setProvider(e.target.value)}
                      className="w-full px-2 py-2 bg-white border border-[#D1D5DB] rounded text-xs text-slate-800 focus:border-[#003366]"
                    >
                      <option value="LESCO (Lahore Electric Supply Company)">LESCO (Lahore)</option>
                      <option value="MEPCO (Multan Electric Power Company)">MEPCO (Multan)</option>
                      <option value="FESCO (Faisalabad Electric Supply Company)">FESCO (Faisalabad)</option>
                      <option value="GEPCO (Gujranwala Electric Power Company)">GEPCO (Gujranwala)</option>
                      <option value="IESCO (Islamabad Electric Supply Company)">IESCO (Islamabad)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[11px] font-bold text-[#1D2A44] block mb-1">
                      Password (min 6 chars)
                    </label>
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded text-xs text-slate-900 focus:border-[#003366]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-[#1D2A44] block mb-1">
                      Confirm Password
                    </label>
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded text-xs text-slate-900 focus:border-[#003366]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-[#003366] hover:bg-[#0B2545] text-white font-bold text-xs rounded transition-colors cursor-pointer mt-1"
                >
                  Register Account & Proceed
                </button>
              </form>
            )}

            {/* MODE 3: PASSWORD RECOVERY */}
            {mode === 'recovery' && (
              <form onSubmit={handleRecoverySubmit} className="space-y-3.5">
                <div className="space-y-1">
                  <h3 className="text-sm font-bold text-[#0B2545]">Reset Account Password</h3>
                  <p className="text-xs text-slate-600">
                    {recoveryStep === 1
                      ? 'Enter your registered email address to receive an official recovery PIN.'
                      : 'Enter the verification code and configure your new password.'}
                  </p>
                </div>

                {recoveryStep === 1 ? (
                  <div>
                    <label className="text-xs font-bold text-[#1D2A44] block mb-1">
                      Registered Email Address
                    </label>
                    <input
                      type="email"
                      value={recoveryEmail}
                      onChange={(e) => setRecoveryEmail(e.target.value)}
                      placeholder="demo@powerpunjab.demo"
                      className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded text-xs text-slate-900 focus:border-[#003366]"
                    />
                  </div>
                ) : (
                  <>
                    <div>
                      <label className="text-xs font-bold text-[#1D2A44] block mb-1">
                        Verification PIN (Demo PIN: 481920)
                      </label>
                      <input
                        type="text"
                        value={resetCode}
                        onChange={(e) => setResetCode(e.target.value)}
                        placeholder="481920"
                        className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded text-xs font-mono text-slate-900 focus:border-[#003366]"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-[#1D2A44] block mb-1">
                        New Password
                      </label>
                      <input
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Minimum 6 characters"
                        className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded text-xs text-slate-900 focus:border-[#003366]"
                      />
                    </div>
                  </>
                )}

                <div className="flex items-center justify-between pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setMode('login');
                      setRecoveryStep(1);
                      setErrorMessage('');
                      setSuccessMessage('');
                    }}
                    className="text-xs text-slate-600 hover:text-slate-900 font-medium"
                  >
                    ← Back to Sign In
                  </button>
                  <button
                    type="submit"
                    className="py-2 px-4 bg-[#003366] hover:bg-[#0B2545] text-white font-bold text-xs rounded transition-colors cursor-pointer"
                  >
                    {recoveryStep === 1 ? 'Dispatch Recovery PIN' : 'Save New Password'}
                  </button>
                </div>
              </form>
            )}

            {/* Google Authentication (Firebase Auth) */}
            {mode === 'login' && (
              <div className="pt-3 border-t border-[#D1D5DB] space-y-2">
                <div className="text-center text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                  Or Authenticate With Verified Account
                </div>
                <button
                  type="button"
                  onClick={loginWithGoogleAuth}
                  className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-white hover:bg-[#F4F6F8] border border-[#D1D5DB] rounded text-xs font-bold text-slate-700 transition-colors cursor-pointer"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Sign in with Google Account</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Official Bottom Disclaimer */}
      <div className="bg-[#0B2545] text-slate-300 text-xs py-3 px-4 text-center border-t border-[#003366]">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-1 text-[11px]">
          <span>PowerPunjab Electricity Management Authority • Government of Punjab</span>
          <span>Security & Standards Compliant • NEPRA Regulated</span>
        </div>
      </div>
    </div>
  );
};
