import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  CreditCard,
  Building2,
  Smartphone,
  QrCode,
  ShieldCheck,
  CheckCircle2,
  Printer,
  Building,
} from 'lucide-react';

export const PaymentModal: React.FC = () => {
  const {
    isPaymentModalOpen,
    activeBillForPayment,
    closePaymentModal,
    markBillAsPaid,
    activeConnection,
    user,
  } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<string>('Bank Transfer (1Bill IBFT)');
  const [paymentState, setPaymentState] = useState<'selecting' | 'processing' | 'success'>('selecting');
  const [receiptData, setReceiptData] = useState<{
    txnId: string;
    date: string;
    method: string;
  } | null>(null);

  if (!isPaymentModalOpen || !activeBillForPayment) return null;

  const bill = activeBillForPayment;

  const paymentOptions = [
    {
      id: 'bank',
      name: 'Bank Transfer (1Bill IBFT)',
      desc: 'HBL, Meezan, Bank Alfalah, MCB, NBP',
      icon: Building2,
    },
    {
      id: 'wallet',
      name: 'Mobile Digital Wallet',
      desc: 'Easypaisa, JazzCash, Nayapay, Sadapay',
      icon: Smartphone,
    },
    {
      id: 'card',
      name: 'Debit / Credit Card',
      desc: 'PayPak, Visa, Mastercard',
      icon: CreditCard,
    },
    {
      id: 'raast',
      name: 'Raast P2M Instant Settlement',
      desc: 'State Bank of Pakistan Instant Rail',
      icon: QrCode,
    },
  ];

  const handleSimulatePayment = async () => {
    setPaymentState('processing');

    setTimeout(async () => {
      const res = await markBillAsPaid(bill.billId, paymentMethod);
      if (res.success) {
        setReceiptData({
          txnId: res.receiptNumber || `TXN-PP-${Math.floor(100000 + Math.random() * 900000)}`,
          date: new Date().toLocaleString('en-PK', { timeZone: 'Asia/Karachi' }) + ' PKT',
          method: paymentMethod,
        });
        setPaymentState('success');
      }
    }, 900);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-white border border-[#D1D5DB] w-full max-w-md rounded-md shadow-xl overflow-hidden flex flex-col max-h-[92vh] text-[#1D2A44]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#D1D5DB] bg-[#F4F6F8]">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#003366] text-xs uppercase tracking-wide">
              Official Payment Checkout
            </span>
          </div>
          <button
            onClick={closePaymentModal}
            className="p-1 rounded text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto p-5 space-y-4 bg-white">
          {paymentState === 'selecting' && (
            <>
              {/* Bill Details Box */}
              <div className="p-3.5 rounded bg-[#F4F6F8] border border-[#D1D5DB] space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-600 font-medium">Service Utility:</span>
                  <span className="font-bold text-slate-900">
                    {bill.serviceProvider || activeConnection.serviceProvider}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 font-medium">Billing Period:</span>
                  <span className="text-slate-800 font-semibold">{bill.billingMonth}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 font-medium">Consumer Reference:</span>
                  <span className="font-mono font-bold text-[#003366]">{activeConnection.referenceNumber}</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-[#D1D5DB]">
                  <span className="font-bold text-[#0B2545]">Payable Amount:</span>
                  <span className="font-mono text-2xl font-black text-[#003366]">
                    Rs. {bill.totalAmount.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Payment Methods */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-[#1D2A44] block">
                  Select Settlement Channel:
                </label>
                <div className="space-y-2">
                  {paymentOptions.map((opt) => {
                    const Icon = opt.icon;
                    const isSelected = paymentMethod === opt.name;

                    return (
                      <div
                        key={opt.id}
                        onClick={() => setPaymentMethod(opt.name)}
                        className={`p-3 rounded border cursor-pointer transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-[#F4F6F8] border-[#003366]'
                            : 'bg-white hover:bg-[#F4F6F8]/60 border-[#D1D5DB]'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded ${isSelected ? 'bg-[#003366] text-white' : 'bg-slate-100 text-slate-700'}`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-xs font-bold text-slate-900">{opt.name}</div>
                            <div className="text-[10px] text-slate-500">{opt.desc}</div>
                          </div>
                        </div>

                        <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${isSelected ? 'border-[#003366] bg-[#003366]' : 'border-slate-300'}`}>
                          {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="p-3 rounded bg-[#F4F6F8] border border-[#D1D5DB] text-[11px] text-slate-600 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#0F5132] shrink-0" />
                <span>Simulated consumer gateway. Authorizes settlement without deducting real banking funds.</span>
              </div>
            </>
          )}

          {paymentState === 'processing' && (
            <div className="py-12 text-center space-y-3">
              <div className="w-7 h-7 rounded-full border-2 border-[#003366] border-t-transparent animate-spin mx-auto" />
              <div className="text-xs font-bold text-[#0B2545]">Authorizing Transaction...</div>
              <p className="text-[11px] text-slate-500">Connecting to national 1Bill payment switch</p>
            </div>
          )}

          {paymentState === 'success' && receiptData && (
            <div className="space-y-4">
              <div className="text-center py-2 space-y-1">
                <CheckCircle2 className="w-10 h-10 text-[#0F5132] mx-auto" />
                <h4 className="text-base font-bold text-[#0B2545]">Payment Successfully Settled</h4>
                <p className="text-xs text-slate-600">
                  {bill.billingMonth} bill status updated to <strong className="text-[#0F5132]">PAID</strong>.
                </p>
              </div>

              {/* Receipt */}
              <div className="p-4 rounded bg-[#F4F6F8] border border-[#D1D5DB] space-y-2 font-mono text-xs">
                <div className="flex justify-between items-center border-b border-[#D1D5DB] pb-2">
                  <span className="font-bold text-[#0B2545] font-sans">Official Payment Receipt</span>
                  <span className="text-[10px] text-[#0F5132] bg-[#D1E7DD] border border-[#BADBCC] px-2 py-0.5 rounded font-bold">
                    SETTLED
                  </span>
                </div>
                <div className="space-y-1 text-slate-700 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Transaction ID:</span>
                    <span className="text-slate-900 font-bold">{receiptData.txnId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Service Utility:</span>
                    <span>{bill.serviceProvider || activeConnection.serviceProvider}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Account Reference:</span>
                    <span>{activeConnection.referenceNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Channel:</span>
                    <span>{receiptData.method}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Timestamp:</span>
                    <span>{receiptData.date}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-[#D1D5DB] text-xs font-bold">
                    <span className="text-slate-800">Amount Paid:</span>
                    <span className="text-[#0B2545] font-black">Rs. {bill.totalAmount.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-[#D1D5DB] bg-[#F4F6F8] flex justify-between gap-2">
          {paymentState === 'selecting' && (
            <>
              <button
                onClick={closePaymentModal}
                className="py-1.5 px-4 rounded bg-white border border-[#D1D5DB] text-slate-700 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSimulatePayment}
                className="py-1.5 px-5 rounded bg-[#003366] hover:bg-[#0B2545] text-white font-bold text-xs transition-colors cursor-pointer shadow-none"
              >
                Confirm & Pay
              </button>
            </>
          )}

          {paymentState === 'success' && (
            <>
              <button
                onClick={handlePrint}
                className="py-1.5 px-4 rounded bg-white border border-[#D1D5DB] text-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer hover:bg-slate-100"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Receipt</span>
              </button>
              <button
                onClick={closePaymentModal}
                className="py-1.5 px-5 rounded bg-[#003366] hover:bg-[#0B2545] text-white font-bold text-xs cursor-pointer shadow-none"
              >
                Close
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
