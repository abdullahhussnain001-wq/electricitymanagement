import React, { useRef, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { jsPDF } from 'jspdf';
import { PunjabGovEmblem } from '../common/PunjabGovEmblem';
import {
  X,
  FileDown,
  Printer,
  ShieldCheck,
} from 'lucide-react';

export const PdfReportModal: React.FC = () => {
  const {
    isPdfReportOpen,
    closePdfReport,
    bills,
    activeConnection,
    user,
  } = useApp();

  const [isGenerating, setIsGenerating] = useState(false);
  const printableReportRef = useRef<HTMLDivElement>(null);

  if (!isPdfReportOpen) return null;

  const connBills = bills.filter((b) => b.connectionId === activeConnection.connectionId);
  const totalUnits = connBills.reduce((acc, b) => acc + b.unitsConsumed, 0);
  const totalBilled = connBills.reduce((acc, b) => acc + b.totalAmount, 0);
  const avgUnits = connBills.length > 0 ? (totalUnits / connBills.length).toFixed(1) : '0';
  const avgCost = connBills.length > 0 ? Math.round(totalBilled / connBills.length) : 0;
  const peakBill = [...connBills].sort((a, b) => b.unitsConsumed - a.unitsConsumed)[0];
  const lowestBill = [...connBills].sort((a, b) => a.unitsConsumed - b.unitsConsumed)[0];

  const reportDate = new Date().toLocaleDateString('en-PK', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  const reportId = `GOP-PUNJAB-${activeConnection.referenceNumber.replace(/[^a-zA-Z0-9]/g, '').slice(0, 8)}-${new Date().getFullYear()}`;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = () => {
    setIsGenerating(true);
    try {
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      // Header
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(13);
      doc.setTextColor(11, 37, 69); // #0B2545
      doc.text('ROSHAN PUNJAB • OFFICIAL ELECTRICITY CONSUMER PORTAL', 14, 19);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9.5);
      doc.setTextColor(0, 51, 102); // #003366
      doc.text('GOVERNMENT OF THE PUNJAB • ENERGY & POWER DEVELOPMENT DEPARTMENT', 14, 24);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(75, 85, 99);
      doc.text('Power Information Technology Company (PITC) • Verified Metering Division', 14, 29);
      doc.text(`Monthly Electricity Usage & Billing Summary Statement • Reference: ${reportId}`, 14, 34);

      doc.setDrawColor(209, 213, 219);
      doc.setLineWidth(0.5);
      doc.line(14, 38, 196, 38);

      // Consumer Particulars
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(11, 37, 69);
      doc.text('1. CONSUMER AND METER PROFILE', 14, 45);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(29, 42, 68);
      doc.text(`Consumer Name: ${user.name}`, 14, 51);
      doc.text(`Account Reference: ${activeConnection.referenceNumber}`, 14, 57);
      doc.text(`Meter Number: ${activeConnection.maskedMeterNumber}`, 14, 63);
      doc.text(`Distribution Utility: ${activeConnection.serviceProvider || 'LESCO'}`, 110, 51);
      doc.text(`Tariff / Sanctioned Load: ${activeConnection.tariff} (${activeConnection.sanctionedLoad})`, 110, 57);
      doc.text(`Sub-Division: ${activeConnection.subDivision}`, 110, 63);

      doc.line(14, 68, 196, 68);

      // Statement Table
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(11, 37, 69);
      doc.text('2. VERIFIED MONTHLY CONSUMPTION & CHARGES RECORD', 14, 75);

      let startY = 82;
      doc.setFillColor(244, 246, 248);
      doc.rect(14, startY - 4.5, 182, 6.5, 'F');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(11, 37, 69);
      doc.text('Month', 16, startY);
      doc.text('Units (kWh)', 50, startY);
      doc.text('Energy Charges', 82, startY);
      doc.text('FPA & Taxes', 120, startY);
      doc.text('Total (PKR)', 155, startY);
      doc.text('Status', 182, startY);

      doc.setFont('helvetica', 'normal');
      doc.setTextColor(29, 42, 68);

      connBills.forEach((b) => {
        startY += 7;
        const taxes = b.totalAmount - b.costOfElectricity;
        doc.text(b.billingMonth, 16, startY);
        doc.text(`${b.unitsConsumed} kWh`, 50, startY);
        doc.text(`Rs. ${b.costOfElectricity.toLocaleString()}`, 82, startY);
        doc.text(`Rs. ${taxes.toLocaleString()}`, 120, startY);
        doc.text(`Rs. ${b.totalAmount.toLocaleString()}`, 155, startY);
        doc.text(b.paymentStatus.toUpperCase(), 182, startY);
        doc.setDrawColor(240, 240, 240);
        doc.line(14, startY + 2, 196, startY + 2);
      });

      // Summary Box
      startY += 10;
      doc.setFillColor(244, 246, 248);
      doc.rect(14, startY - 4, 182, 26, 'F');
      doc.setDrawColor(209, 213, 219);
      doc.rect(14, startY - 4, 182, 26, 'S');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9.5);
      doc.setTextColor(11, 37, 69);
      doc.text('3. CUMULATIVE PERIOD TOTALS AND AUDIT METRICS', 18, startY + 2);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.text(`Total Energy Recorded: ${totalUnits.toLocaleString()} kWh units`, 18, startY + 8);
      doc.text(`Total Billed Charges: Rs. ${totalBilled.toLocaleString()}`, 18, startY + 14);
      doc.text(`Average Monthly Consumption: ${avgUnits} kWh/month`, 18, startY + 20);

      doc.text(`Average Monthly Invoice: Rs. ${avgCost.toLocaleString()}`, 110, startY + 8);
      doc.text(`Peak Demand Period: ${peakBill ? `${peakBill.billingMonth} (${peakBill.unitsConsumed} kWh)` : 'N/A'}`, 110, startY + 14);
      doc.text(`Lowest Demand Period: ${lowestBill ? `${lowestBill.billingMonth} (${lowestBill.unitsConsumed} kWh)` : 'N/A'}`, 110, startY + 20);

      // Certification footer
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      doc.text('Official Government of Punjab Consumer Electricity Summary Statement • Power Information Technology Company', 14, 275);
      doc.text('This document is certified for official tax filing, personal bookkeeping, and residential efficiency audits.', 14, 280);

      doc.save(`PowerPunjab_Billing_Statement_${activeConnection.referenceNumber.slice(-6)}.pdf`);
    } catch (err) {
      console.error('Failed to generate PDF:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-white border border-[#D1D5DB] w-full max-w-2xl rounded-md shadow-xl overflow-hidden flex flex-col max-h-[92vh] text-[#1D2A44]">
        {/* Top Control Bar */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-[#D1D5DB] bg-[#F4F6F8] no-print">
          <div>
            <h3 className="text-xs font-bold text-[#003366] uppercase tracking-wide">
              Official Billing & Usage Statement Preview
            </h3>
            <p className="text-[11px] text-slate-500">
              Government format certified for personal filing & tax record-keeping
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadPdf}
              disabled={isGenerating}
              className="flex items-center gap-1.5 py-1.5 px-3 bg-[#003366] hover:bg-[#0B2545] text-white rounded text-xs font-bold transition-colors cursor-pointer disabled:opacity-50 shadow-none"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span>{isGenerating ? 'Exporting...' : 'Download PDF'}</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 py-1.5 px-3 bg-white border border-[#D1D5DB] hover:bg-slate-100 text-slate-700 rounded text-xs font-semibold transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save</span>
            </button>

            <button
              onClick={closePdfReport}
              className="p-1 rounded text-slate-500 hover:text-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Report Preview Document */}
        <div className="overflow-y-auto p-6 space-y-5 bg-white" ref={printableReportRef}>
          {/* Government Letterhead */}
          <div className="border-b-2 border-[#003366] pb-3 flex flex-col sm:flex-row justify-between sm:items-end gap-3">
            <div className="flex items-center gap-3">
              <PunjabGovEmblem size={44} />
              <div>
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
                    Government of the Punjab • Energy & Power Development Department
                  </span>
                </div>
                <h1 className="text-xl font-black text-[#0B2545] tracking-tight">
                  Roshan Punjab
                </h1>
                <p className="text-xs text-[#003366] font-bold uppercase">
                  Official Electricity Consumer Portal • Monthly Usage & Billing Summary Statement
                </p>
              </div>
            </div>

            <div className="text-left sm:text-right font-mono text-xs text-slate-600">
              <div>Doc Ref: <strong className="text-slate-900">{reportId}</strong></div>
              <div>Issue Date: {reportDate}</div>
              <div>Status: <span className="text-[#0F5132] font-bold">CERTIFIED AUTHENTIC</span></div>
            </div>
          </div>

          {/* Consumer Account Particulars */}
          <div className="rounded border border-[#D1D5DB] p-3.5 bg-[#F4F6F8] text-xs space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">
              1. Consumer & Meter Profile
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <span className="text-slate-500 text-[10px] block">Consumer Name:</span>
                <span className="font-bold text-slate-900">{user.name}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">Reference Number:</span>
                <span className="font-mono font-bold text-[#003366]">{activeConnection.referenceNumber}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">Meter Number:</span>
                <span className="font-mono text-slate-800">{activeConnection.maskedMeterNumber}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">Distribution Utility:</span>
                <span className="text-slate-800 font-semibold">{activeConnection.serviceProvider || 'LESCO'}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">Tariff / Load:</span>
                <span className="text-slate-800">{activeConnection.tariff} ({activeConnection.sanctionedLoad})</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">Sub-Division:</span>
                <span className="text-slate-800">{activeConnection.subDivision}</span>
              </div>
            </div>
          </div>

          {/* Monthly Record Table */}
          <div className="space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">
              2. Monthly Consumption & Billing Breakdown
            </span>
            <div className="rounded border border-[#D1D5DB] overflow-hidden text-xs">
              <table className="w-full text-left border-collapse">
                <thead className="bg-[#F4F6F8] border-b border-[#D1D5DB] text-[#0B2545] font-bold text-[11px] uppercase">
                  <tr>
                    <th className="py-2 px-3">Billing Month</th>
                    <th className="py-2 px-3">Units (kWh)</th>
                    <th className="py-2 px-3">Energy Charges</th>
                    <th className="py-2 px-3">FPA & Surcharges</th>
                    <th className="py-2 px-3">Total Amount</th>
                    <th className="py-2 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-800">
                  {connBills.map((b) => {
                    const surcharges = b.fuelPriceAdjustment + b.fcSurcharge + b.electricityDuty + b.tvFee + b.salesTax;
                    return (
                      <tr key={b.billId} className="hover:bg-[#F4F6F8]/70">
                        <td className="py-2 px-3 font-semibold text-slate-900">{b.billingMonth}</td>
                        <td className="py-2 px-3 font-mono font-bold text-[#003366]">{b.unitsConsumed}</td>
                        <td className="py-2 px-3 font-mono">Rs. {b.costOfElectricity.toLocaleString()}</td>
                        <td className="py-2 px-3 font-mono">Rs. {surcharges.toLocaleString()}</td>
                        <td className="py-2 px-3 font-mono font-bold text-slate-900">Rs. {b.totalAmount.toLocaleString()}</td>
                        <td className="py-2 px-3">
                          <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${b.paymentStatus === 'paid' ? 'bg-[#D1E7DD] text-[#0F5132] border-[#BADBCC]' : 'bg-[#F8D7DA] text-[#842029] border-[#F5C2C7]'}`}>
                            {b.paymentStatus}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Cumulative Totals and Key Insights */}
          <div className="rounded border border-[#D1D5DB] p-3.5 bg-[#F4F6F8] space-y-2 text-xs">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">
              3. Period Summary & Consumption Analytics
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
              <div className="p-2.5 bg-white rounded border border-[#D1D5DB]">
                <span className="text-[10px] text-slate-500 block uppercase">Total Units</span>
                <span className="font-mono text-base font-bold text-slate-900 mt-0.5 block">
                  {totalUnits.toLocaleString()} kWh
                </span>
              </div>
              <div className="p-2.5 bg-white rounded border border-[#D1D5DB]">
                <span className="text-[10px] text-slate-500 block uppercase">Total Billed</span>
                <span className="font-mono text-base font-bold text-slate-900 mt-0.5 block">
                  Rs. {totalBilled.toLocaleString()}
                </span>
              </div>
              <div className="p-2.5 bg-white rounded border border-[#D1D5DB]">
                <span className="text-[10px] text-slate-500 block uppercase">Monthly Avg Units</span>
                <span className="font-mono text-base font-bold text-[#003366] mt-0.5 block">
                  {avgUnits} kWh
                </span>
              </div>
              <div className="p-2.5 bg-white rounded border border-[#D1D5DB]">
                <span className="text-[10px] text-slate-500 block uppercase">Monthly Avg Cost</span>
                <span className="font-mono text-base font-bold text-slate-900 mt-0.5 block">
                  Rs. {avgCost.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Certification notice */}
          <div className="border-t border-[#D1D5DB] pt-3 flex flex-col sm:flex-row justify-between items-center gap-2 text-[10px] text-slate-500">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#0F5132]" />
              <span>Certified authentic electronic summary for personal record-keeping & audits.</span>
            </div>
            <div className="font-mono text-slate-500">
              SYSTEM HASH: 8F2A-09C1-77BA
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#D1D5DB] bg-[#F4F6F8] flex justify-between items-center no-print">
          <span className="text-xs text-slate-500">
            Standard A4 Portrait Export Format
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={closePdfReport}
              className="py-1.5 px-3 rounded border border-[#D1D5DB] bg-white text-slate-700 text-xs font-semibold cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={handleDownloadPdf}
              disabled={isGenerating}
              className="py-1.5 px-4 rounded bg-[#003366] hover:bg-[#0B2545] text-white text-xs font-bold transition-colors cursor-pointer shadow-none"
            >
              {isGenerating ? 'Exporting...' : 'Download PDF'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
