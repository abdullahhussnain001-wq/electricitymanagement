import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TARIFF_SLABS, EDUCATION_ARTICLES } from '../../services/dataService';
import { EducationArticle } from '../../types';
import {
  X,
  BookOpen,
  Search,
  ChevronRight,
  ShieldAlert,
  Clock,
  CheckCircle2,
} from 'lucide-react';

export const TariffsAndEducationModal: React.FC = () => {
  const { isTariffsEducationOpen, closeTariffsEducation } = useApp();
  const [activeTab, setActiveTab] = useState<'tariffs' | 'articles'>('tariffs');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArticle, setSelectedArticle] = useState<EducationArticle | null>(null);

  if (!isTariffsEducationOpen) return null;

  const filteredArticles = EDUCATION_ARTICLES.filter((a) => {
    const q = searchQuery.toLowerCase();
    return (
      a.title.toLowerCase().includes(q) ||
      a.category.toLowerCase().includes(q) ||
      a.summary.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-white border border-[#D1D5DB] w-full max-w-lg rounded-md shadow-xl overflow-hidden flex flex-col max-h-[92vh] text-[#1D2A44]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#D1D5DB] bg-[#F4F6F8]">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#003366] text-xs uppercase tracking-wide">
              NEPRA Statutory Tariff Slabs & Guides
            </span>
          </div>
          <button
            onClick={closeTariffsEducation}
            className="p-1 rounded text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selector */}
        {!selectedArticle && (
          <div className="flex border-b border-[#D1D5DB] bg-[#F4F6F8] px-4 pt-2 gap-2 text-xs font-bold">
            <button
              onClick={() => setActiveTab('tariffs')}
              className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer ${
                activeTab === 'tariffs'
                  ? 'border-[#003366] text-[#003366]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              Statutory Tariff Slabs
            </button>
            <button
              onClick={() => setActiveTab('articles')}
              className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer ${
                activeTab === 'articles'
                  ? 'border-[#003366] text-[#003366]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              Energy Guides ({EDUCATION_ARTICLES.length})
            </button>
          </div>
        )}

        {/* Modal Body */}
        <div className="overflow-y-auto p-5 space-y-4 bg-white text-xs">
          {/* ARTICLE READER VIEW */}
          {selectedArticle ? (
            <div className="space-y-4">
              <button
                onClick={() => setSelectedArticle(null)}
                className="text-xs text-[#003366] hover:underline font-bold cursor-pointer"
              >
                ← Back to guide directory
              </button>

              <div className="space-y-1">
                <span className="text-[10px] font-bold text-[#003366] uppercase tracking-wider">
                  {selectedArticle.category} • {selectedArticle.readTime}
                </span>
                <h3 className="text-base font-bold text-[#0B2545] leading-tight">
                  {selectedArticle.title}
                </h3>
              </div>

              <div className="p-3.5 rounded bg-[#F4F6F8] border border-[#D1D5DB] text-xs text-slate-800 leading-relaxed font-medium">
                {selectedArticle.summary}
              </div>

              <div className="space-y-2.5 text-xs text-slate-700 leading-relaxed">
                {selectedArticle.content.map((paragraph, idx) => (
                  <p key={idx}>{paragraph}</p>
                ))}
              </div>

              {/* Key Takeaways */}
              <div className="p-4 rounded bg-[#F4F6F8] border border-[#D1D5DB] space-y-2">
                <span className="text-xs font-bold text-[#0B2545] block">Official Key Takeaways</span>
                <ul className="space-y-1.5 text-xs text-slate-700">
                  {selectedArticle.keyTakeaways.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#0F5132] mt-0.5 shrink-0" />
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : activeTab === 'tariffs' ? (
            /* TARIFFS TABLE VIEW */
            <div className="space-y-3">
              {/* Official Notice */}
              <div className="p-3 rounded bg-[#F4F6F8] border border-[#D1D5DB] flex items-start gap-2 text-xs text-slate-700">
                <ShieldAlert className="w-4 h-4 text-[#003366] shrink-0 mt-0.5" />
                <p className="text-[11px] leading-snug">
                  <strong>NEPRA Statutory Slabs:</strong> Standard benchmark rates applicable across Punjab distribution companies (LESCO, MEPCO, FESCO, GEPCO).
                </p>
              </div>

              {/* Tariff Table */}
              <div className="rounded border border-[#D1D5DB] overflow-hidden bg-white">
                <div className="px-3.5 py-2 bg-[#F4F6F8] border-b border-[#D1D5DB] flex justify-between text-[11px] font-bold text-[#0B2545] uppercase tracking-wider">
                  <span>Consumption Slab</span>
                  <span>Approved Rate / Unit</span>
                </div>
                <div className="divide-y divide-slate-200 text-xs">
                  {TARIFF_SLABS.map((slab) => (
                    <div key={slab.slab} className="p-3 flex justify-between items-center hover:bg-[#F4F6F8]/60">
                      <div>
                        <div className="font-bold text-slate-900">{slab.slab}</div>
                        <div className="text-[10px] text-[#003366] font-mono font-bold">{slab.unitRange}</div>
                        <div className="text-[10px] text-slate-500 mt-0.5">{slab.notes}</div>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-slate-900 text-sm">
                          Rs. {slab.ratePerUnit.toFixed(2)}
                        </span>
                        <span className="text-[10px] text-slate-500 block">per unit</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Surcharges & Taxes Explanation */}
              <div className="p-3.5 rounded bg-[#F4F6F8] border border-[#D1D5DB] space-y-1.5 text-xs">
                <span className="font-bold text-[#0B2545] block">Statutory Surcharges & Taxes:</span>
                <ul className="space-y-1 text-slate-600 text-[11px]">
                  <li>• <strong>Fuel Price Adjustment (FPA):</strong> Monthly pass-through of power generation fuel mix variance.</li>
                  <li>• <strong>Financing Cost (FC) Surcharge:</strong> Debt servicing surcharge approved by NEPRA.</li>
                  <li>• <strong>Electricity Duty:</strong> 1.5% Government of Punjab provincial excise.</li>
                  <li>• <strong>PTV License Fee:</strong> Fixed statutory broadcast charge (Rs. 35 per residential meter).</li>
                  <li>• <strong>General Sales Tax (GST):</strong> 17% Federal statutory sales tax.</li>
                </ul>
              </div>
            </div>
          ) : (
            /* ARTICLES LIST VIEW */
            <div className="space-y-3">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search regulatory guides or topics..."
                  className="w-full pl-9 pr-3 py-1.5 bg-white border border-[#D1D5DB] rounded text-xs text-slate-900 focus:border-[#003366]"
                />
              </div>

              <div className="space-y-2">
                {filteredArticles.map((article) => (
                  <div
                    key={article.id}
                    onClick={() => setSelectedArticle(article)}
                    className="p-3.5 rounded bg-[#F4F6F8] hover:bg-slate-100 border border-[#D1D5DB] transition-all cursor-pointer space-y-1"
                  >
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="font-bold text-[#003366] uppercase tracking-wide">
                        {article.category}
                      </span>
                      <span className="text-slate-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {article.readTime}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-slate-900">
                      {article.title}
                    </h4>

                    <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                      {article.summary}
                    </p>

                    <div className="pt-1 flex items-center justify-end text-[10px] text-[#003366] font-bold">
                      Read Guidance →
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#D1D5DB] bg-[#F4F6F8] flex justify-end">
          <button
            onClick={closeTariffsEducation}
            className="py-1.5 px-4 rounded bg-white border border-[#D1D5DB] hover:bg-slate-100 text-slate-700 font-bold text-xs cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
