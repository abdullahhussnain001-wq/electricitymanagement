import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Bill } from '../../types';
import {
  Search,
  FileText,
  CreditCard,
  CheckCircle2,
  Calendar,
  Building,
  PlusCircle,
  Clock,
  ArrowUpDown,
  AlertCircle,
  FileDown,
} from 'lucide-react';

export const BillsTab: React.FC = () => {
  const {
    bills,
    activeConnection,
    openBillDetails,
    openAiAnalyzer,
    openPaymentModal,
    openAddBill,
    openPdfReport,
  } = useApp();

  const [filterStatus, setFilterStatus] = useState<'all' | 'unpaid' | 'paid'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'date' | 'amount' | 'units'>('date');

  const filteredBills = bills
    .filter((bill) => {
      if (filterStatus === 'unpaid') return bill.paymentStatus === 'unpaid';
      if (filterStatus === 'paid') return bill.paymentStatus === 'paid';
      return true;
    })
    .filter((bill) => {
      const q = searchQuery.toLowerCase();
      return (
        bill.billingMonth.toLowerCase().includes(q) ||
        bill.billId.toLowerCase().includes(q) ||
        (bill.serviceProvider && bill.serviceProvider.toLowerCase().includes(q)) ||
        bill.totalAmount.toString().includes(q)
      );
    })
    .sort((a, b) => {
      if (sortBy === 'amount') return b.totalAmount - a.totalAmount;
      if (sortBy === 'units') return b.unitsConsumed - a.unitsConsumed;
      return 0;
    });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <span className="text-[11px] font-bold text-[#003366] uppercase tracking-wider block">
            Consumer Billing Archive
          </span>
          <h2 className="text-xl font-bold text-[#0B2545] tracking-tight">
            Official Electricity Bills
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Registered Connection: <strong className="text-slate-900">{activeConnection.displayName}</strong> • Ref: <span className="font-mono text-[#003366] font-bold">{activeConnection.referenceNumber}</span>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={openPdfReport}
            className="flex items-center gap-1.5 py-2 px-3.5 bg-white hover:bg-[#F4F6F8] text-[#003366] border border-[#003366] text-xs font-bold rounded transition-colors cursor-pointer"
          >
            <FileDown className="w-4 h-4" />
            <span>Export Statement (PDF)</span>
          </button>

          <button
            onClick={openAddBill}
            className="flex items-center gap-1.5 py-2 px-3.5 bg-[#003366] hover:bg-[#0B2545] text-white text-xs font-bold rounded transition-colors cursor-pointer shadow-none"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add Bill Record</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white border border-[#D1D5DB] rounded-md p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by month (e.g. October) or bill #..."
            className="w-full pl-9 pr-3 py-1.5 bg-white border border-[#D1D5DB] rounded text-xs text-slate-900 placeholder:text-slate-400 focus:border-[#003366]"
          />
        </div>

        <div className="flex items-center justify-between w-full sm:w-auto gap-3 text-xs">
          {/* Status filters */}
          <div className="flex items-center gap-1">
            {(['all', 'unpaid', 'paid'] as const).map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`capitalize px-3 py-1 rounded text-xs font-bold transition-colors cursor-pointer ${
                  filterStatus === status
                    ? 'bg-[#003366] text-white'
                    : 'bg-[#F4F6F8] text-slate-700 hover:bg-slate-200 border border-[#D1D5DB]'
                }`}
              >
                {status}
              </button>
            ))}
          </div>

          {/* Sort */}
          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span className="text-[11px] font-semibold text-slate-500">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-white border border-[#D1D5DB] rounded px-2 py-1 text-slate-800 text-xs focus:border-[#003366]"
            >
              <option value="date">Billing Date</option>
              <option value="amount">Amount (High to Low)</option>
              <option value="units">Units Consumed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Official Billing Statements Table */}
      <div className="bg-white border border-[#D1D5DB] rounded-md shadow-xs overflow-hidden">
        {filteredBills.length === 0 ? (
          <div className="text-center py-12 px-4 space-y-2">
            <AlertCircle className="w-8 h-8 text-slate-400 mx-auto" />
            <h4 className="text-sm font-bold text-slate-800">No matching bills found</h4>
            <p className="text-xs text-slate-500">Adjust your search criteria or register a new bill record.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-[#F4F6F8] text-[#0B2545] font-bold border-b border-[#D1D5DB]">
                  <th className="py-3 px-4">Billing Month</th>
                  <th className="py-3 px-4">Invoice Ref</th>
                  <th className="py-3 px-4">Utility Provider</th>
                  <th className="py-3 px-4">Units (kWh)</th>
                  <th className="py-3 px-4">Payment Due</th>
                  <th className="py-3 px-4">Total Amount (PKR)</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredBills.map((b) => {
                  const isUnpaid = b.paymentStatus === 'unpaid';

                  return (
                    <tr key={b.billId} className="hover:bg-[#F4F6F8]/60 transition-colors">
                      <td className="py-3 px-4 font-bold text-slate-900">
                        {b.billingMonth}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-600">
                        #{b.billId.slice(-8)}
                      </td>
                      <td className="py-3 px-4 text-slate-700">
                        {b.serviceProvider || activeConnection.serviceProvider}
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-[#003366]">
                        {b.unitsConsumed} Units
                      </td>
                      <td className="py-3 px-4 text-slate-700 font-medium">
                        {b.dueDate}
                      </td>
                      <td className="py-3 px-4 font-mono font-black text-slate-900">
                        Rs. {b.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${
                            isUnpaid
                              ? 'bg-[#F8D7DA] text-[#842029] border-[#F5C2C7]'
                              : 'bg-[#D1E7DD] text-[#0F5132] border-[#BADBCC]'
                          }`}
                        >
                          {b.paymentStatus}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right space-x-2">
                        <button
                          onClick={() => openBillDetails(b)}
                          className="text-xs font-semibold text-[#003366] hover:underline cursor-pointer"
                        >
                          Statement
                        </button>
                        <button
                          onClick={() => openAiAnalyzer(b)}
                          className="text-xs font-semibold text-slate-600 hover:text-[#003366] hover:underline cursor-pointer"
                        >
                          Explain
                        </button>
                        {isUnpaid ? (
                          <button
                            onClick={() => openPaymentModal(b)}
                            className="py-1 px-2.5 bg-[#003366] hover:bg-[#0B2545] text-white text-[11px] font-bold rounded cursor-pointer transition-colors"
                          >
                            Pay
                          </button>
                        ) : (
                          <span className="text-[11px] text-[#0F5132] font-semibold">
                            Settled
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
