import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, PlusCircle } from 'lucide-react';

export const AddBillModal: React.FC = () => {
  const { isAddBillOpen, closeAddBill, addNewBill, activeConnection, user } = useApp();

  const [billingMonth, setBillingMonth] = useState('November 2026');
  const [billingPeriod, setBillingPeriod] = useState('12 Oct 2026 - 12 Nov 2026');
  const [issueDate, setIssueDate] = useState('14 Nov 2026');
  const [dueDate, setDueDate] = useState('24 Nov 2026');
  const [unitsConsumed, setUnitsConsumed] = useState(350);
  const [previousReading, setPreviousReading] = useState(15316);
  const [currentReading, setCurrentReading] = useState(15666);
  const [serviceProvider, setServiceProvider] = useState(activeConnection.serviceProvider || 'LESCO (Lahore Electric)');

  // Charges
  const [costOfElectricity, setCostOfElectricity] = useState(4200);
  const [fuelPriceAdjustment, setFuelPriceAdjustment] = useState(650);
  const [fcSurcharge, setFcSurcharge] = useState(320);
  const [electricityDuty, setElectricityDuty] = useState(90);
  const [tvFee, setTvFee] = useState(35);
  const [salesTax, setSalesTax] = useState(900);
  const [paymentStatus, setPaymentStatus] = useState<'unpaid' | 'paid'>('unpaid');

  if (!isAddBillOpen) return null;

  const totalAmount =
    costOfElectricity +
    fuelPriceAdjustment +
    fcSurcharge +
    electricityDuty +
    tvFee +
    salesTax;
  const amountAfterDueDate = Math.round(totalAmount * 1.08);

  const handleUnitsChange = (val: number) => {
    setUnitsConsumed(val);
    setCurrentReading(previousReading + val);
    const estCost = Math.round(val * 12.5);
    setCostOfElectricity(estCost);
    setFuelPriceAdjustment(Math.round(val * 1.8));
    setFcSurcharge(Math.round(val * 0.9));
    setElectricityDuty(Math.round(val * 0.25));
    setSalesTax(Math.round((estCost + val * 2.7) * 0.17));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addNewBill({
      connectionId: activeConnection.connectionId,
      userId: user.userId,
      serviceProvider,
      billingMonth,
      billingPeriod,
      issueDate,
      dueDate,
      unitsConsumed,
      previousReading,
      currentReading,
      costOfElectricity,
      fuelPriceAdjustment,
      fcSurcharge,
      electricityDuty,
      tvFee,
      salesTax,
      totalAmount,
      amountAfterDueDate,
      paymentStatus,
    });
    closeAddBill();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-white border border-[#D1D5DB] w-full max-w-md rounded-md shadow-xl overflow-hidden flex flex-col max-h-[92vh] text-[#1D2A44]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#D1D5DB] bg-[#F4F6F8]">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#003366] text-xs uppercase tracking-wide">
              Register Custom Bill Statement
            </span>
          </div>
          <button
            onClick={closeAddBill}
            className="p-1 rounded text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-5 space-y-3.5 text-xs bg-white">
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">Billing Month *</label>
              <input
                type="text"
                value={billingMonth}
                onChange={(e) => setBillingMonth(e.target.value)}
                placeholder="e.g. November 2026"
                className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-slate-900 focus:border-[#003366]"
              />
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">Utility Provider</label>
              <input
                type="text"
                value={serviceProvider}
                onChange={(e) => setServiceProvider(e.target.value)}
                placeholder="e.g. LESCO, MEPCO"
                className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-slate-900 focus:border-[#003366]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">Due Date *</label>
              <input
                type="text"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                placeholder="e.g. 24 Nov 2026"
                className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-slate-900 focus:border-[#003366]"
              />
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">Units Consumed (kWh) *</label>
              <input
                type="number"
                min="1"
                max="5000"
                value={unitsConsumed}
                onChange={(e) => handleUnitsChange(Number(e.target.value))}
                className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-slate-900 font-mono focus:border-[#003366] font-bold"
              />
            </div>
          </div>

          {/* Meter Readings */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">Previous Meter Reading</label>
              <input
                type="number"
                value={previousReading}
                onChange={(e) => setPreviousReading(Number(e.target.value))}
                className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-slate-900 font-mono focus:border-[#003366]"
              />
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">Current Meter Reading</label>
              <input
                type="number"
                value={currentReading}
                onChange={(e) => setCurrentReading(Number(e.target.value))}
                className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-slate-900 font-mono focus:border-[#003366]"
              />
            </div>
          </div>

          {/* Breakdown Section */}
          <div className="p-3.5 rounded bg-[#F4F6F8] border border-[#D1D5DB] space-y-2">
            <span className="text-[11px] font-bold text-[#0B2545] block">Itemized Charges Breakdown</span>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-600 block mb-0.5">Energy Charges (Rs.)</label>
                <input
                  type="number"
                  value={costOfElectricity}
                  onChange={(e) => setCostOfElectricity(Number(e.target.value))}
                  className="w-full bg-white border border-[#D1D5DB] rounded px-2.5 py-1 text-slate-900 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-600 block mb-0.5">FPA Surcharge (Rs.)</label>
                <input
                  type="number"
                  value={fuelPriceAdjustment}
                  onChange={(e) => setFuelPriceAdjustment(Number(e.target.value))}
                  className="w-full bg-white border border-[#D1D5DB] rounded px-2.5 py-1 text-slate-900 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-600 block mb-0.5">FC Surcharge (Rs.)</label>
                <input
                  type="number"
                  value={fcSurcharge}
                  onChange={(e) => setFcSurcharge(Number(e.target.value))}
                  className="w-full bg-white border border-[#D1D5DB] rounded px-2.5 py-1 text-slate-900 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-600 block mb-0.5">Sales Tax GST (Rs.)</label>
                <input
                  type="number"
                  value={salesTax}
                  onChange={(e) => setSalesTax(Number(e.target.value))}
                  className="w-full bg-white border border-[#D1D5DB] rounded px-2.5 py-1 text-slate-900 font-mono"
                />
              </div>
            </div>

            <div className="pt-2 border-t border-[#D1D5DB] flex justify-between items-center">
              <span className="font-bold text-slate-700">Calculated Total:</span>
              <span className="font-mono text-base font-black text-[#0B2545]">
                Rs. {totalAmount.toLocaleString()}
              </span>
            </div>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">Payment Status</label>
            <div className="flex gap-4">
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="radio"
                  name="status"
                  checked={paymentStatus === 'unpaid'}
                  onChange={() => setPaymentStatus('unpaid')}
                  className="accent-[#003366]"
                />
                <span className="text-slate-800 font-medium">Unpaid (Due)</span>
              </label>
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="radio"
                  name="status"
                  checked={paymentStatus === 'paid'}
                  onChange={() => setPaymentStatus('paid')}
                  className="accent-[#003366]"
                />
                <span className="text-slate-800 font-medium">Paid in Full</span>
              </label>
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={closeAddBill}
              className="py-1.5 px-3 rounded border border-[#D1D5DB] text-slate-700 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="py-1.5 px-5 bg-[#003366] hover:bg-[#0B2545] text-white font-bold rounded transition-colors cursor-pointer shadow-none"
            >
              Register Bill
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
