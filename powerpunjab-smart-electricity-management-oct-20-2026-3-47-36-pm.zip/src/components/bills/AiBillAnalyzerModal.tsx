import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { AiService } from '../../services/aiService';
import { AiAnalysisResult } from '../../types';
import {
  X,
  Send,
  Building,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';

interface QnA {
  question: string;
  answer: string;
}

export const AiBillAnalyzerModal: React.FC = () => {
  const {
    isAiAnalyzerOpen,
    activeBillForAnalysis,
    closeAiAnalyzer,
    previousBill,
    activeConnection,
  } = useApp();

  const [analysisResult, setAnalysisResult] = useState<AiAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [customQuestion, setCustomQuestion] = useState('');
  const [isAsking, setIsAsking] = useState(false);
  const [qaHistory, setQaHistory] = useState<QnA[]>([]);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isAiAnalyzerOpen && activeBillForAnalysis) {
      loadExecutiveAnalysis();
      setQaHistory([]);
      setCustomQuestion('');
    }
  }, [isAiAnalyzerOpen, activeBillForAnalysis]);

  const loadExecutiveAnalysis = async () => {
    if (!activeBillForAnalysis) return;
    setIsLoading(true);

    try {
      const result = await AiService.analyzeBill(
        activeBillForAnalysis,
        previousBill,
        activeConnection.displayName
      );
      setAnalysisResult(result);
    } catch (err) {
      console.error('Error generating AI analysis:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAskQuestion = async (queryText?: string) => {
    const q = (queryText || customQuestion).trim();
    if (!q || isAsking) return;

    setIsAsking(true);
    setCustomQuestion('');

    try {
      const answer = await AiService.chat(
        [{ role: 'user', content: q }],
        {
          connectionName: activeConnection.displayName,
          currentBillAmount: activeBillForAnalysis?.totalAmount,
          currentUnits: activeBillForAnalysis?.unitsConsumed,
          serviceProvider: activeBillForAnalysis?.serviceProvider,
          billStatus: activeBillForAnalysis?.paymentStatus,
          billingMonth: activeBillForAnalysis?.billingMonth,
        }
      );

      setQaHistory((prev) => [...prev, { question: q, answer }]);
      setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    } catch {
      setQaHistory((prev) => [
        ...prev,
        {
          question: q,
          answer: 'Unable to analyze this question right now. Please try again.',
        },
      ]);
    } finally {
      setIsAsking(false);
    }
  };

  if (!isAiAnalyzerOpen || !activeBillForAnalysis) return null;

  const bill = activeBillForAnalysis;

  const suggestedQuestions = [
    'What is Fuel Price Adjustment (FPA)?',
    'Why is my bill higher than last month?',
    'What percentage of my bill is taxes and surcharges?',
    'What are the most effective ways to lower this bill?',
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-white border border-[#D1D5DB] w-full max-w-xl rounded-md shadow-xl overflow-hidden flex flex-col max-h-[92vh] text-[#1D2A44]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#D1D5DB] bg-[#F4F6F8]">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#003366] text-xs uppercase tracking-wide">
              Plain-Language Bill Explainer
            </span>
            <span className="text-slate-400">•</span>
            <span className="text-xs text-slate-600 font-medium">
              {bill.billingMonth} Statement
            </span>
          </div>

          <button
            onClick={closeAiAnalyzer}
            className="p-1 rounded text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
            title="Close dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto p-5 space-y-4 bg-white">
          {/* Bill reference header */}
          <div className="p-3 bg-[#F4F6F8] rounded border border-[#D1D5DB] flex items-center justify-between text-xs">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Statement Under Review</span>
              <span className="font-bold text-[#0B2545] text-sm">{bill.billingMonth} Invoice</span>
              <span className="text-[11px] text-slate-600 block mt-0.5">
                {bill.serviceProvider || activeConnection.serviceProvider}
              </span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Total Payable</span>
              <span className="font-mono text-base font-black text-[#003366]">
                Rs. {bill.totalAmount.toLocaleString()}
              </span>
              <span className="text-[11px] text-slate-600 block font-medium">
                {bill.unitsConsumed} Units Billed
              </span>
            </div>
          </div>

          {/* Loading State */}
          {isLoading && (
            <div className="py-10 text-center space-y-3">
              <div className="w-7 h-7 rounded-full border-2 border-[#003366] border-t-transparent animate-spin mx-auto" />
              <p className="text-xs text-slate-600">Analyzing bill line items against NEPRA tariff slabs...</p>
            </div>
          )}

          {/* Analysis Content */}
          {!isLoading && analysisResult && (
            <div className="space-y-4 text-xs">
              {/* 1. Plain-Language Executive Summary */}
              <div className="p-3.5 rounded bg-white border border-[#D1D5DB] space-y-1.5">
                <span className="text-[11px] font-bold text-[#003366] uppercase tracking-wider block">
                  Plain-Language Summary
                </span>
                <p className="text-slate-800 leading-relaxed font-normal">
                  {analysisResult.summary}
                </p>
              </div>

              {/* 2. Key Highlights */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded bg-[#F4F6F8] border border-[#D1D5DB] space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-600 block">Base Electricity</span>
                  <span className="font-mono font-bold text-slate-900 text-sm">
                    Rs. {bill.costOfElectricity.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-500 block">
                    {Math.round((bill.costOfElectricity / bill.totalAmount) * 100)}% of total invoice
                  </span>
                </div>

                <div className="p-3 rounded bg-[#F4F6F8] border border-[#D1D5DB] space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-600 block">Taxes & Surcharges</span>
                  <span className="font-mono font-bold text-slate-900 text-sm">
                    Rs. {(bill.totalAmount - bill.costOfElectricity).toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-500 block">
                    FPA, FC, Duty, TV & GST
                  </span>
                </div>
              </div>

              {/* 3. Detailed Charge Breakdown Explanation */}
              {analysisResult.chargeBreakdown && (
                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-[#0B2545] uppercase tracking-wider block">
                    Itemized Charge Explanations:
                  </span>
                  <div className="space-y-1.5">
                    {analysisResult.chargeBreakdown.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded bg-[#F4F6F8] border border-[#D1D5DB] space-y-0.5"
                      >
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-slate-900">{item.name}</span>
                          <span className="font-mono font-bold text-[#003366]">
                            Rs. {item.amount.toLocaleString()}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 leading-normal">{item.explanation}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 4. Actionable Recommendations */}
              {analysisResult.recommendations && (
                <div className="p-3.5 rounded bg-[#F4F6F8] border border-[#D1D5DB] space-y-2">
                  <span className="text-[11px] font-bold text-[#0F5132] uppercase tracking-wider block">
                    Energy Conservation Recommendations:
                  </span>
                  <ul className="space-y-1.5 text-slate-800">
                    {analysisResult.recommendations.map((rec, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#0F5132] shrink-0 mt-0.5" />
                        <span className="text-[11px] leading-snug">{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* 5. Custom Questions */}
              <div className="p-3.5 rounded bg-white border border-[#D1D5DB] space-y-3">
                <span className="text-[11px] font-bold text-[#0B2545] uppercase tracking-wider block">
                  Ask a Specific Question About This Bill:
                </span>

                <div className="flex flex-wrap gap-1.5">
                  {suggestedQuestions.map((q, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleAskQuestion(q)}
                      className="text-[11px] px-2.5 py-1 rounded bg-[#F4F6F8] hover:bg-slate-200 border border-[#D1D5DB] text-slate-700 hover:text-slate-900 transition-colors text-left cursor-pointer font-medium"
                    >
                      {q}
                    </button>
                  ))}
                </div>

                {qaHistory.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-[#D1D5DB]">
                    {qaHistory.map((item, idx) => (
                      <div key={idx} className="space-y-1 text-xs">
                        <div className="font-bold text-[#003366] bg-[#F4F6F8] p-2 rounded border border-[#D1D5DB]">
                          Q: {item.question}
                        </div>
                        <div className="text-slate-800 bg-white p-2.5 rounded border border-[#D1D5DB] leading-relaxed whitespace-pre-line">
                          {item.answer}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {isAsking && (
                  <div className="p-2.5 rounded bg-[#F4F6F8] border border-[#D1D5DB] text-slate-600 text-xs flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#003366] animate-pulse" />
                    <span>Analyzing your question...</span>
                  </div>
                )}

                <div ref={chatEndRef} />

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleAskQuestion();
                  }}
                  className="flex items-center gap-2 pt-1"
                >
                  <input
                    type="text"
                    value={customQuestion}
                    onChange={(e) => setCustomQuestion(e.target.value)}
                    placeholder="Type your question about charges or slabs..."
                    className="flex-1 bg-white border border-[#D1D5DB] rounded px-3 py-1.5 text-xs text-slate-900 focus:border-[#003366]"
                  />
                  <button
                    type="submit"
                    disabled={!customQuestion.trim() || isAsking}
                    className="py-1.5 px-4 bg-[#003366] hover:bg-[#0B2545] disabled:opacity-50 text-white rounded text-xs font-bold transition-colors cursor-pointer"
                  >
                    Submit
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#D1D5DB] bg-[#F4F6F8] flex justify-between items-center">
          <button
            onClick={loadExecutiveAnalysis}
            disabled={isLoading}
            className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-[#003366] font-semibold cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Re-analyze</span>
          </button>
          <button
            onClick={closeAiAnalyzer}
            className="py-1.5 px-4 rounded bg-white border border-[#D1D5DB] hover:bg-slate-100 text-slate-800 font-bold text-xs cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
