import React, { useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Printer,
  CheckCircle2,
  Building,
  Clock,
  FileDown,
} from 'lucide-react';

export const BillDetailsModal: React.FC = () => {
  const {
    isBillDetailsModalOpen,
    activeBillForDetails,
    closeBillDetails,
    openAiAnalyzer,
    openPaymentModal,
    openPdfReport,
    activeConnection,
    user,
  } = useApp();

  const printAreaRef = useRef<HTMLDivElement>(null);

  if (!isBillDetailsModalOpen || !activeBillForDetails) return null;

  const bill = activeBillForDetails;
  const isUnpaid = bill.paymentStatus === 'unpaid';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-white border border-[#D1D5DB] w-full max-w-xl rounded-md shadow-xl overflow-hidden flex flex-col max-h-[92vh] text-[#1D2A44]">
        {/* Top Control Bar */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#D1D5DB] bg-[#F4F6F8] no-print">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#003366] text-xs uppercase tracking-wide">
              Official Invoice Statement
            </span>
            <span className="text-slate-400">•</span>
            <span className="text-xs font-mono font-medium text-slate-600">
              Ref: {bill.billId}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                closeBillDetails();
                openPdfReport();
              }}
              className="flex items-center gap-1.5 py-1 px-2.5 bg-white border border-[#D1D5DB] text-slate-700 hover:text-[#003366] hover:bg-[#F4F6F8] rounded text-xs font-semibold transition-colors cursor-pointer"
              title="Export Full Summary PDF"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span>Export PDF</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 py-1 px-2.5 bg-white border border-[#D1D5DB] text-slate-700 hover:bg-[#F4F6F8] rounded text-xs font-semibold transition-colors cursor-pointer"
              title="Print Statement"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>

            <button
              onClick={closeBillDetails}
              className="p-1 rounded text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
              title="Close dialog"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Invoice Statement Content */}
        <div className="overflow-y-auto p-6 space-y-5 bg-white" ref={printAreaRef}>
          {/* Header */}
          <div className="border-b border-[#D1D5DB] pb-4 flex flex-col sm:flex-row justify-between sm:items-start gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="bg-[#003366] text-white font-bold text-[10px] px-1.5 py-0.2 rounded">
                  GOP
                </span>
                <span className="text-[11px] font-bold text-slate-600 uppercase">
                  Government of Punjab • Public Utility Billing
                </span>
              </div>
              <h2 className="text-lg font-bold text-[#0B2545] tracking-tight">
                {bill.serviceProvider || activeConnection.serviceProvider || 'LESCO (Lahore Electric Supply Company)'}
              </h2>
              <p className="text-xs text-slate-600 mt-0.5">
                Sub-Division: {activeConnection.subDivision} • Feeder: {activeConnection.feederName}
              </p>
            </div>

            <div className="text-left sm:text-right">
              <span
                className={`inline-block text-[11px] font-bold uppercase px-2.5 py-0.5 rounded border ${
                  isUnpaid
                    ? 'bg-[#F8D7DA] text-[#842029] border-[#F5C2C7]'
                    : 'bg-[#D1E7DD] text-[#0F5132] border-[#BADBCC]'
                }`}
              >
                {isUnpaid ? 'Payment Due' : 'Paid in Full'}
              </span>
              <div className="text-xs font-mono text-slate-600 mt-1">
                Billing Cycle: <strong className="text-slate-900">{bill.billingMonth}</strong>
              </div>
            </div>
          </div>

          {/* Consumer and Connection Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-[#F4F6F8] p-3.5 rounded border border-[#D1D5DB] text-xs">
            <div>
              <span className="text-[10px] text-slate-500 block uppercase font-medium">Consumer Name</span>
              <span className="font-bold text-slate-900">{user.name}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block uppercase font-medium">Consumer Reference</span>
              <span className="font-mono font-bold text-[#003366]">{activeConnection.referenceNumber}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block uppercase font-medium">Meter Number</span>
              <span className="font-mono text-slate-800">{activeConnection.maskedMeterNumber}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block uppercase font-medium">Tariff Category</span>
              <span className="text-slate-800">{activeConnection.tariff}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block uppercase font-medium">Sanctioned Load</span>
              <span className="text-slate-800">{activeConnection.sanctionedLoad}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block uppercase font-medium">Meter Reading Dates</span>
              <span className="text-slate-800 text-[11px]">{bill.billingPeriod}</span>
            </div>
          </div>

          {/* Meter Readings & Due Date Box */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
            <div className="p-2.5 rounded bg-[#F4F6F8] border border-[#D1D5DB]">
              <span className="text-[10px] text-slate-500 block uppercase font-medium">Previous Reading</span>
              <span className="font-mono text-sm font-bold text-slate-800 mt-0.5 block">
                {bill.previousReading.toLocaleString()}
              </span>
            </div>
            <div className="p-2.5 rounded bg-[#F4F6F8] border border-[#D1D5DB]">
              <span className="text-[10px] text-slate-500 block uppercase font-medium">Present Reading</span>
              <span className="font-mono text-sm font-bold text-slate-800 mt-0.5 block">
                {bill.currentReading.toLocaleString()}
              </span>
            </div>
            <div className="p-2.5 rounded bg-[#F4F6F8] border border-[#003366]/40">
              <span className="text-[10px] text-[#003366] block uppercase font-bold">Units Billed (kWh)</span>
              <span className="font-mono text-sm font-black text-[#003366] mt-0.5 block">
                {bill.unitsConsumed} Units
              </span>
            </div>
            <div className="p-2.5 rounded bg-[#F4F6F8] border border-[#D1D5DB]">
              <span className="text-[10px] text-slate-600 block uppercase font-bold">Due Date</span>
              <span className="text-xs font-bold text-slate-900 mt-0.5 block">
                {bill.dueDate}
              </span>
            </div>
          </div>

          {/* Itemized Charge Line Items Table */}
          <div className="rounded border border-[#D1D5DB] overflow-hidden text-xs">
            <div className="px-3.5 py-2 bg-[#F4F6F8] border-b border-[#D1D5DB] flex justify-between font-bold text-[#0B2545] text-[11px] uppercase tracking-wider">
              <span>Itemized Charge Description</span>
              <span>Amount (PKR)</span>
            </div>
            <div className="divide-y divide-slate-200">
              <div className="px-3.5 py-2 flex justify-between">
                <div>
                  <span className="text-slate-900 font-semibold">Cost of Electricity (Base Energy)</span>
                  <span className="text-[10px] text-slate-500 block">Calculated across statutory residential slab tiers</span>
                </div>
                <span className="font-mono font-bold text-slate-900">
                  Rs. {bill.costOfElectricity.toLocaleString()}
                </span>
              </div>

              <div className="px-3.5 py-2 flex justify-between">
                <div>
                  <span className="text-slate-900 font-semibold">Fuel Price Adjustment (FPA)</span>
                  <span className="text-[10px] text-slate-500 block">Generation fuel mix monthly variance pass-through</span>
                </div>
                <span className="font-mono font-bold text-slate-900">
                  Rs. {bill.fuelPriceAdjustment.toLocaleString()}
                </span>
              </div>

              <div className="px-3.5 py-2 flex justify-between">
                <div>
                  <span className="text-slate-900 font-semibold">Financing Cost (FC) Surcharge</span>
                  <span className="text-[10px] text-slate-500 block">Debt servicing statutory surcharge</span>
                </div>
                <span className="font-mono font-bold text-slate-900">
                  Rs. {bill.fcSurcharge.toLocaleString()}
                </span>
              </div>

              <div className="px-3.5 py-2 flex justify-between">
                <div>
                  <span className="text-slate-900 font-semibold">Provincial Electricity Duty (1.5%)</span>
                  <span className="text-[10px] text-slate-500 block">Government of Punjab revenue assessment</span>
                </div>
                <span className="font-mono font-bold text-slate-900">
                  Rs. {bill.electricityDuty.toLocaleString()}
                </span>
              </div>

              <div className="px-3.5 py-2 flex justify-between">
                <div>
                  <span className="text-slate-900 font-semibold">PTV License Fee</span>
                  <span className="text-[10px] text-slate-500 block">Statutory broadcasting fee</span>
                </div>
                <span className="font-mono font-bold text-slate-900">
                  Rs. {bill.tvFee.toLocaleString()}
                </span>
              </div>

              <div className="px-3.5 py-2 flex justify-between">
                <div>
                  <span className="text-slate-900 font-semibold">General Sales Tax (GST 17%)</span>
                  <span className="text-[10px] text-slate-500 block">Federal statutory sales tax</span>
                </div>
                <span className="font-mono font-bold text-slate-900">
                  Rs. {bill.salesTax.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Total Section */}
            <div className="p-3.5 bg-[#F4F6F8] border-t border-[#D1D5DB] space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-800 uppercase">
                  Payable Within Due Date ({bill.dueDate}):
                </span>
                <span className="text-xl font-black font-mono text-[#0B2545]">
                  Rs. {bill.totalAmount.toLocaleString()}
                </span>
              </div>

              {isUnpaid && (
                <div className="flex justify-between items-center text-[11px] text-slate-600 pt-1 border-t border-slate-300">
                  <span>Payable After Due Date (includes late surcharge):</span>
                  <span className="font-mono font-bold text-[#842029]">
                    Rs. {bill.amountAfterDueDate.toLocaleString()}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Paid Confirmation Box */}
          {!isUnpaid && (
            <div className="p-3 rounded bg-[#D1E7DD] border border-[#BADBCC] flex items-center justify-between text-xs text-[#0F5132]">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <div>
                  <span className="font-bold block">Settlement Confirmed</span>
                  <p className="text-[11px] text-emerald-800">
                    Paid via {bill.paidMethod || 'Electronic Transfer'} • Ref: {bill.transactionId || 'TXN-09281'}
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-mono font-bold">
                {bill.paidAt ? new Date(bill.paidAt).toLocaleDateString() : 'Settled'}
              </span>
            </div>
          )}
        </div>

        {/* Footer Actions: Flat rectangular standard government buttons */}
        <div className="p-3.5 border-t border-[#D1D5DB] bg-[#F4F6F8] flex flex-col sm:flex-row items-center justify-between gap-2 no-print">
          <button
            onClick={() => {
              closeBillDetails();
              openAiAnalyzer(bill);
            }}
            className="w-full sm:w-auto py-2 px-4 rounded bg-white hover:bg-slate-100 text-[#003366] border border-[#003366] text-xs font-bold transition-colors cursor-pointer"
          >
            Explain in Plain Language
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={closeBillDetails}
              className="py-2 px-4 rounded border border-[#D1D5DB] bg-white text-slate-700 hover:bg-slate-100 text-xs font-semibold"
            >
              Close
            </button>

            {isUnpaid ? (
              <button
                onClick={() => {
                  closeBillDetails();
                  openPaymentModal(bill);
                }}
                className="py-2 px-5 rounded bg-[#003366] hover:bg-[#0B2545] text-white text-xs font-bold transition-colors cursor-pointer shadow-none"
              >
                Pay Bill Online
              </button>
            ) : (
              <button
                onClick={handlePrint}
                className="py-2 px-4 rounded bg-[#003366] text-white text-xs font-bold flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Invoice</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
