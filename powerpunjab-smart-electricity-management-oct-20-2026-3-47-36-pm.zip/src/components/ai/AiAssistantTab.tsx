import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { AiService } from '../../services/aiService';
import { ChatMessage } from '../../types';
import {
  Send,
  Trash2,
  Building,
  HelpCircle,
  FileText,
} from 'lucide-react';

export const AiAssistantTab: React.FC = () => {
  const { user, activeConnection, currentBill } = useApp();

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `Welcome to the PowerPunjab Automated Utility Inquiry Service. I have access to your active connection records for **${activeConnection.displayName}** (Account Reference: ${activeConnection.referenceNumber}) and your current October bill of **Rs. ${currentBill?.totalAmount.toLocaleString()}** (${currentBill?.unitsConsumed} kWh units).\n\nYou may ask any question regarding your electricity charges, fuel adjustments, statutory slab rates, or how to reduce your monthly bill.`,
      timestamp: 'Active Session',
    },
  ]);

  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestedPrompts = [
    'Explain my October 2026 bill in simple terms',
    'Why did my bill increase from last month?',
    'What are the current NEPRA residential slab rates?',
    'How much does a 1.5 ton Inverter AC cost per hour?',
    'How do I report low voltage or power fluctuations?',
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || isTyping) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await AiService.chat(
        [...messages, userMsg].map((m) => ({ role: m.role, content: m.content })),
        {
          userName: user.name,
          connectionName: `${activeConnection.displayName} (${activeConnection.referenceNumber})`,
          currentBillAmount: currentBill?.totalAmount,
          currentUnits: currentBill?.unitsConsumed,
          billStatus: currentBill?.paymentStatus,
        }
      );

      const aiMsg: ChatMessage = {
        id: `msg-ai-${Date.now()}`,
        role: 'assistant',
        content: response,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-err-${Date.now()}`,
          role: 'assistant',
          content: 'Unable to reach the utility information server. Please try again shortly.',
          timestamp: 'Now',
        },
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  const clearChat = () => {
    setMessages([
      {
        id: 'welcome-reset',
        role: 'assistant',
        content: `Inquiry history cleared. Please enter your question regarding billing line items, slab tiers, or appliance consumption.`,
        timestamp: 'New Session',
      },
    ]);
  };

  return (
    <div className="space-y-4">
      {/* Page Header */}
      <div className="bg-white border border-[#D1D5DB] rounded-md p-5 shadow-xs flex items-center justify-between">
        <div>
          <span className="text-[11px] font-bold text-[#003366] uppercase tracking-wider block">
            Automated Consumer Support
          </span>
          <h2 className="text-xl font-bold text-[#0B2545] tracking-tight">
            Bill Explainer & Public Inquiry Desk
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Verified answers grounded in your active meter records and NEPRA guidelines
          </p>
        </div>

        <button
          onClick={clearChat}
          className="flex items-center gap-1.5 py-1.5 px-3 bg-[#F4F6F8] hover:bg-slate-200 text-slate-700 border border-[#D1D5DB] text-xs font-semibold rounded transition-colors cursor-pointer"
          title="Reset conversation"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear History</span>
        </button>
      </div>

      {/* Suggested Inquiries */}
      <div className="bg-white border border-[#D1D5DB] rounded-md p-3.5 shadow-xs space-y-2">
        <span className="text-[11px] font-bold text-[#003366] uppercase tracking-wider block">
          Frequently Asked Inquiries:
        </span>
        <div className="flex flex-wrap gap-2">
          {suggestedPrompts.map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleSend(prompt)}
              className="text-xs px-3 py-1.5 rounded bg-[#F4F6F8] hover:bg-slate-200 border border-[#D1D5DB] text-slate-800 transition-colors cursor-pointer text-left font-medium"
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Main Conversation Container */}
      <div className="bg-white border border-[#D1D5DB] rounded-md shadow-xs flex flex-col h-[520px]">
        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
              >
                <div className="text-[10px] font-bold uppercase text-slate-500 mb-1 px-1">
                  {isUser ? user.name : 'PowerPunjab Automated Advisory'}
                </div>

                <div
                  className={`max-w-[85%] rounded p-3.5 text-xs leading-relaxed border ${
                    isUser
                      ? 'bg-[#003366] text-white border-[#003366]'
                      : 'bg-[#F4F6F8] text-[#1D2A44] border-[#D1D5DB]'
                  }`}
                >
                  <div className="whitespace-pre-line font-normal">{msg.content}</div>
                  <div
                    className={`text-[9px] mt-2 text-right ${
                      isUser ? 'text-slate-300' : 'text-slate-500'
                    }`}
                  >
                    {msg.timestamp}
                  </div>
                </div>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex flex-col items-start">
              <div className="text-[10px] font-bold uppercase text-slate-500 mb-1 px-1">
                PowerPunjab Advisory
              </div>
              <div className="p-3 bg-[#F4F6F8] border border-[#D1D5DB] rounded text-xs text-slate-600 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#003366] animate-pulse" />
                <span>Retrieving verified tariff explanation...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 border-t border-[#D1D5DB] bg-[#F4F6F8] flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your electricity bill inquiry or question here..."
            className="flex-1 bg-white border border-[#D1D5DB] rounded px-3.5 py-2 text-xs text-slate-900 placeholder:text-slate-500 focus:border-[#003366]"
          />
          <button
            type="submit"
            disabled={!input.trim() || isTyping}
            className="py-2 px-5 bg-[#003366] hover:bg-[#0B2545] disabled:opacity-50 text-white font-bold text-xs rounded transition-colors cursor-pointer shadow-none"
          >
            Submit Inquiry
          </button>
        </form>
      </div>
    </div>
  );
};
