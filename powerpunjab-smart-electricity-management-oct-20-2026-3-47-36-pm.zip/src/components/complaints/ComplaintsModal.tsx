import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Complaint } from '../../types';
import {
  X,
  AlertTriangle,
  Plus,
  Clock,
  CheckCircle2,
  ChevronRight,
  Send,
  UserCheck,
} from 'lucide-react';

export const ComplaintsModal: React.FC = () => {
  const {
    isComplaintsModalOpen,
    closeComplaintsModal,
    complaints,
    submitComplaint,
    activeConnection,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'list' | 'new' | 'detail'>('list');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);

  // New Complaint Form State
  const [category, setCategory] = useState<Complaint['category']>('Low Voltage');
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState(activeConnection.address);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isComplaintsModalOpen) return null;

  const categories: Complaint['category'][] = [
    'Power Outage',
    'Low Voltage',
    'Billing Issue',
    'Meter Issue',
    'Transformer Issue',
    'Other Issue',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      setErrorMsg('Please enter a description of the issue.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      submitComplaint({
        category,
        description: description.trim(),
        address: address.trim(),
      });
      setIsSubmitting(false);
      setDescription('');
      setErrorMsg('');
      setActiveTab('list');
    }, 600);
  };

  const getStatusBadge = (status: Complaint['status']) => {
    switch (status) {
      case 'Submitted':
        return <span className="text-[10px] font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">Submitted</span>;
      case 'Under Review':
        return <span className="text-[10px] font-bold text-[#003366] bg-blue-50 px-2 py-0.5 rounded border border-blue-200">Under Review</span>;
      case 'Assigned':
        return <span className="text-[10px] font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded border border-slate-300">Line Crew Assigned</span>;
      case 'Resolved':
        return <span className="text-[10px] font-bold text-[#0F5132] bg-[#D1E7DD] px-2 py-0.5 rounded border border-[#BADBCC]">Resolved</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-white border border-[#D1D5DB] w-full max-w-lg rounded-md shadow-xl overflow-hidden flex flex-col max-h-[92vh] text-[#1D2A44]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#D1D5DB] bg-[#F4F6F8]">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#003366] text-xs uppercase tracking-wide">
              Consumer Grievance & Outage Desk
            </span>
          </div>
          <button
            onClick={closeComplaintsModal}
            className="p-1 rounded text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switchers if not viewing single detail */}
        {activeTab !== 'detail' && (
          <div className="flex border-b border-[#D1D5DB] bg-[#F4F6F8] px-4 pt-2 gap-2 text-xs font-bold">
            <button
              onClick={() => setActiveTab('list')}
              className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer ${
                activeTab === 'list'
                  ? 'border-[#003366] text-[#003366]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              Registered Complaints ({complaints.length})
            </button>
            <button
              onClick={() => setActiveTab('new')}
              className={`pb-2 px-3 border-b-2 transition-colors flex items-center gap-1 cursor-pointer ${
                activeTab === 'new'
                  ? 'border-[#003366] text-[#003366]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Lodge New Grievance</span>
            </button>
          </div>
        )}

        {/* Body */}
        <div className="overflow-y-auto p-5 space-y-4 bg-white">
          {/* TAB 1: LIST VIEW */}
          {activeTab === 'list' && (
            <div className="space-y-3">
              {complaints.length === 0 ? (
                <div className="text-center py-12 space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-[#0F5132] mx-auto" />
                  <h4 className="text-sm font-bold text-slate-800">No active complaints on record</h4>
                  <p className="text-xs text-slate-500">Your connection is operating normally.</p>
                </div>
              ) : (
                complaints.map((item) => (
                  <div
                    key={item.complaintId}
                    onClick={() => {
                      setSelectedComplaint(item);
                      setActiveTab('detail');
                    }}
                    className="p-3.5 rounded bg-[#F4F6F8] hover:bg-slate-100 border border-[#D1D5DB] transition-all cursor-pointer space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-[#003366]">
                          {item.complaintId}
                        </span>
                        <span className="text-xs font-bold text-slate-900">• {item.category}</span>
                      </div>
                      {getStatusBadge(item.status)}
                    </div>

                    <p className="text-xs text-slate-700 leading-normal">
                      {item.description}
                    </p>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-[#D1D5DB]">
                      <span>Logged: {item.createdAt}</span>
                      <span className="text-[#003366] font-semibold flex items-center gap-0.5">
                        Track Progress <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 2: NEW COMPLAINT FORM */}
          {activeTab === 'new' && (
            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
              {errorMsg && (
                <div className="p-2.5 rounded bg-[#F8D7DA] border border-[#F5C2C7] text-[#842029]">
                  {errorMsg}
                </div>
              )}

              <div>
                <label className="text-[11px] font-bold text-[#1D2A44] block mb-1">
                  Electricity Connection Reference
                </label>
                <div className="p-2.5 rounded bg-[#F4F6F8] border border-[#D1D5DB] text-xs text-slate-800 font-semibold">
                  {activeConnection.displayName} ({activeConnection.referenceNumber})
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-[#1D2A44] block mb-1">
                  Issue Category *
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-2 text-xs text-slate-900 focus:border-[#003366]"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-[#1D2A44] block mb-1">
                  Description of Grievance *
                </label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide exact details (e.g. low voltage drop after 7 PM, sparking line, reading mismatch)..."
                  className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:border-[#003366]"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-[#1D2A44] block mb-1">
                  Physical Address / Landmark
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Street / House location"
                  className="w-full bg-white border border-[#D1D5DB] rounded px-3 py-2 text-xs text-slate-900 focus:border-[#003366]"
                />
              </div>

              <div className="p-2.5 rounded bg-[#F4F6F8] border border-[#D1D5DB] text-[11px] text-slate-600">
                Official registration dispatches a complaint tracking ID to the sub-divisional complaint registry.
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('list')}
                  className="py-2 px-4 rounded border border-[#D1D5DB] bg-white text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="py-2 px-5 rounded bg-[#003366] hover:bg-[#0B2545] text-white text-xs font-bold transition-colors cursor-pointer shadow-none"
                >
                  {isSubmitting ? 'Registering...' : 'Register Complaint'}
                </button>
              </div>
            </form>
          )}

          {/* TAB 3: DETAIL VIEW */}
          {activeTab === 'detail' && selectedComplaint && (
            <div className="space-y-4 text-xs">
              <button
                onClick={() => setActiveTab('list')}
                className="text-xs text-[#003366] hover:underline font-semibold cursor-pointer"
              >
                ← Back to registered complaints
              </button>

              <div className="p-4 rounded bg-[#F4F6F8] border border-[#D1D5DB] space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-mono text-base font-bold text-[#0B2545]">
                      {selectedComplaint.complaintId}
                    </span>
                    <span className="text-xs text-slate-600 block">{selectedComplaint.category}</span>
                  </div>
                  {getStatusBadge(selectedComplaint.status)}
                </div>

                <p className="text-xs text-slate-800 pt-2 border-t border-[#D1D5DB] leading-relaxed">
                  {selectedComplaint.description}
                </p>

                {selectedComplaint.assignedTo && (
                  <div className="flex items-center gap-2 pt-2 text-xs text-[#003366]">
                    <UserCheck className="w-4 h-4 shrink-0" />
                    <span>Assigned Supervisor: <strong>{selectedComplaint.assignedTo}</strong></span>
                  </div>
                )}
              </div>

              {/* Official Tracking Timeline */}
              <div className="p-4 rounded bg-white border border-[#D1D5DB] space-y-3">
                <span className="text-xs font-bold text-[#0B2545] block">
                  Official Progress Timeline
                </span>

                <div className="relative pl-6 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#D1D5DB]">
                  {selectedComplaint.timeline.map((step, idx) => (
                    <div key={idx} className="relative">
                      <div className="absolute -left-6 top-0.5 w-2.5 h-2.5 rounded-full bg-[#003366] ring-4 ring-white" />
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-900">{step.status}</span>
                          <span className="text-[10px] text-slate-500 font-mono">{step.timestamp}</span>
                        </div>
                        <p className="text-[11px] text-slate-600 mt-0.5">{step.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#D1D5DB] bg-[#F4F6F8] flex justify-end">
          <button
            onClick={closeComplaintsModal}
            className="py-1.5 px-4 rounded bg-white border border-[#D1D5DB] hover:bg-slate-100 text-slate-700 font-bold text-xs cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
