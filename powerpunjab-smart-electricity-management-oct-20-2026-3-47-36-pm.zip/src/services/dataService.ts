import {
  UserProfile,
  ElectricityConnection,
  Bill,
  PaymentRecord,
  Complaint,
  AppNotification,
  MonthlyUsage,
  AppliancePreset,
  TariffSlab,
  EducationArticle,
} from '../types';

const STORAGE_KEY_PREFIX = 'powerpunjab_v2_';

export const INITIAL_USER: UserProfile = {
  userId: 'usr_demo_8820',
  name: 'Ahmed Khan',
  email: 'demo@powerpunjab.demo',
  phone: '+92 300 9876543',
  accountType: 'demo',
  createdAt: '2026-01-15T08:00:00Z',
  notificationsEnabled: true,
  theme: 'dark',
  language: 'en',
};

export const INITIAL_CONNECTIONS: ElectricityConnection[] = [
  {
    connectionId: 'CONN-LHR-10284',
    userId: 'usr_demo_8820',
    displayName: 'Home Residence',
    referenceNumber: '08-11234-0102840-U',
    maskedMeterNumber: '08-****-1940',
    serviceProvider: 'LESCO (Lahore Electric Supply Company)',
    connectionType: 'Residential Single-Phase',
    sanctionedLoad: '5.0 kW',
    tariff: 'A-1a Residential',
    address: 'House 42-B, Model Town, Lahore',
    feederName: 'Gulberg-II 11kV Feeder',
    subDivision: 'Model Town Sub-Division (Div 4)',
    isActive: true,
  },
  {
    connectionId: 'CONN-LHR-20591',
    userId: 'usr_demo_8820',
    displayName: 'Commercial Office',
    referenceNumber: '14-22901-0205910-U',
    maskedMeterNumber: '14-****-7812',
    serviceProvider: 'LESCO (Lahore Electric Supply Company)',
    connectionType: 'Residential 3-Phase',
    sanctionedLoad: '12.0 kW',
    tariff: 'A-2 Commercial 3-Phase',
    address: 'Plaza 18-C, Commercial Zone, DHA Phase 5, Lahore',
    feederName: 'DHA Cantt 11kV Feeder',
    subDivision: 'DHA Sub-Division 1',
    isActive: false,
  },
  {
    connectionId: 'CONN-FSD-30882',
    userId: 'usr_demo_8820',
    displayName: "Parents' Residence",
    referenceNumber: '05-99120-0308820-U',
    maskedMeterNumber: '05-****-4431',
    serviceProvider: 'FESCO (Faisalabad Electric Supply Company)',
    connectionType: 'Residential Single-Phase',
    sanctionedLoad: '3.0 kW',
    tariff: 'A-1a Residential',
    address: 'Street 7, Madina Town, Faisalabad',
    feederName: 'Madina Town Feeder',
    subDivision: 'Faisalabad East Electric',
    isActive: false,
  },
];

export const INITIAL_BILLS: Bill[] = [
  {
    billId: 'INV-2026-10-8450',
    connectionId: 'CONN-LHR-10284',
    userId: 'usr_demo_8820',
    serviceProvider: 'LESCO (Lahore Electric Supply Company)',
    billingMonth: 'October 2026',
    billingPeriod: '12 Sep 2026 - 12 Oct 2026',
    issueDate: '14 Oct 2026',
    dueDate: '24 Oct 2026',
    unitsConsumed: 496,
    previousReading: 14820,
    currentReading: 15316,
    costOfElectricity: 5700,
    fuelPriceAdjustment: 890,
    fcSurcharge: 450,
    electricityDuty: 120,
    tvFee: 35,
    salesTax: 1255,
    totalAmount: 8450,
    amountAfterDueDate: 9150,
    paymentStatus: 'unpaid',
  },
  {
    billId: 'INV-2026-09-7820',
    connectionId: 'CONN-LHR-10284',
    userId: 'usr_demo_8820',
    serviceProvider: 'LESCO (Lahore Electric Supply Company)',
    billingMonth: 'September 2026',
    billingPeriod: '12 Aug 2026 - 12 Sep 2026',
    issueDate: '14 Sep 2026',
    dueDate: '24 Sep 2026',
    unitsConsumed: 420,
    previousReading: 14400,
    currentReading: 14820,
    costOfElectricity: 5280,
    fuelPriceAdjustment: 810,
    fcSurcharge: 410,
    electricityDuty: 110,
    tvFee: 35,
    salesTax: 1175,
    totalAmount: 7820,
    amountAfterDueDate: 8450,
    paymentStatus: 'paid',
    paidAt: '2026-09-18T14:22:00Z',
    paidMethod: 'Bank Transfer (1Bill IBFT)',
    transactionId: 'TXN-HBL-941824',
  },
  {
    billId: 'INV-2026-08-8100',
    connectionId: 'CONN-LHR-10284',
    userId: 'usr_demo_8820',
    serviceProvider: 'LESCO (Lahore Electric Supply Company)',
    billingMonth: 'August 2026',
    billingPeriod: '12 Jul 2026 - 12 Aug 2026',
    issueDate: '14 Aug 2026',
    dueDate: '24 Aug 2026',
    unitsConsumed: 440,
    previousReading: 13960,
    currentReading: 14400,
    costOfElectricity: 5490,
    fuelPriceAdjustment: 850,
    fcSurcharge: 420,
    electricityDuty: 115,
    tvFee: 35,
    salesTax: 1190,
    totalAmount: 8100,
    amountAfterDueDate: 8750,
    paymentStatus: 'paid',
    paidAt: '2026-08-19T11:05:00Z',
    paidMethod: 'Mobile Banking App',
    transactionId: 'TXN-MEEZAN-882103',
  },
  {
    billId: 'INV-2026-07-7200',
    connectionId: 'CONN-LHR-10284',
    userId: 'usr_demo_8820',
    serviceProvider: 'LESCO (Lahore Electric Supply Company)',
    billingMonth: 'July 2026',
    billingPeriod: '12 Jun 2026 - 12 Jul 2026',
    issueDate: '14 Jul 2026',
    dueDate: '24 Jul 2026',
    unitsConsumed: 390,
    previousReading: 13570,
    currentReading: 13960,
    costOfElectricity: 4890,
    fuelPriceAdjustment: 740,
    fcSurcharge: 380,
    electricityDuty: 100,
    tvFee: 35,
    salesTax: 1055,
    totalAmount: 7200,
    amountAfterDueDate: 7800,
    paymentStatus: 'paid',
    paidAt: '2026-07-20T09:30:00Z',
    paidMethod: 'Debit Card (Visa)',
    transactionId: 'TXN-CARD-771920',
  },
];

export const INITIAL_PAYMENTS: PaymentRecord[] = [
  {
    paymentId: 'PAY-2026-09-01',
    billId: 'INV-2026-09-7820',
    userId: 'usr_demo_8820',
    connectionId: 'CONN-LHR-10284',
    connectionName: 'Home Residence',
    serviceProvider: 'LESCO (Lahore Electric Supply Company)',
    billingMonth: 'September 2026',
    amount: 7820,
    paymentMethod: 'Bank Transfer (1Bill IBFT)',
    transactionStatus: 'successful',
    transactionDate: '2026-09-18 14:22 PKT',
    isDemoTransaction: true,
    referenceNumber: '08-11234-0102840-U',
    receiptNumber: 'REC-202609-78201',
  },
];

export const INITIAL_COMPLAINTS: Complaint[] = [
  {
    complaintId: 'CMP-2026-10482',
    userId: 'usr_demo_8820',
    connectionId: 'CONN-LHR-10284',
    connectionName: 'Home Residence',
    category: 'Low Voltage',
    description: 'Line voltage drops below 170V during evening hours (7 PM - 10 PM), causing equipment malfunction and trip incidents.',
    address: 'House 42-B, Model Town, Lahore',
    status: 'Under Review',
    createdAt: '2026-10-14 18:30 PKT',
    assignedTo: 'Engr. M. Farooq (Sub-Division Inspector)',
    timeline: [
      {
        status: 'Submitted',
        timestamp: '14 Oct 2026, 06:30 PM',
        description: 'Electronic ticket logged in distribution network dispatcher.',
      },
      {
        status: 'Under Review',
        timestamp: '15 Oct 2026, 09:15 AM',
        description: 'Assigned to Model Town sub-division technical field supervisor.',
      },
    ],
  },
];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    notificationId: 'NTF-01',
    userId: 'usr_demo_8820',
    title: 'October 2026 Bill Issued',
    message: 'Billing period invoice for Rs. 8,450 (496 units) is generated. Due date: 24 Oct 2026.',
    category: 'bill',
    isRead: false,
    createdAt: '2026-10-14T10:00:00Z',
    relatedBillId: 'INV-2026-10-8450',
  },
];

export const APPLIANCE_PRESETS: AppliancePreset[] = [
  {
    id: 'ac',
    name: 'Inverter AC 1.5 Ton',
    defaultWatts: 1800,
    defaultHours: 8,
    category: 'cooling',
    icon: 'Snowflake',
    savingTip: 'Maintain thermostat at 26°C with auto fan speed. Lowers monthly power draw by ~25%.',
  },
  {
    id: 'fan',
    name: 'Ceiling Fan (Standard AC)',
    defaultWatts: 75,
    defaultHours: 14,
    category: 'cooling',
    icon: 'Fan',
    savingTip: 'Modern BLDC fans use 28W instead of 75W, saving ~20 units/month per fan.',
  },
  {
    id: 'refrigerator',
    name: 'Refrigerator (Double Door)',
    defaultWatts: 250,
    defaultHours: 8,
    category: 'kitchen',
    icon: 'Refrigerator',
    savingTip: 'Ensure 3 inches of rear clearance for optimal condenser heat dissipation.',
  },
  {
    id: 'tv',
    name: 'Smart TV 55"',
    defaultWatts: 110,
    defaultHours: 5,
    category: 'living',
    icon: 'Tv',
    savingTip: 'Turn off socket switch rather than leaving device in standby mode.',
  },
  {
    id: 'iron',
    name: 'Electric Iron (Dry / Steam)',
    defaultWatts: 1000,
    defaultHours: 1,
    category: 'utility',
    icon: 'Zap',
    savingTip: 'Iron clothes in bulk batches to eliminate repetitive pre-heating energy.',
  },
  {
    id: 'motor',
    name: 'Water Motor Pump (1 HP)',
    defaultWatts: 750,
    defaultHours: 1.5,
    category: 'utility',
    icon: 'Droplets',
    savingTip: 'Install float switch sensors to prevent water tank overflow wastage.',
  },
];

export const TARIFF_SLABS: TariffSlab[] = [
  { slab: 'Protected S-1', unitRange: '1 - 100 Units', ratePerUnit: 13.50, notes: 'Protected lifeline slab (6-month average < 200 units)' },
  { slab: 'Protected S-2', unitRange: '101 - 200 Units', ratePerUnit: 16.80, notes: 'Protected residential tier' },
  { slab: 'Unprotected S-1', unitRange: '1 - 100 Units', ratePerUnit: 22.40, notes: 'Standard non-protected baseline rate' },
  { slab: 'Unprotected S-2', unitRange: '101 - 200 Units', ratePerUnit: 27.50, notes: 'Standard residential tariff' },
  { slab: 'Residential S-3', unitRange: '201 - 300 Units', ratePerUnit: 32.10, notes: 'Mid-level consumption bracket' },
  { slab: 'Residential S-4', unitRange: '301 - 700 Units', ratePerUnit: 37.80, notes: 'Higher tier slab with progressive rates' },
  { slab: 'Residential Peak', unitRange: 'Above 700 Units', ratePerUnit: 44.50, notes: 'Highest residential bracket' },
];

export const EDUCATION_ARTICLES: EducationArticle[] = [
  {
    id: 'what-is-a-unit',
    title: 'What Exactly is an Electricity Unit (kWh)?',
    category: 'Fundamentals',
    readTime: '3 min read',
    summary: 'Understanding Kilowatt-hours, appliance wattage, and bill unit consumption.',
    content: [
      'One unit on your electricity meter corresponds directly to 1 Kilowatt-hour (kWh).',
      'This represents 1,000 watts of electrical power operating continuously for one hour.',
      'A 1,000W iron running for 1 hour consumes exactly 1.0 unit. Ten 100W light bulbs running together for 1 hour also consume 1.0 unit.'
    ],
    keyTakeaways: [
      'Units = (Watts × Operating Hours) ÷ 1,000',
      'High-wattage thermal appliances (AC, iron, heater, pump) drive 80% of unit consumption.',
      'Tracking unit numbers instead of rupee amounts gives an objective measure of energy use.'
    ],
  },
  {
    id: 'understanding-fuel-price-adjustments',
    title: 'Understanding Fuel Price Adjustment (FPA) Charges',
    category: 'Tariffs & Regulations',
    readTime: '4 min read',
    summary: 'Why monthly fuel cost adjustments vary based on national generation mix and fuel prices.',
    content: [
      'In Pakistan, thermal power plants utilize imported coal, furnace oil, and RLNG.',
      'NEPRA calculates monthly variances between reference fuel generation costs and actual incurred expenditure.',
      'When fuel import prices fluctuate or hydel generation dips in winter, the difference is billed as FPA 1-2 months retrospectively.'
    ],
    keyTakeaways: [
      'FPA is a regulatory fuel pass-through, not an arbitrary penalty.',
      'General Sales Tax (17%) is legally assessed on FPA line items.',
      'Reducing total units consumed proportionally reduces your FPA charge.'
    ],
  },
];

function getLocalItem<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(STORAGE_KEY_PREFIX + key);
    return item ? JSON.parse(item) : fallback;
  } catch {
    return fallback;
  }
}

function setLocalItem<T>(key: string, data: T): void {
  try {
    localStorage.setItem(STORAGE_KEY_PREFIX + key, JSON.stringify(data));
  } catch (err) {
    console.error('Storage error:', err);
  }
}

export const DataService = {
  getUser(): UserProfile {
    return getLocalItem('user', INITIAL_USER);
  },

  updateUser(updates: Partial<UserProfile>): UserProfile {
    const current = this.getUser();
    const updated = { ...current, ...updates };
    setLocalItem('user', updated);
    return updated;
  },

  getConnections(): ElectricityConnection[] {
    return getLocalItem('connections', INITIAL_CONNECTIONS);
  },

  saveConnections(connections: ElectricityConnection[]): void {
    setLocalItem('connections', connections);
  },

  getActiveConnection(): ElectricityConnection {
    const connections = this.getConnections();
    return connections.find((c) => c.isActive) || connections[0];
  },

  setActiveConnection(connectionId: string): ElectricityConnection {
    const connections = this.getConnections().map((c) => ({
      ...c,
      isActive: c.connectionId === connectionId,
    }));
    this.saveConnections(connections);
    return connections.find((c) => c.connectionId === connectionId) || connections[0];
  },

  addConnection(connection: Omit<ElectricityConnection, 'isActive'>): ElectricityConnection {
    const connections = this.getConnections();
    const newConn: ElectricityConnection = {
      ...connection,
      isActive: false,
    };
    connections.push(newConn);
    this.saveConnections(connections);
    return newConn;
  },

  getBills(connectionId?: string): Bill[] {
    const all = getLocalItem('bills', INITIAL_BILLS);
    if (!connectionId) return all;
    return all.filter((b) => b.connectionId === connectionId);
  },

  addBill(bill: Omit<Bill, 'billId'>): Bill {
    const bills = getLocalItem('bills', INITIAL_BILLS);
    const newBill: Bill = {
      ...bill,
      billId: `INV-${Date.now()}`,
    };
    bills.unshift(newBill);
    setLocalItem('bills', bills);
    return newBill;
  },

  markBillPaid(billId: string, paymentMethod: string, transactionId: string): Bill | null {
    const bills = getLocalItem('bills', INITIAL_BILLS);
    const index = bills.findIndex((b) => b.billId === billId);
    if (index === -1) return null;

    const targetBill = bills[index];
    const updatedBill: Bill = {
      ...targetBill,
      paymentStatus: 'paid',
      paidAt: new Date().toISOString(),
      paidMethod: paymentMethod,
      transactionId,
    };

    bills[index] = updatedBill;
    setLocalItem('bills', bills);

    // Save payment
    const payments = this.getPayments();
    const newPayment: PaymentRecord = {
      paymentId: `PAY-${Date.now()}`,
      billId: targetBill.billId,
      userId: targetBill.userId,
      connectionId: targetBill.connectionId,
      connectionName: targetBill.connectionId,
      serviceProvider: targetBill.serviceProvider,
      billingMonth: targetBill.billingMonth,
      amount: targetBill.totalAmount,
      paymentMethod,
      transactionStatus: 'successful',
      transactionDate: new Date().toLocaleString('en-PK', { timeZone: 'Asia/Karachi' }) + ' PKT',
      isDemoTransaction: true,
      referenceNumber: targetBill.connectionId,
      receiptNumber: `REC-${Date.now().toString().slice(-6)}`,
    };
    payments.unshift(newPayment);
    setLocalItem('payments', payments);

    return updatedBill;
  },

  getPayments(): PaymentRecord[] {
    return getLocalItem('payments', INITIAL_PAYMENTS);
  },

  getComplaints(): Complaint[] {
    return getLocalItem('complaints', INITIAL_COMPLAINTS);
  },

  addComplaint(data: {
    connectionId: string;
    connectionName: string;
    category: Complaint['category'];
    description: string;
    address?: string;
  }): Complaint {
    const complaints = this.getComplaints();
    const id = `CMP-${Math.floor(10000 + Math.random() * 90000)}`;
    const newComplaint: Complaint = {
      complaintId: id,
      userId: 'usr_demo_8820',
      connectionId: data.connectionId,
      connectionName: data.connectionName,
      category: data.category,
      description: data.description,
      address: data.address || 'Address on file',
      status: 'Submitted',
      createdAt: new Date().toLocaleString('en-PK', { timeZone: 'Asia/Karachi' }) + ' PKT',
      timeline: [
        {
          status: 'Submitted',
          timestamp: 'Just now',
          description: 'Ticket registered in distribution dispatch system.',
        },
      ],
    };

    complaints.unshift(newComplaint);
    setLocalItem('complaints', complaints);
    return newComplaint;
  },

  getNotifications(): AppNotification[] {
    return getLocalItem('notifications', INITIAL_NOTIFICATIONS);
  },

  markNotificationRead(id: string): void {
    const notifs = this.getNotifications().map((n) =>
      n.notificationId === id ? { ...n, isRead: true } : n
    );
    setLocalItem('notifications', notifs);
  },

  markAllNotificationsRead(): void {
    const notifs = this.getNotifications().map((n) => ({ ...n, isRead: true }));
    setLocalItem('notifications', notifs);
  },

  deleteNotification(id: string): void {
    const notifs = this.getNotifications().filter((n) => n.notificationId !== id);
    setLocalItem('notifications', notifs);
  },

  getMonthlyUsage(connectionId?: string): MonthlyUsage[] {
    return [
      { month: 'May', units: 380, estimatedCost: 6900 },
      { month: 'June', units: 410, estimatedCost: 7550 },
      { month: 'July', units: 390, estimatedCost: 7200 },
      { month: 'August', units: 440, estimatedCost: 8100 },
      { month: 'September', units: 420, estimatedCost: 7820 },
      { month: 'October', units: 496, estimatedCost: 8450, isCurrent: true },
    ];
  },

  resetDemoData(): void {
    localStorage.removeItem(STORAGE_KEY_PREFIX + 'user');
    localStorage.removeItem(STORAGE_KEY_PREFIX + 'connections');
    localStorage.removeItem(STORAGE_KEY_PREFIX + 'bills');
    localStorage.removeItem(STORAGE_KEY_PREFIX + 'payments');
    localStorage.removeItem(STORAGE_KEY_PREFIX + 'complaints');
    localStorage.removeItem(STORAGE_KEY_PREFIX + 'notifications');
  },
};
