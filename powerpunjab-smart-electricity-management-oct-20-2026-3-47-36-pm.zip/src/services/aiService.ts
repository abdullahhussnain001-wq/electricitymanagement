import { Bill, AiAnalysisResult, ChatMessage } from '../types';

export const AiService = {
  async analyzeBill(bill: Bill, previousBill?: Bill, connectionName?: string): Promise<AiAnalysisResult> {
    try {
      const response = await fetch('/api/gemini/analyze-bill', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bill, previousBill, connectionName }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.warn('Using client-side fallback for AI bill analysis:', error);
      // Failsafe fallback
      const prevUnits = previousBill ? previousBill.unitsConsumed : 420;
      const prevAmount = previousBill ? previousBill.totalAmount : 7820;
      const unitDiff = bill.unitsConsumed - prevUnits;
      const unitPct = ((unitDiff / prevUnits) * 100).toFixed(1);
      const amountDiff = bill.totalAmount - prevAmount;
      const amountPct = ((amountDiff / prevAmount) * 100).toFixed(1);

      return {
        source: 'client-fallback',
        summary: `Your ${bill.billingMonth} electricity bill is Rs. ${bill.totalAmount.toLocaleString()} for ${bill.unitsConsumed} units. Recorded consumption increased by ${unitDiff >= 0 ? '+' : ''}${unitDiff} units (${unitPct}%) compared to the previous cycle.`,
        consumptionChange: `Units consumed changed from ${prevUnits} to ${bill.unitsConsumed} (${unitPct}%). The bill increased by Rs. ${amountDiff.toLocaleString()} (${amountPct}%), moving into a higher marginal tariff bracket.`,
        chargeBreakdown: [
          { name: 'Cost of Electricity', amount: bill.costOfElectricity, explanation: 'Base energy rate across progressive slab brackets.' },
          { name: 'Fuel Price Adjustment (FPA)', amount: bill.fuelPriceAdjustment, explanation: 'Regulatory adjustment reflecting thermal generation fuel mix variations.' },
          { name: 'FC Surcharge & Duty', amount: bill.fcSurcharge + bill.electricityDuty, explanation: 'Financing debt servicing surcharge and provincial excise duty.' },
          { name: 'General Sales Tax (17%)', amount: bill.salesTax, explanation: 'Statutory sales tax assessed on total electricity services.' },
        ],
        possibleReasons: [
          'High ambient humidity during late summer resulting in extended compressor runtime on air conditioning.',
          'Refrigeration appliances working harder against ambient kitchen temperatures.',
          'Crossing the 300/400 unit slab threshold where the baseline unit tariff escalates significantly.',
          'Seasonal variation in quarterly fuel cost adjustments passed by NEPRA.'
        ],
        recommendations: [
          'Keep your air conditioner temperature locked at 26°C with auto fan speed to cut compressor draw by ~25%.',
          'Avoid using heavy power-drawing appliances like irons and washing machines during evening peak hours.',
          'Ensure refrigerator coils have at least 3 inches of clear airflow behind the unit.',
          'Replace any remaining high-wattage incandescent bulbs with energy-efficient LED lighting.'
        ],
        limitations: 'This AI analysis is generated using demonstration billing metrics and simulated tariff models. It is not an official utility bill assessment.'
      };
    }
  },

  async chat(messages: { role: 'user' | 'assistant'; content: string }[], userContext?: any): Promise<string> {
    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages, userContext }),
      });

      if (!response.ok) {
        throw new Error(`Chat error status: ${response.status}`);
      }

      const data = await response.json();
      return data.reply || 'I could not generate an answer at the moment.';
    } catch (error) {
      console.warn('Fallback response for AI chat:', error);
      const lastMsg = messages[messages.length - 1]?.content.toLowerCase() || '';
      if (lastMsg.includes('high') || lastMsg.includes('bill') || lastMsg.includes('increase')) {
        return "Your October bill rose to Rs. 8,450 because consumption jumped from 420 to 496 units (+18.1%). Under Punjab's slab system, higher units fall into steeper per-unit tariff brackets, compounded by FPA and 17% GST.";
      }
      return "PowerPunjab Assistant: I can help explain your bill, calculate appliance operating costs, or guide you through filing a complaint.";
    }
  },

  async getApplianceAdvice(appliance: string, watts: number, hours: number, monthlyCost: number): Promise<string> {
    try {
      const res = await fetch('/api/gemini/appliance-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appliance, watts, hours, monthlyCost }),
      });
      const data = await res.json();
      return data.advice || `For ${appliance}, reducing daily usage by 1 hour saves noticeable units across the month.`;
    } catch {
      return `Operating ${appliance} outside peak hours and regular cleaning can lower consumption by up to 15%.`;
    }
  }
};
