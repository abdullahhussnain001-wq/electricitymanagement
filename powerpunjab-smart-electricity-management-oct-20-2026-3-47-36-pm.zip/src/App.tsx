/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { Navigation } from './components/common/Navigation';
import { LoginModal } from './components/auth/LoginModal';
import { DashboardTab } from './components/dashboard/DashboardTab';
import { BillsTab } from './components/bills/BillsTab';
import { UsageTab } from './components/usage/UsageTab';
import { AiAssistantTab } from './components/ai/AiAssistantTab';
import { ProfileTab } from './components/profile/ProfileTab';

// Modals
import { BillDetailsModal } from './components/bills/BillDetailsModal';
import { AiBillAnalyzerModal } from './components/bills/AiBillAnalyzerModal';
import { PaymentModal } from './components/payment/PaymentModal';
import { EnergyCalculatorModal } from './components/calculator/EnergyCalculatorModal';
import { ComplaintsModal } from './components/complaints/ComplaintsModal';
import { NotificationsModal } from './components/notifications/NotificationsModal';
import { TariffsAndEducationModal } from './components/education/TariffsAndEducationModal';
import { AddBillModal } from './components/bills/AddBillModal';
import { PdfReportModal } from './components/reports/PdfReportModal';

const MainAppContent: React.FC = () => {
  const { isAuthenticated, activeTab } = useApp();

  if (!isAuthenticated) {
    return <LoginModal />;
  }

  return (
    <div className="min-h-screen bg-[#F4F6F8] text-[#1D2A44] flex flex-col font-sans selection:bg-[#003366] selection:text-white">
      <Header />

      <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'home' && <DashboardTab />}
        {activeTab === 'bills' && <BillsTab />}
        {activeTab === 'usage' && <UsageTab />}
        {activeTab === 'ai' && <AiAssistantTab />}
        {activeTab === 'profile' && <ProfileTab />}
      </main>

      <Footer />

      <Navigation />

      {/* Global Modals */}
      <BillDetailsModal />
      <AiBillAnalyzerModal />
      <PaymentModal />
      <EnergyCalculatorModal />
      <ComplaintsModal />
      <NotificationsModal />
      <TariffsAndEducationModal />
      <AddBillModal />
      <PdfReportModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
