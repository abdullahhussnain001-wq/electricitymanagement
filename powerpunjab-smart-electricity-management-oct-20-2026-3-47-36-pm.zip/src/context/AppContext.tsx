import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserProfile,
  ElectricityConnection,
  Bill,
  PaymentRecord,
  Complaint,
  AppNotification,
  TabType,
} from '../types';
import { DataService, INITIAL_USER } from '../services/dataService';
import { auth, googleProvider, testConnection } from '../firebase/config';
import { signInWithPopup, signOut as fbSignOut, onAuthStateChanged } from 'firebase/auth';

interface AppContextType {
  user: UserProfile;
  isAuthenticated: boolean;
  connections: ElectricityConnection[];
  activeConnection: ElectricityConnection;
  bills: Bill[];
  currentBill: Bill | undefined;
  previousBill: Bill | undefined;
  payments: PaymentRecord[];
  complaints: Complaint[];
  notifications: AppNotification[];
  activeTab: TabType;
  unreadNotificationsCount: number;

  // Modals & Navigation triggers
  isPaymentModalOpen: boolean;
  activeBillForPayment: Bill | null;
  isBillDetailsModalOpen: boolean;
  activeBillForDetails: Bill | null;
  isAiAnalyzerOpen: boolean;
  activeBillForAnalysis: Bill | null;
  isCalculatorOpen: boolean;
  isComplaintsModalOpen: boolean;
  isNotificationsModalOpen: boolean;
  isTariffsEducationOpen: boolean;
  isAddBillOpen: boolean;
  isPdfReportOpen: boolean;
  isResetConfirmOpen: boolean;

  // Setters & Actions
  setActiveTab: (tab: TabType) => void;
  switchConnection: (connectionId: string) => void;
  updateUser: (updates: Partial<UserProfile>) => void;
  markBillAsPaid: (billId: string, method: string) => Promise<{ success: boolean; receiptNumber?: string }>;
  submitComplaint: (data: { category: Complaint['category']; description: string; address?: string }) => void;
  addNewBill: (billData: Omit<Bill, 'billId'>) => Bill;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  deleteNotification: (id: string) => void;

  // Modal controls
  openPaymentModal: (bill?: Bill) => void;
  closePaymentModal: () => void;
  openBillDetails: (bill: Bill) => void;
  closeBillDetails: () => void;
  openAiAnalyzer: (bill?: Bill) => void;
  closeAiAnalyzer: () => void;
  openCalculator: () => void;
  closeCalculator: () => void;
  openComplaintsModal: () => void;
  closeComplaintsModal: () => void;
  openNotificationsModal: () => void;
  closeNotificationsModal: () => void;
  openTariffsEducation: () => void;
  closeTariffsEducation: () => void;
  openAddBill: () => void;
  closeAddBill: () => void;
  openPdfReport: () => void;
  closePdfReport: () => void;
  openResetConfirm: () => void;
  closeResetConfirm: () => void;

  // Auth
  loginAsDemo: () => void;
  loginUser: (email: string, name?: string) => void;
  loginWithGoogleAuth: () => Promise<void>;
  logout: () => void;
  resetDemoData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile>(() => DataService.getUser());
  // IMPORTANT: Set to false initially so user lands on login page to see demo credentials and sign in / register!
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [connections, setConnections] = useState<ElectricityConnection[]>(() => DataService.getConnections());
  const [activeConnection, setActiveConnection] = useState<ElectricityConnection>(() => DataService.getActiveConnection());
  const [bills, setBills] = useState<Bill[]>(() => DataService.getBills(activeConnection.connectionId));
  const [payments, setPayments] = useState<PaymentRecord[]>(() => DataService.getPayments());
  const [complaints, setComplaints] = useState<Complaint[]>(() => DataService.getComplaints());
  const [notifications, setNotifications] = useState<AppNotification[]>(() => DataService.getNotifications());
  const [activeTab, setActiveTab] = useState<TabType>('home');

  // Modals
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [activeBillForPayment, setActiveBillForPayment] = useState<Bill | null>(null);
  const [isBillDetailsModalOpen, setIsBillDetailsModalOpen] = useState(false);
  const [activeBillForDetails, setActiveBillForDetails] = useState<Bill | null>(null);
  const [isAiAnalyzerOpen, setIsAiAnalyzerOpen] = useState(false);
  const [activeBillForAnalysis, setActiveBillForAnalysis] = useState<Bill | null>(null);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [isComplaintsModalOpen, setIsComplaintsModalOpen] = useState(false);
  const [isNotificationsModalOpen, setIsNotificationsModalOpen] = useState(false);
  const [isTariffsEducationOpen, setIsTariffsEducationOpen] = useState(false);
  const [isAddBillOpen, setIsAddBillOpen] = useState(false);
  const [isPdfReportOpen, setIsPdfReportOpen] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  useEffect(() => {
    testConnection();

    const unsubscribe = onAuthStateChanged(auth, (fbUser) => {
      if (fbUser) {
        setUser((prev) => ({
          ...prev,
          userId: fbUser.uid,
          name: fbUser.displayName || prev.name,
          email: fbUser.email || prev.email,
          accountType: 'google',
          avatarUrl: fbUser.photoURL || prev.avatarUrl,
        }));
        setIsAuthenticated(true);
      }
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const updatedBills = DataService.getBills(activeConnection.connectionId);
    setBills(updatedBills);
  }, [activeConnection]);

  const refreshAllData = () => {
    const active = DataService.getActiveConnection();
    setActiveConnection(active);
    setConnections(DataService.getConnections());
    setBills(DataService.getBills(active.connectionId));
    setPayments(DataService.getPayments());
    setComplaints(DataService.getComplaints());
    setNotifications(DataService.getNotifications());
    setUser(DataService.getUser());
  };

  const switchConnection = (connectionId: string) => {
    const newActive = DataService.setActiveConnection(connectionId);
    setActiveConnection(newActive);
    setConnections(DataService.getConnections());
    setBills(DataService.getBills(newActive.connectionId));
  };

  const updateUser = (updates: Partial<UserProfile>) => {
    const updated = DataService.updateUser(updates);
    setUser(updated);
  };

  const addNewBill = (billData: Omit<Bill, 'billId'>) => {
    const created = DataService.addBill(billData);
    setBills(DataService.getBills(activeConnection.connectionId));
    return created;
  };

  const markBillAsPaid = async (billId: string, method: string) => {
    const txnId = `TXN-${Math.floor(100000 + Math.random() * 900000)}`;
    const updated = DataService.markBillPaid(billId, method, txnId);
    if (updated) {
      refreshAllData();
      return { success: true, receiptNumber: txnId };
    }
    return { success: false };
  };

  const submitComplaint = (data: { category: Complaint['category']; description: string; address?: string }) => {
    DataService.addComplaint({
      connectionId: activeConnection.connectionId,
      connectionName: `${activeConnection.displayName} (${activeConnection.referenceNumber})`,
      category: data.category,
      description: data.description,
      address: data.address,
    });
    setComplaints(DataService.getComplaints());
    setNotifications(DataService.getNotifications());
  };

  const markNotificationAsRead = (id: string) => {
    DataService.markNotificationRead(id);
    setNotifications(DataService.getNotifications());
  };

  const markAllNotificationsAsRead = () => {
    DataService.markAllNotificationsRead();
    setNotifications(DataService.getNotifications());
  };

  const deleteNotification = (id: string) => {
    DataService.deleteNotification(id);
    setNotifications(DataService.getNotifications());
  };

  // Modals
  const openPaymentModal = (bill?: Bill) => {
    const target = bill || bills.find((b) => b.paymentStatus === 'unpaid') || bills[0];
    setActiveBillForPayment(target || null);
    setIsPaymentModalOpen(true);
  };

  const closePaymentModal = () => {
    setIsPaymentModalOpen(false);
    setActiveBillForPayment(null);
  };

  const openBillDetails = (bill: Bill) => {
    setActiveBillForDetails(bill);
    setIsBillDetailsModalOpen(true);
  };

  const closeBillDetails = () => {
    setIsBillDetailsModalOpen(false);
    setActiveBillForDetails(null);
  };

  const openAiAnalyzer = (bill?: Bill) => {
    const target = bill || bills[0];
    setActiveBillForAnalysis(target || null);
    setIsAiAnalyzerOpen(true);
  };

  const closeAiAnalyzer = () => {
    setIsAiAnalyzerOpen(false);
    setActiveBillForAnalysis(null);
  };

  const openCalculator = () => setIsCalculatorOpen(true);
  const closeCalculator = () => setIsCalculatorOpen(false);

  const openComplaintsModal = () => setIsComplaintsModalOpen(true);
  const closeComplaintsModal = () => setIsComplaintsModalOpen(false);

  const openNotificationsModal = () => setIsNotificationsModalOpen(true);
  const closeNotificationsModal = () => setIsNotificationsModalOpen(false);

  const openTariffsEducation = () => setIsTariffsEducationOpen(true);
  const closeTariffsEducation = () => setIsTariffsEducationOpen(false);

  const openAddBill = () => setIsAddBillOpen(true);
  const closeAddBill = () => setIsAddBillOpen(false);

  const openPdfReport = () => setIsPdfReportOpen(true);
  const closePdfReport = () => setIsPdfReportOpen(false);

  const openResetConfirm = () => setIsResetConfirmOpen(true);
  const closeResetConfirm = () => setIsResetConfirmOpen(false);

  // Authentication
  const loginAsDemo = () => {
    setUser(INITIAL_USER);
    setIsAuthenticated(true);
    refreshAllData();
  };

  const loginUser = (email: string, name?: string) => {
    const updated = DataService.updateUser({
      email,
      name: name || email.split('@')[0],
      accountType: 'registered',
    });
    setUser(updated);
    setIsAuthenticated(true);
    refreshAllData();
  };

  const loginWithGoogleAuth = async () => {
    try {
      const res = await signInWithPopup(auth, googleProvider);
      if (res.user) {
        setUser((prev) => ({
          ...prev,
          userId: res.user.uid,
          name: res.user.displayName || 'Authorized User',
          email: res.user.email || 'user@gmail.com',
          accountType: 'google',
          avatarUrl: res.user.photoURL || prev.avatarUrl,
        }));
        setIsAuthenticated(true);
      }
    } catch (err) {
      console.error('Google Sign-in failed:', err);
    }
  };

  const logout = async () => {
    try {
      await fbSignOut(auth);
    } catch {
      // ignore
    }
    setIsAuthenticated(false);
  };

  const resetDemoData = () => {
    DataService.resetDemoData();
    refreshAllData();
    setIsResetConfirmOpen(false);
  };

  const currentBill = bills.find((b) => b.billingMonth === 'October 2026') || bills[0];
  const previousBill = bills.find((b) => b.billingMonth === 'September 2026');
  const unreadNotificationsCount = notifications.filter((n) => !n.isRead).length;

  return (
    <AppContext.Provider
      value={{
        user,
        isAuthenticated,
        connections,
        activeConnection,
        bills,
        currentBill,
        previousBill,
        payments,
        complaints,
        notifications,
        activeTab,
        unreadNotificationsCount,

        isPaymentModalOpen,
        activeBillForPayment,
        isBillDetailsModalOpen,
        activeBillForDetails,
        isAiAnalyzerOpen,
        activeBillForAnalysis,
        isCalculatorOpen,
        isComplaintsModalOpen,
        isNotificationsModalOpen,
        isTariffsEducationOpen,
        isAddBillOpen,
        isPdfReportOpen,
        isResetConfirmOpen,

        setActiveTab,
        switchConnection,
        updateUser,
        addNewBill,
        markBillAsPaid,
        submitComplaint,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        deleteNotification,

        openPaymentModal,
        closePaymentModal,
        openBillDetails,
        closeBillDetails,
        openAiAnalyzer,
        closeAiAnalyzer,
        openCalculator,
        closeCalculator,
        openComplaintsModal,
        closeComplaintsModal,
        openNotificationsModal,
        closeNotificationsModal,
        openTariffsEducation,
        closeTariffsEducation,
        openAddBill,
        closeAddBill,
        openPdfReport,
        closePdfReport,
        openResetConfirm,
        closeResetConfirm,

        loginAsDemo,
        loginUser,
        loginWithGoogleAuth,
        logout,
        resetDemoData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
