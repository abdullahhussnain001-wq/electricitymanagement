export type TabType = 'home' | 'bills' | 'usage' | 'ai' | 'profile';

export interface UserProfile {
  userId: string;
  name: string;
  email: string;
  phone: string;
  accountType: 'demo' | 'registered' | 'google';
  createdAt: string;
  avatarUrl?: string;
  notificationsEnabled: boolean;
  theme: 'dark' | 'light' | 'system';
  language: 'en' | 'ur';
}

export interface ElectricityConnection {
  connectionId: string;
  userId: string;
  displayName: string;
  referenceNumber: string;
  maskedMeterNumber: string;
  serviceProvider: string; // e.g., "LESCO - Lahore Electric Supply Company"
  connectionType: 'Residential Single-Phase' | 'Residential 3-Phase' | 'Commercial';
  sanctionedLoad: string;
  tariff: string;
  address: string;
  feederName: string;
  subDivision: string;
  isActive: boolean;
}

export interface BillCharges {
  costOfElectricity: number;
  fuelPriceAdjustment: number;
  fcSurcharge: number;
  electricityDuty: number;
  tvFee: number;
  salesTax: number;
}

export interface Bill {
  billId: string;
  connectionId: string;
  userId: string;
  serviceProvider: string; // e.g. "LESCO - Lahore Electric Supply Company"
  billingMonth: string; // e.g. "October 2026"
  billingPeriod: string; // e.g. "15 Sep 2026 - 15 Oct 2026"
  issueDate: string;
  dueDate: string;
  unitsConsumed: number;
  previousReading: number;
  currentReading: number;
  costOfElectricity: number;
  fuelPriceAdjustment: number;
  fcSurcharge: number;
  electricityDuty: number;
  tvFee: number;
  salesTax: number;
  totalAmount: number;
  amountAfterDueDate: number;
  paymentStatus: 'unpaid' | 'paid' | 'processing';
  paidAt?: string;
  paidMethod?: string;
  transactionId?: string;
}

export interface PaymentRecord {
  paymentId: string;
  billId: string;
  userId: string;
  connectionId: string;
  connectionName: string;
  serviceProvider: string;
  billingMonth: string;
  amount: number;
  paymentMethod: string;
  transactionStatus: 'successful' | 'processing' | 'failed';
  transactionDate: string;
  isDemoTransaction: boolean;
  referenceNumber: string;
  receiptNumber: string;
}

export interface ComplaintTimelineItem {
  status: 'Submitted' | 'Under Review' | 'Assigned' | 'Resolved';
  timestamp: string;
  description: string;
}

export interface Complaint {
  complaintId: string;
  userId: string;
  connectionId: string;
  connectionName: string;
  category: 'Power Outage' | 'Low Voltage' | 'Billing Issue' | 'Meter Issue' | 'Transformer Issue' | 'Other Issue';
  description: string;
  address?: string;
  status: 'Submitted' | 'Under Review' | 'Assigned' | 'Resolved';
  timeline: ComplaintTimelineItem[];
  createdAt: string;
  assignedTo?: string;
}

export interface AppNotification {
  notificationId: string;
  userId: string;
  title: string;
  message: string;
  category: 'bill' | 'payment' | 'complaint' | 'insight';
  isRead: boolean;
  createdAt: string;
  relatedBillId?: string;
  relatedComplaintId?: string;
}

export interface MonthlyUsage {
  month: string;
  units: number;
  estimatedCost: number;
  isCurrent?: boolean;
}

export interface AppliancePreset {
  id: string;
  name: string;
  defaultWatts: number;
  defaultHours: number;
  category: 'cooling' | 'living' | 'kitchen' | 'utility';
  icon: string;
  savingTip: string;
}

export interface TariffSlab {
  slab: string;
  unitRange: string;
  ratePerUnit: number;
  notes: string;
}

export interface EducationArticle {
  id: string;
  title: string;
  category: string;
  readTime: string;
  summary: string;
  content: string[];
  keyTakeaways: string[];
}

export interface AiAnalysisResult {
  source: string;
  summary: string;
  consumptionChange: string;
  chargeBreakdown: Array<{
    name: string;
    amount: number;
    explanation: string;
  }>;
  possibleReasons: string[];
  recommendations: string[];
  limitations: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}
